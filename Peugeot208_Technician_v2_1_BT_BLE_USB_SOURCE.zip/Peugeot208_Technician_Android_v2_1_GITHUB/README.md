# Peugeot 208 Technician — Android v2 Bluetooth + USB

App Android dedicata al profilo:

**Peugeot 208 II — 2022 — 1.2 PureTech Turbo 100 CV — HNK/EB2ADT — cambio manuale**

Fingerprint già osservato e usato soltanto come riferimento diagnostico:

- ISO 15765-4 CAN, 11 bit, 500 kbit/s
- Calibration ID: `9609SsCS`
- CVN: `A86E9F62`
- DTC di particolare interesse nel profilo: `P050B` e `U1F1A`

## Collegamento consigliato con il tuo OBD Bluetooth

`Peugeot 208 → presa OBD-II → ELM327 Bluetooth → telefono Android → Peugeot 208 Technician`

Il telefono non va collegato direttamente alla presa OBD: l'ELM327 resta l'interfaccia tra CAN/OBD dell'auto e Android.

### Bluetooth classico (SPP)

È il caso più comune per molti ELM327 Bluetooth economici.

1. Inserisci l'ELM327 nella presa OBD-II.
2. Metti il quadro su ON.
3. Dal Bluetooth di Android associa l'ELM327 una volta. Se richiesto, molti modelli usano `1234` o `0000` (dipende dal produttore).
4. Apri l'app e concedi **Dispositivi nelle vicinanze**.
5. Premi **RILEVA OBD USB + BLUETOOTH**.
6. Seleziona la voce `BT CLASSIC ...`.
7. Premi **CONNETTI E INIZIALIZZA OBD**.

La connessione usa RFCOMM/SPP; il baud rate mostrato nell'app è ignorato per Bluetooth ed è usato soltanto dagli adattatori USB seriali.

### Bluetooth Low Energy (BLE)

La v2 effettua anche una scansione BLE e tenta di riconoscere automaticamente una coppia di caratteristiche GATT scrivibile + notificabile. Include preferenze per profili seriali BLE comuni (Nordic UART, FFE1/FFF1) e un fallback euristico.

Gli ELM327 BLE non sono standardizzati a livello di UUID GATT: se un adattatore usa un servizio proprietario incompatibile, l'app lo segnala invece di inviare dati alla cieca.

### USB/OTG

Resta disponibile il collegamento della v1:

`Telefono USB-C/OTG → ELM327 USB → presa OBD-II`

Sono supportati i convertitori seriali riconosciuti da `usb-serial-for-android`.

## Diagnostica disponibile

### CONNETTI

- ricerca USB, Bluetooth classico già associato e BLE;
- inizializzazione ELM327 (`ATZ`, echo/linefeed/spazi off, adaptive timing, `ATSP0`);
- identificazione adattatore;
- protocollo OBD rilevato;
- tensione adattatore;
- VIN Mode 09;
- Calibration ID e CVN quando disponibili;
- confronto con il fingerprint già noto della vettura;
- bitmap PID Mode 01 supportati.

### LIVE DATA

Se esposti dalla ECU:

- RPM e velocità;
- ECT/IAT;
- anticipo accensione;
- carico motore;
- STFT/LTFT;
- MAP/MAF;
- farfalla;
- livello carburante;
- tensione ECU e adattatore;
- stima indicativa del consumo quando è disponibile il MAF.

### DTC

- Mode 03: confermati;
- Mode 07: pending;
- Mode 0A: permanenti;
- profilo esplicativo per `P050B`;
- `U1F1A` trattato come manufacturer-specific senza inventare descrizioni PSA;
- Mode 04 per cancellare DTC soltanto dopo conferma manuale `CANCELLA`.

### COLD START / P050B

Recorder fino a 180 secondi da avviare prima dell'avviamento a freddo. Registra i PID disponibili e produce report + CSV, con controlli su:

- ECT/IAT iniziali;
- tensione;
- andamento RPM;
- anticipo;
- fuel trim;
- MAP/MAF quando presenti.

### RADIO USB

Resta un modulo separato, esclusivamente passivo, per verificare se una eventuale porta service della head-unit si presenta realmente come USB DEVICE. La normale USB multimediale dell'auto non viene trattata automaticamente come porta diagnostica.

### AI LOCALE

L'AI riceve soltanto report testuali, DTC e live data. Non possiede accesso al trasporto Bluetooth/USB e non può trasmettere comandi alla vettura.

## Operazioni volutamente non presenti

Questa build non implementa coding BSI/ECU, SecurityAccess UDS, programmazione immobilizer/chiavi, flashing firmware, scrittura calibrazioni, raw CAN injection, routine proprietarie o bypass.

Lo scopo è diagnosi OBD leggibile e tracciabile sulla vettura dell'utente.

## Permessi Android

Per Android 12+ vengono richiesti `BLUETOOTH_SCAN` e `BLUETOOTH_CONNECT` come permessi runtime. Sui dispositivi precedenti vengono mantenuti i permessi Bluetooth legacy e, per la scansione BLE, il permesso di localizzazione previsto dalle API precedenti.

L'app non usa i risultati BLE per determinare la posizione fisica.

## Build APK

Apri la cartella con Android Studio e compila `app` in Debug. È incluso anche `.github/workflows/build-apk.yml`, che esegue unit test e `assembleDebug` su GitHub Actions.

## Limiti della verifica in questo pacchetto

Sono stati verificati staticamente manifest, XML, riferimenti ViewBinding e separazione delle capacità. Il decoder OBD puro viene testato separatamente. Una prova completa di SPP/BLE richiede necessariamente un telefono Android reale e l'adattatore ELM327 specifico, perché i cloni BLE possono usare UUID GATT differenti.
