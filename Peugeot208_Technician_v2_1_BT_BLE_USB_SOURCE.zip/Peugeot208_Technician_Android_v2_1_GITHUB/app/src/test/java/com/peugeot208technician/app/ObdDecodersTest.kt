package com.peugeot208technician.app

import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test

class ObdDecodersTest {
    @Test fun rpm() {
        assertEquals(1726.0, ObdDecoders.pidValue("41 0C 1A F8 >", 0x0C)!!, 0.001)
    }

    @Test fun coolant() {
        assertEquals(83.0, ObdDecoders.pidValue("41 05 7B >", 0x05)!!, 0.001)
    }

    @Test fun dtc() {
        assertEquals(listOf("P0133"), ObdDecoders.parseDtcs("43 01 33 00 00 >", 0x43))
    }

    @Test fun vin() {
        val vin = ObdDecoders.parseVin("49 02 01 56 46 33 55 48 4E 5A 4B 54 4D 59 31 32 33 34 35 36 37 >")
        assertTrue(vin?.startsWith("VF3") == true)
    }
}
