package com.peugeot208technician.app

data class ElmInfo(
    val identity: String,
    val protocol: String,
    val adapterVoltage: String,
    val vin: String?,
    val calibrationId: String? = null,
    val cvn: String? = null
)

data class LiveSnapshot(
    val timestampMs: Long = System.currentTimeMillis(),
    val rpm: Double? = null,
    val speedKmh: Double? = null,
    val coolantC: Double? = null,
    val intakeC: Double? = null,
    val timingAdvanceDeg: Double? = null,
    val engineLoadPct: Double? = null,
    val stftPct: Double? = null,
    val ltftPct: Double? = null,
    val mapKpa: Double? = null,
    val mafGps: Double? = null,
    val throttlePct: Double? = null,
    val fuelLevelPct: Double? = null,
    val ecuVoltageV: Double? = null,
    val adapterVoltageV: Double? = null
) {
    fun humanReadable(): String = buildString {
        appendLine("RPM: ${rpm.fmt("rpm")}")
        appendLine("Velocità: ${speedKmh.fmt("km/h")}")
        appendLine("Liquido motore (ECT): ${coolantC.fmt("°C")}")
        appendLine("Aria aspirata (IAT): ${intakeC.fmt("°C")}")
        appendLine("Anticipo accensione: ${timingAdvanceDeg.fmt("°")}")
        appendLine("Carico calcolato: ${engineLoadPct.fmt("%")}")
        appendLine("STFT B1: ${stftPct.fmt("%")}")
        appendLine("LTFT B1: ${ltftPct.fmt("%")}")
        appendLine("MAP: ${mapKpa.fmt("kPa")}")
        appendLine("MAF: ${mafGps.fmt("g/s")}")
        appendLine("Farfalla: ${throttlePct.fmt("%")}")
        appendLine("Carburante: ${fuelLevelPct.fmt("%")}")
        appendLine("Tensione ECU: ${ecuVoltageV.fmt("V")}")
        appendLine("Tensione adattatore: ${adapterVoltageV.fmt("V")}")
        estimatedFuelLph()?.let { appendLine("Consumo stimato da MAF: ${"%.2f".format(it)} L/h (indicativo)") }
    }

    fun estimatedFuelLph(): Double? {
        val maf = mafGps ?: return null
        if (maf <= 0.0) return null
        // Stima benzina a lambda~1: MAF / AFR stechiometrico / densità benzina.
        return maf * 3600.0 / (14.7 * 745.0)
    }

    private fun Double?.fmt(unit: String): String = this?.let { "%.2f %s".format(it, unit) } ?: "n/d"
}

data class DtcReport(
    val confirmed: List<String>,
    val pending: List<String>,
    val permanent: List<String>
)
