package com.peugeot208technician.app

data class UsbEndpointInfo(
    val address: Int,
    val direction: String,
    val type: String,
    val maxPacketSize: Int
)

data class UsbInterfaceInfo(
    val index: Int,
    val interfaceClass: Int,
    val interfaceClassName: String,
    val subclass: Int,
    val protocol: Int,
    val endpoints: List<UsbEndpointInfo>
)

data class UsbScanReport(
    val deviceName: String,
    val vendorId: Int,
    val productId: Int,
    val manufacturer: String?,
    val product: String?,
    val deviceClass: Int,
    val deviceClassName: String,
    val interfaces: List<UsbInterfaceInfo>,
    val notes: List<String>
) {
    fun humanReadable(): String = buildString {
        appendLine("SAFE ANALYSIS — nessun comando inviato")
        appendLine("Device: $deviceName")
        appendLine("VID:PID = %04X:%04X".format(vendorId, productId))
        appendLine("Produttore: ${manufacturer ?: "non disponibile"}")
        appendLine("Prodotto: ${product ?: "non disponibile"}")
        appendLine("Classe device: $deviceClass ($deviceClassName)")
        appendLine("Interfacce: ${interfaces.size}")
        interfaces.forEach { intf ->
            appendLine()
            appendLine("IF ${intf.index}: ${intf.interfaceClassName} " +
                    "[class=${intf.interfaceClass}, sub=${intf.subclass}, proto=${intf.protocol}]")
            if (intf.endpoints.isEmpty()) appendLine("  nessun endpoint")
            intf.endpoints.forEach { ep ->
                appendLine("  EP 0x%02X ${ep.direction} ${ep.type} maxPacket=${ep.maxPacketSize}"
                    .format(ep.address))
            }
        }
        if (notes.isNotEmpty()) {
            appendLine()
            appendLine("Osservazioni:")
            notes.forEach { appendLine("• $it") }
        }
    }
}
