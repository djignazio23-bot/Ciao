package com.peugeot208technician.app

import kotlin.math.abs

object PeugeotAdvisor {
    fun explainDtc(code: String): String = when (code.uppercase()) {
        "P050B" -> "P050B — prestazione anticipo accensione durante avviamento a freddo. Non indica da solo un componente guasto: controllare plausibilità temperature, alimentazione/tensione, aria aspirata, accensione, correlazione distribuzione e altri DTC presenti. Usa il recorder COLD START prima di cancellare il codice."
        "P0300" -> "P0300 — mancate accensioni casuali/multiple. Valutare candele/bobine, miscela, iniezione, compressione e altri codici associati."
        "P0171" -> "P0171 — miscela troppo magra banco 1. Confrontare STFT/LTFT, aspirazione, pressione/alimentazione carburante e sensori aria."
        "P0420" -> "P0420 — efficienza catalizzatore sotto soglia. Non sostituire il catalizzatore senza verificare prima combustione, sonde e altri DTC."
        "U1F1A" -> "U1F1A — codice di rete/manufacturer-specific PSA/Stellantis. Questa build non assegna una descrizione non verificata: per il significato ECU-specifico serve documentazione/diagnostica PSA compatibile."
        else -> if (code.startsWith("U1") || code.startsWith("P1")) {
            "$code — codice manufacturer-specific: conservarne freeze-frame/contesto e non dedurre il componente solo dal numero."
        } else "$code — DTC OBD-II. Interpretalo insieme a freeze-frame, live data e sintomi reali."
    }

    fun analyze(snapshot: LiveSnapshot, dtcs: List<String> = emptyList()): String = buildString {
        appendLine("Analisi mirata — ${Peugeot208Profile.VEHICLE}")
        appendLine()
        val rpm = snapshot.rpm
        val running = rpm != null && rpm > 400

        snapshot.ecuVoltageV?.let {
            if (!running && it < 11.8) appendLine("• Tensione ECU bassa a motore spento (${fmt(it)} V): una batteria debole può generare anomalie di avviamento/rete.")
            if (running && it < 13.0) appendLine("• Tensione ECU contenuta a motore avviato (${fmt(it)} V): verificare il sistema di ricarica prima di inseguire DTC secondari.")
        }

        val ect = snapshot.coolantC
        val iat = snapshot.intakeC
        if (!running && ect != null && iat != null && abs(ect - iat) > 15.0) {
            appendLine("• A motore freddo ECT e IAT differiscono di ${fmt(abs(ect - iat))} °C: controllare plausibilità sensori/condizioni ambientali. È rilevante per P050B.")
        }

        val combinedTrim = listOfNotNull(snapshot.stftPct, snapshot.ltftPct).sum()
        if (running && combinedTrim > 15.0) appendLine("• Correzione carburazione complessiva positiva (~${fmt(combinedTrim)}%): possibile tendenza magra. È un indizio, non una diagnosi.")
        if (running && combinedTrim < -15.0) appendLine("• Correzione carburazione complessiva negativa (~${fmt(combinedTrim)}%): possibile tendenza ricca. È un indizio, non una diagnosi.")

        snapshot.coolantC?.let { if (it > 115) appendLine("• Temperatura liquido elevata (${fmt(it)} °C): interrompere test gravosi e verificare raffreddamento.") }

        if (dtcs.isNotEmpty()) {
            appendLine()
            appendLine("DTC:")
            dtcs.distinct().forEach { appendLine("• ${explainDtc(it)}") }
        }

        if (length < 120) appendLine("• Nessun indicatore evidente nei parametri standard letti. Registra il difetto nel momento in cui si presenta.")
        appendLine()
        appendLine("Limiti: OBD-II standard non misura direttamente frizione/cambio, stato fisico cinghia, rumorosità meccaniche o tutti i parametri PSA proprietari.")
    }

    fun analyzeColdStart(rows: List<LiveSnapshot>): String {
        if (rows.isEmpty()) return "Nessun campione COLD START disponibile."
        val first = rows.first()
        val runningRows = rows.filter { (it.rpm ?: 0.0) > 400 }
        val firstRunning = runningRows.firstOrNull()
        val maxRpm = runningRows.mapNotNull { it.rpm }.maxOrNull()
        val minVoltage = rows.mapNotNull { it.ecuVoltageV ?: it.adapterVoltageV }.minOrNull()
        val maxTrim = runningRows.map { listOfNotNull(it.stftPct, it.ltftPct).sum() }.maxOrNull()
        return buildString {
            appendLine("REPORT AVVIAMENTO A FREDDO — ${Peugeot208Profile.VEHICLE}")
            appendLine("Campioni: ${rows.size}")
            appendLine("ECT iniziale: ${first.coolantC?.let(::fmt) ?: "n/d"} °C")
            appendLine("IAT iniziale: ${first.intakeC?.let(::fmt) ?: "n/d"} °C")
            firstRunning?.let { appendLine("ECT al primo rilevamento motore acceso: ${it.coolantC?.let(::fmt) ?: "n/d"} °C") }
            appendLine("RPM massimo iniziale: ${maxRpm?.let(::fmt) ?: "n/d"}")
            appendLine("Tensione minima osservata: ${minVoltage?.let(::fmt) ?: "n/d"} V")
            appendLine("Massima somma STFT+LTFT osservata: ${maxTrim?.let(::fmt) ?: "n/d"} %")
            appendLine()
            if (first.coolantC != null && first.intakeC != null && abs(first.coolantC - first.intakeC) > 15.0) {
                appendLine("• ECT/IAT iniziali poco coerenti tra loro: dato da approfondire nel percorso P050B.")
            }
            if (minVoltage != null && minVoltage < 10.0) appendLine("• Caduta di tensione marcata durante l'avviamento: controllare batteria/connessioni prima di interpretare anomalie elettroniche secondarie.")
            if (maxTrim != null && maxTrim > 20.0) appendLine("• Fuel trim molto positivo in parte del test: verificare aspirazione/alimentazione e ripetibilità a freddo.")
            appendLine("• Per P050B confrontare questo report con DTC presenti/pending e con il comportamento realmente avvertito a freddo.")
        }
    }

    private fun fmt(v: Double) = "%.1f".format(v)
}
