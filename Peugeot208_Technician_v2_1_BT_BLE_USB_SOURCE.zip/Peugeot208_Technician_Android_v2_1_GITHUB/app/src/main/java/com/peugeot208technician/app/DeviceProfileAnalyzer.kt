package com.peugeot208technician.app

import android.hardware.usb.UsbConstants

data class DeviceTechnicalProfile(
    val likelyType: String,
    val confidence: String,
    val findings: List<String>,
    val safeNextSteps: List<String>,
    val limitations: List<String>
) {
    fun humanReadable(): String = buildString {
        appendLine("PROFILO TECNICO DEL DISPOSITIVO")
        appendLine("Tipo probabile: $likelyType")
        appendLine("Confidenza: $confidence")
        appendLine()
        appendLine("Elementi osservati:")
        findings.forEach { appendLine("• $it") }
        appendLine()
        appendLine("Passi sicuri consigliati:")
        safeNextSteps.forEach { appendLine("• $it") }
        appendLine()
        appendLine("Limiti importanti:")
        limitations.forEach { appendLine("• $it") }
    }
}

object DeviceProfileAnalyzer {
    fun analyze(report: UsbScanReport): DeviceTechnicalProfile {
        val classes = report.interfaces.map { it.interfaceClass }.toSet()
        val adb = report.interfaces.any {
            it.interfaceClass == UsbConstants.USB_CLASS_VENDOR_SPEC &&
                    it.subclass == 0x42 && it.protocol == 0x01
        }
        val cdc = UsbConstants.USB_CLASS_COMM in classes || UsbConstants.USB_CLASS_CDC_DATA in classes
        val audio = UsbConstants.USB_CLASS_AUDIO in classes
        val storage = UsbConstants.USB_CLASS_MASS_STORAGE in classes
        val image = UsbConstants.USB_CLASS_STILL_IMAGE in classes
        val hid = UsbConstants.USB_CLASS_HID in classes
        val video = UsbConstants.USB_CLASS_VIDEO in classes
        val vendor = UsbConstants.USB_CLASS_VENDOR_SPEC in classes

        val nameText = listOfNotNull(report.manufacturer, report.product).joinToString(" ").lowercase()
        val carHint = listOf("radio", "head unit", "infotainment", "car", "automotive", "android")
            .any { it in nameText }

        val findings = mutableListOf<String>()
        if (audio) findings += "Interfaccia USB Audio rilevata."
        if (storage) findings += "Interfaccia Mass Storage rilevata."
        if (image) findings += "Interfaccia Still Image/PTP-MTP compatibile rilevata."
        if (cdc) findings += "Interfaccia CDC/seriale rilevata: potrebbe esporre log o console documentata."
        if (hid) findings += "Interfaccia HID rilevata."
        if (video) findings += "Interfaccia USB Video rilevata."
        if (adb) findings += "Pattern di interfaccia ADB Android rilevato (vendor-specific / sub 0x42 / proto 0x01)."
        else if (vendor) findings += "Interfaccia proprietaria/vendor-specific rilevata."
        if (carHint) findings += "Nome produttore/prodotto compatibile con apparato automotive/Android."
        if (report.interfaces.any { i -> i.endpoints.any { it.direction == "OUT" } }) {
            findings += "Sono presenti endpoint OUT; la sola presenza non rende sicuro inviare dati."
        }
        if (findings.isEmpty()) findings += "Dai soli descrittori USB non emerge un profilo standard specifico."

        val (type, confidence) = when {
            adb && (audio || image || storage || carHint) -> "Possibile head-unit/autoradio Peugeot basata su Android o dispositivo di servizio" to "alta"
            adb -> "Dispositivo Android con interfaccia ADB esposta" to "alta"
            cdc && carHint -> "Possibile elettronica Peugeot/automotive con porta seriale/CDC" to "media"
            audio && carHint -> "Possibile autoradio Peugeot/interfaccia audio USB" to "media"
            audio -> "Dispositivo USB Audio" to "alta"
            cdc -> "Dispositivo seriale/CDC USB" to "alta"
            storage && image -> "Dispositivo multimediale MTP/PTP + storage" to "media"
            storage -> "Dispositivo Mass Storage" to "alta"
            hid -> "Dispositivo HID" to "alta"
            vendor -> "Dispositivo con protocollo proprietario" to "media-bassa"
            else -> "Dispositivo USB generico" to "bassa"
        }

        val next = mutableListOf<String>()
        next += "Conservare questo report VID:PID e le classi/interfacce prima di qualunque test attivo."
        if (cdc) next += "Se conosci baud/protocollo del costruttore, puoi aprire manualmente la seriale; l'app non trasmette nulla automaticamente."
        if (adb) next += "Se è una tua head-unit Android, verifica sul dispositivo che il debug USB sia abilitato e autorizzato prima di qualsiasi sessione ADB."
        if (storage) next += "Se il dispositivo espone memoria, eseguire prima una copia dei dati/configurazioni leggibili prima di modificarli."
        if (vendor) next += "Per le interfacce proprietarie usa documentazione del produttore o protocollo noto; niente probing casuale."
        if (!cdc && !adb) next += "Identificare marca/modello e porta di servizio documentata per andare oltre i descrittori USB."

        val limits = listOf(
            "La normale porta USB multimediale della Peugeot, come molte autoradio rende la radio HOST e il telefono DEVICE: in quel caso Android non può enumerare internamente la radio come periferica USB.",
            "Per una diagnosi profonda può servire una vera porta service/device della radio, oppure un adattatore USB-UART/CAN/OBD appropriato e documentato.",
            "L'app non esegue flash firmware, erase, reset, brute force, bypass di protezioni o comandi proprietari automatici."
        )

        return DeviceTechnicalProfile(type, confidence, findings, next, limits)
    }
}
