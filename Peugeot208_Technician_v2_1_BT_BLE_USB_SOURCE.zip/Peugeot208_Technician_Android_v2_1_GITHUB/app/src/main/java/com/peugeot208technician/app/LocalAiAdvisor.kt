package com.peugeot208technician.app

import com.google.mlkit.genai.prompt.DownloadStatus
import com.google.mlkit.genai.prompt.FeatureStatus
import com.google.mlkit.genai.prompt.Generation

/**
 * AI locale opzionale. Riceve soltanto testo diagnostico e non ha accesso
 * a UsbManager/Elm327UsbClient: non può inviare comandi alla vettura.
 */
class LocalAiAdvisor {
    private val model = Generation.getClient()

    suspend fun prepare(onStatus: (String) -> Unit): Boolean = try {
        when (val status = model.checkStatus()) {
            FeatureStatus.AVAILABLE -> { onStatus("AI locale disponibile."); true }
            FeatureStatus.DOWNLOADABLE -> {
                onStatus("AI locale scaricabile: avvio download gestito da Android…")
                var ready = false
                model.download().collect { d ->
                    when (d) {
                        is DownloadStatus.DownloadStarted -> onStatus("Download AI iniziato…")
                        is DownloadStatus.DownloadProgress -> onStatus("Download AI: ${d.totalBytesDownloaded} byte")
                        DownloadStatus.DownloadCompleted -> { ready = true; onStatus("AI locale pronta.") }
                        is DownloadStatus.DownloadFailed -> onStatus("Download AI fallito: ${d.e.message}")
                    }
                }
                ready
            }
            FeatureStatus.DOWNLOADING -> { onStatus("AI locale già in download."); false }
            FeatureStatus.UNAVAILABLE -> { onStatus("Gemini Nano non disponibile: resta attivo l'advisor offline."); false }
            else -> { onStatus("Stato AI: $status"); false }
        }
    } catch (e: Exception) {
        onStatus("AI locale non disponibile: ${e.message}. Uso advisor offline.")
        false
    }

    suspend fun analyze(question: String, context: String): String? {
        return try {
            if (model.checkStatus() != FeatureStatus.AVAILABLE) null
            else {
                val prompt = """
                    Sei un assistente diagnostico per una ${Peugeot208Profile.VEHICLE}.
                    Interpreta esclusivamente i dati OBD-II forniti. Distingui fatti, ipotesi e verifiche successive.
                    Non inventare PID PSA, pinout, codici UDS, security access, procedure di coding o firmware.
                    Non suggerire di cancellare DTC prima di registrare contesto e freeze-frame/live data.
                    Se il problema è meccanico (frizione, cambio, cinghia fisica, rumore) dichiaralo chiaramente.
                    La build usa soltanto OBD-II standard e un ELM327 compatibile.

                    DOMANDA:
                    $question

                    DATI:
                    $context
                """.trimIndent()
                model.generateContent(prompt).candidates.firstOrNull()?.text
            }
        } catch (_: Exception) { null }
    }
}
