package com.peugeot208technician.app

import android.Manifest
import android.annotation.SuppressLint
import android.bluetooth.BluetoothDevice
import android.bluetooth.BluetoothGatt
import android.bluetooth.BluetoothGattCallback
import android.bluetooth.BluetoothGattCharacteristic
import android.bluetooth.BluetoothGattDescriptor
import android.bluetooth.BluetoothGattService
import android.bluetooth.BluetoothManager
import android.bluetooth.BluetoothProfile
import android.bluetooth.le.ScanCallback
import android.bluetooth.le.ScanResult
import android.content.Context
import android.content.pm.PackageManager
import android.hardware.usb.UsbDevice
import android.hardware.usb.UsbManager
import android.os.Build
import androidx.core.content.ContextCompat
import com.hoho.android.usbserial.driver.UsbSerialPort
import com.hoho.android.usbserial.driver.UsbSerialProber
import kotlinx.coroutines.delay
import kotlinx.coroutines.suspendCancellableCoroutine
import kotlinx.coroutines.withTimeout
import java.io.IOException
import java.util.UUID
import java.util.concurrent.ConcurrentHashMap
import kotlin.coroutines.resume

/**
 * ELM327 transport client for Peugeot 208 Technician.
 *
 * Supported transports:
 *  - USB serial/OTG
 *  - Bluetooth Classic RFCOMM/SPP
 *  - Bluetooth Low Energy GATT (heuristic discovery of write + notify characteristics)
 *
 * The higher-level OBD command set is intentionally limited to normal ELM/OBD diagnostics.
 */
class Elm327UsbClient(private val context: Context) {
    enum class TransportKind { NONE, USB, BLUETOOTH_CLASSIC, BLUETOOTH_LE }

    data class BleCandidate(
        val device: BluetoothDevice,
        val name: String,
        val address: String,
        val rssi: Int
    )

    private val usbManager = context.getSystemService(Context.USB_SERVICE) as UsbManager
    private val bluetoothManager = context.getSystemService(Context.BLUETOOTH_SERVICE) as BluetoothManager
    private val bluetoothAdapter get() = bluetoothManager.adapter

    private var port: UsbSerialPort? = null
    private var classicSocket: android.bluetooth.BluetoothSocket? = null
    private var bleGatt: BluetoothGatt? = null
    private var bleWriteCharacteristic: BluetoothGattCharacteristic? = null
    private var bleNotifyCharacteristic: BluetoothGattCharacteristic? = null
    private val bleLock = Object()
    private val bleBuffer = StringBuilder()
    @Volatile private var bleConnected = false
    @Volatile private var bleServicesReady = false
    @Volatile private var transport = TransportKind.NONE

    fun isOpen(): Boolean = when (transport) {
        TransportKind.USB -> port != null
        TransportKind.BLUETOOTH_CLASSIC -> classicSocket?.isConnected == true
        TransportKind.BLUETOOTH_LE -> bleConnected && bleGatt != null && bleWriteCharacteristic != null && bleNotifyCharacteristic != null
        else -> false
    }

    fun transportKind(): TransportKind = transport

    fun transportLabel(): String = when (transport) {
        TransportKind.USB -> "USB/OTG"
        TransportKind.BLUETOOTH_CLASSIC -> "Bluetooth classico (SPP)"
        TransportKind.BLUETOOTH_LE -> "Bluetooth Low Energy (BLE)"
        else -> "nessuno"
    }

    fun compatibleDevices(): List<UsbDevice> = usbManager.deviceList.values
        .filter { UsbSerialProber.getDefaultProber().probeDevice(it) != null }

    fun bluetoothAvailable(): Boolean = bluetoothAdapter != null

    @SuppressLint("MissingPermission")
    fun bluetoothEnabled(): Boolean = try { bluetoothAdapter?.isEnabled == true } catch (_: SecurityException) { false }

    private fun hasBtConnectPermission(): Boolean =
        Build.VERSION.SDK_INT < Build.VERSION_CODES.S ||
            ContextCompat.checkSelfPermission(context, Manifest.permission.BLUETOOTH_CONNECT) == PackageManager.PERMISSION_GRANTED

    private fun hasBtScanPermission(): Boolean =
        Build.VERSION.SDK_INT < Build.VERSION_CODES.S ||
            ContextCompat.checkSelfPermission(context, Manifest.permission.BLUETOOTH_SCAN) == PackageManager.PERMISSION_GRANTED

    @SuppressLint("MissingPermission")
    fun bondedClassicDevices(): List<BluetoothDevice> {
        if (!hasBtConnectPermission()) return emptyList()
        return try {
            bluetoothAdapter?.bondedDevices?.sortedBy { safeDeviceName(it) } ?: emptyList()
        } catch (_: SecurityException) { emptyList() }
    }

    @SuppressLint("MissingPermission")
    fun safeDeviceName(device: BluetoothDevice): String = try {
        if (hasBtConnectPermission()) device.name ?: "Bluetooth" else "Bluetooth"
    } catch (_: SecurityException) { "Bluetooth" }

    @SuppressLint("MissingPermission")
    fun safeAddress(device: BluetoothDevice): String = try { device.address ?: "?" } catch (_: SecurityException) { "?" }

    /** Passive BLE discovery. No GATT connection and no writes occur during scanning. */
    @SuppressLint("MissingPermission")
    suspend fun scanBle(timeoutMs: Long = 6500L): List<BleCandidate> {
        if (!hasBtScanPermission()) throw IOException("Permesso Bluetooth SCAN non concesso")
        val adapter = bluetoothAdapter ?: throw IOException("Bluetooth non disponibile sul telefono")
        if (!adapter.isEnabled) throw IOException("Bluetooth disattivato")
        val scanner = adapter.bluetoothLeScanner ?: throw IOException("Scanner BLE non disponibile")
        val found = ConcurrentHashMap<String, BleCandidate>()
        val callback = object : ScanCallback() {
            override fun onScanResult(callbackType: Int, result: ScanResult) {
                val d = result.device ?: return
                val address = try { d.address } catch (_: SecurityException) { return }
                val advertisedName = result.scanRecord?.deviceName
                val name = advertisedName ?: safeDeviceName(d)
                found[address] = BleCandidate(d, name, address, result.rssi)
            }

            override fun onBatchScanResults(results: MutableList<ScanResult>) {
                results.forEach { onScanResult(0, it) }
            }
        }
        scanner.startScan(callback)
        try { delay(timeoutMs) } finally { try { scanner.stopScan(callback) } catch (_: Exception) {} }
        return found.values.sortedWith(compareByDescending<BleCandidate> { likelyObdName(it.name) }.thenByDescending { it.rssi })
    }

    private fun likelyObdName(name: String): Boolean {
        val n = name.uppercase()
        return listOf("OBD", "ELM", "V-LINK", "VLINK", "VGATE", "CARISTA", "KONNWEI", "OBDLINK").any { it in n }
    }

    @Throws(IOException::class)
    fun open(device: UsbDevice, baud: Int) {
        close()
        val driver = UsbSerialProber.getDefaultProber().probeDevice(device)
            ?: throw IOException("Adattatore USB-seriale non riconosciuto")
        val connection = usbManager.openDevice(device)
            ?: throw IOException("Permesso USB non disponibile")
        val p = driver.ports.firstOrNull() ?: throw IOException("Nessuna porta seriale")
        try {
            p.open(connection)
            p.setParameters(baud, 8, UsbSerialPort.STOPBITS_1, UsbSerialPort.PARITY_NONE)
            try { p.dtr = false } catch (_: Exception) {}
            try { p.rts = false } catch (_: Exception) {}
            port = p
            transport = TransportKind.USB
        } catch (e: Exception) {
            try { p.close() } catch (_: Exception) {}
            try { connection.close() } catch (_: Exception) {}
            throw e
        }
    }

    @SuppressLint("MissingPermission")
    @Throws(IOException::class)
    fun openBluetoothClassic(device: BluetoothDevice) {
        if (!hasBtConnectPermission()) throw IOException("Permesso Bluetooth CONNECT non concesso")
        close()
        val uuid = UUID.fromString(SPP_UUID)
        var last: Exception? = null
        val attempts = listOf<(BluetoothDevice) -> android.bluetooth.BluetoothSocket>(
            { it.createRfcommSocketToServiceRecord(uuid) },
            { it.createInsecureRfcommSocketToServiceRecord(uuid) }
        )
        for (factory in attempts) {
            var socket: android.bluetooth.BluetoothSocket? = null
            try {
                try { bluetoothAdapter?.cancelDiscovery() } catch (_: Exception) {}
                socket = factory(device)
                socket.connect()
                classicSocket = socket
                transport = TransportKind.BLUETOOTH_CLASSIC
                return
            } catch (e: Exception) {
                last = e
                try { socket?.close() } catch (_: Exception) {}
            }
        }
        throw IOException("Connessione SPP fallita: ${last?.message ?: "adattatore non raggiungibile"}", last)
    }

    @SuppressLint("MissingPermission")
    suspend fun openBluetoothLe(device: BluetoothDevice, timeoutMs: Long = 9000L) {
        if (!hasBtConnectPermission()) throw IOException("Permesso Bluetooth CONNECT non concesso")
        close()
        bleConnected = false
        bleServicesReady = false
        bleWriteCharacteristic = null
        bleNotifyCharacteristic = null
        bleBuffer.clear()

        val result = withTimeout(timeoutMs) { suspendCancellableCoroutine<Result<Unit>> { cont ->
            val callback = object : BluetoothGattCallback() {
                override fun onConnectionStateChange(gatt: BluetoothGatt, status: Int, newState: Int) {
                    if (status != BluetoothGatt.GATT_SUCCESS) {
                        if (cont.isActive) cont.resume(Result.failure(IOException("BLE status=$status")))
                        return
                    }
                    if (newState == BluetoothProfile.STATE_CONNECTED) {
                        bleConnected = true
                        gatt.discoverServices()
                    } else if (newState == BluetoothProfile.STATE_DISCONNECTED) {
                        bleConnected = false
                        synchronized(bleLock) { bleLock.notifyAll() }
                        if (cont.isActive) cont.resume(Result.failure(IOException("BLE disconnesso")))
                    }
                }

                override fun onServicesDiscovered(gatt: BluetoothGatt, status: Int) {
                    if (status != BluetoothGatt.GATT_SUCCESS) {
                        if (cont.isActive) cont.resume(Result.failure(IOException("Service discovery BLE fallita: $status")))
                        return
                    }
                    val pair = chooseBleCharacteristics(gatt.services)
                    if (pair == null) {
                        if (cont.isActive) cont.resume(Result.failure(IOException("Nessuna coppia GATT write + notify adatta a un ELM327 BLE")))
                        return
                    }
                    bleWriteCharacteristic = pair.first
                    bleNotifyCharacteristic = pair.second
                    tryEnableNotifications(gatt, pair.second)
                    bleServicesReady = true
                    if (cont.isActive) cont.resume(Result.success(Unit))
                }

                override fun onCharacteristicChanged(gatt: BluetoothGatt, characteristic: BluetoothGattCharacteristic) {
                    @Suppress("DEPRECATION")
                    val bytes = characteristic.value ?: return
                    appendBle(bytes)
                }

                override fun onCharacteristicChanged(gatt: BluetoothGatt, characteristic: BluetoothGattCharacteristic, value: ByteArray) {
                    appendBle(value)
                }
            }

            val gatt = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
                device.connectGatt(context, false, callback, BluetoothDevice.TRANSPORT_LE)
            } else {
                @Suppress("DEPRECATION")
                device.connectGatt(context, false, callback)
            }
            bleGatt = gatt
            cont.invokeOnCancellation { try { gatt.disconnect(); gatt.close() } catch (_: Exception) {} }
        } }

        result.getOrThrow()
        if (!bleServicesReady) {
            close()
            throw IOException("Timeout inizializzazione BLE")
        }
        transport = TransportKind.BLUETOOTH_LE
        delay(350)
    }

    private fun appendBle(bytes: ByteArray) {
        synchronized(bleLock) {
            bleBuffer.append(String(bytes, Charsets.US_ASCII))
            bleLock.notifyAll()
        }
    }

    private fun chooseBleCharacteristics(services: List<BluetoothGattService>): Pair<BluetoothGattCharacteristic, BluetoothGattCharacteristic>? {
        val chars = services.flatMap { it.characteristics }
        if (chars.isEmpty()) return null

        fun writable(c: BluetoothGattCharacteristic): Boolean =
            c.properties and (BluetoothGattCharacteristic.PROPERTY_WRITE or BluetoothGattCharacteristic.PROPERTY_WRITE_NO_RESPONSE) != 0
        fun notifiable(c: BluetoothGattCharacteristic): Boolean =
            c.properties and (BluetoothGattCharacteristic.PROPERTY_NOTIFY or BluetoothGattCharacteristic.PROPERTY_INDICATE) != 0

        val preferredWrite = listOf(
            "6e400002-b5a3-f393-e0a9-e50e24dcca9e", // Nordic UART RX
            "0000ffe1-0000-1000-8000-00805f9b34fb",
            "0000fff1-0000-1000-8000-00805f9b34fb"
        )
        val preferredNotify = listOf(
            "6e400003-b5a3-f393-e0a9-e50e24dcca9e", // Nordic UART TX
            "0000ffe1-0000-1000-8000-00805f9b34fb",
            "0000fff1-0000-1000-8000-00805f9b34fb"
        )

        val write = preferredWrite.asSequence().mapNotNull { u -> chars.firstOrNull { it.uuid.toString().equals(u, true) && writable(it) } }.firstOrNull()
            ?: chars.firstOrNull { writable(it) }
        val notify = preferredNotify.asSequence().mapNotNull { u -> chars.firstOrNull { it.uuid.toString().equals(u, true) && notifiable(it) } }.firstOrNull()
            ?: chars.firstOrNull { notifiable(it) }
        if (write == null || notify == null) return null
        return write to notify
    }

    @SuppressLint("MissingPermission")
    private fun tryEnableNotifications(gatt: BluetoothGatt, characteristic: BluetoothGattCharacteristic) {
        gatt.setCharacteristicNotification(characteristic, true)
        val descriptor = characteristic.getDescriptor(UUID.fromString(CCCD_UUID)) ?: return
        val enableValue = if (characteristic.properties and BluetoothGattCharacteristic.PROPERTY_INDICATE != 0)
            BluetoothGattDescriptor.ENABLE_INDICATION_VALUE else BluetoothGattDescriptor.ENABLE_NOTIFICATION_VALUE
        if (Build.VERSION.SDK_INT >= 33) {
            gatt.writeDescriptor(descriptor, enableValue)
        } else {
            @Suppress("DEPRECATION")
            descriptor.value = enableValue
            @Suppress("DEPRECATION")
            gatt.writeDescriptor(descriptor)
        }
    }

    fun close() {
        try { port?.close() } catch (_: Exception) {}
        port = null
        try { classicSocket?.close() } catch (_: Exception) {}
        classicSocket = null
        try { bleGatt?.disconnect() } catch (_: Exception) {}
        try { bleGatt?.close() } catch (_: Exception) {}
        bleGatt = null
        bleWriteCharacteristic = null
        bleNotifyCharacteristic = null
        bleConnected = false
        bleServicesReady = false
        synchronized(bleLock) { bleBuffer.clear(); bleLock.notifyAll() }
        transport = TransportKind.NONE
    }

    @Synchronized
    fun command(command: String, timeoutMs: Int = 1800): String {
        return when (transport) {
            TransportKind.USB -> commandUsb(command, timeoutMs)
            TransportKind.BLUETOOTH_CLASSIC -> commandClassic(command, timeoutMs)
            TransportKind.BLUETOOTH_LE -> commandBle(command, timeoutMs)
            else -> throw IOException("ELM327 non connesso")
        }
    }

    private fun commandUsb(command: String, timeoutMs: Int): String {
        val p = port ?: throw IOException("ELM327 USB non connesso")
        try {
            val junk = ByteArray(1024)
            repeat(2) { p.read(junk, 30) }
        } catch (_: Exception) {}
        p.write((command.trim() + "\r").toByteArray(Charsets.US_ASCII), 1200)
        val out = StringBuilder()
        val buf = ByteArray(1024)
        val deadline = System.currentTimeMillis() + timeoutMs
        while (System.currentTimeMillis() < deadline) {
            try {
                val n = p.read(buf, 220)
                if (n > 0) {
                    val s = String(buf, 0, n, Charsets.US_ASCII)
                    out.append(s)
                    if ('>' in s) break
                }
            } catch (_: Exception) {}
        }
        return out.toString().trim()
    }

    private fun commandClassic(command: String, timeoutMs: Int): String {
        val socket = classicSocket ?: throw IOException("ELM327 Bluetooth non connesso")
        val input = socket.inputStream
        val output = socket.outputStream
        try { while (input.available() > 0) input.read(ByteArray(minOf(1024, input.available()))) } catch (_: Exception) {}
        output.write((command.trim() + "\r").toByteArray(Charsets.US_ASCII))
        output.flush()
        val out = StringBuilder()
        val buf = ByteArray(1024)
        val deadline = System.currentTimeMillis() + timeoutMs
        while (System.currentTimeMillis() < deadline) {
            if (input.available() > 0) {
                val n = input.read(buf)
                if (n > 0) {
                    val s = String(buf, 0, n, Charsets.US_ASCII)
                    out.append(s)
                    if ('>' in s) break
                }
            } else {
                Thread.sleep(18)
            }
        }
        return out.toString().trim()
    }

    @SuppressLint("MissingPermission")
    private fun commandBle(command: String, timeoutMs: Int): String {
        val gatt = bleGatt ?: throw IOException("ELM327 BLE non connesso")
        val write = bleWriteCharacteristic ?: throw IOException("Caratteristica BLE TX assente")
        synchronized(bleLock) { bleBuffer.clear() }
        val bytes = (command.trim() + "\r").toByteArray(Charsets.US_ASCII)
        val writeType = if (write.properties and BluetoothGattCharacteristic.PROPERTY_WRITE_NO_RESPONSE != 0)
            BluetoothGattCharacteristic.WRITE_TYPE_NO_RESPONSE else BluetoothGattCharacteristic.WRITE_TYPE_DEFAULT
        val ok = if (Build.VERSION.SDK_INT >= 33) {
            gatt.writeCharacteristic(write, bytes, writeType) == android.bluetooth.BluetoothStatusCodes.SUCCESS
        } else {
            @Suppress("DEPRECATION")
            write.writeType = writeType
            @Suppress("DEPRECATION")
            write.value = bytes
            @Suppress("DEPRECATION")
            gatt.writeCharacteristic(write)
        }
        if (!ok) throw IOException("Invio BLE rifiutato dal dispositivo")

        val deadline = System.currentTimeMillis() + timeoutMs
        synchronized(bleLock) {
            while (System.currentTimeMillis() < deadline) {
                if ('>' in bleBuffer) break
                val remaining = deadline - System.currentTimeMillis()
                if (remaining <= 0) break
                try { bleLock.wait(minOf(remaining, 180L)) } catch (_: InterruptedException) { break }
            }
            return bleBuffer.toString().trim()
        }
    }

    fun initialize(): ElmInfo {
        val reset = command("ATZ", 3500)
        Thread.sleep(450)
        command("ATE0")
        command("ATL0")
        command("ATS0")
        command("ATH0")
        command("ATAT1")
        command("ATSP0")
        val identity = command("ATI").lineSequence().firstOrNull { it.isNotBlank() && ">" !in it }?.trim()
            ?: reset.lineSequence().firstOrNull { it.isNotBlank() }?.trim().orEmpty()
        command("0100", 4500)
        val protocol = cleanText(command("ATDP"))
        val voltage = cleanText(command("ATRV"))
        val vin = readVin()
        val calibrationId = readCalibrationId()
        val cvn = readCvn()
        return ElmInfo(identity.ifBlank { "ELM327/compatibile" }, protocol, voltage, vin, calibrationId, cvn)
    }

    fun readVin(): String? = ObdDecoders.parseVin(command("0902", 3500))
    fun readCalibrationId(): String? = ObdDecoders.parseMode09Ascii(command("0904", 3500), 0x04)
    fun readCvn(): String? = ObdDecoders.parseCvn(command("0906", 3500))

    fun supportedPids(): Set<Int> {
        val result = linkedSetOf<Int>()
        val bases = listOf(0x00, 0x20, 0x40, 0x60)
        for (base in bases) {
            val response = command("01%02X".format(base), 2200)
            val set = ObdDecoders.supportedPids(response, base)
            result += set
            if (base > 0 && set.isEmpty()) break
            if ((base + 0x20) !in set && base >= 0x20) break
        }
        return result
    }

    fun readLiveSnapshot(): LiveSnapshot {
        fun pid(id: Int): Double? = try {
            val raw = command("01%02X".format(id), 1600)
            if (ObdDecoders.isNoData(raw)) null else ObdDecoders.pidValue(raw, id)
        } catch (_: Exception) { null }

        val adapterV = try { ObdDecoders.parseVoltage(command("ATRV", 1000)) } catch (_: Exception) { null }
        return LiveSnapshot(
            rpm = pid(0x0C), speedKmh = pid(0x0D), coolantC = pid(0x05), intakeC = pid(0x0F),
            timingAdvanceDeg = pid(0x0E), engineLoadPct = pid(0x04), stftPct = pid(0x06), ltftPct = pid(0x07),
            mapKpa = pid(0x0B), mafGps = pid(0x10), throttlePct = pid(0x11), fuelLevelPct = pid(0x2F),
            ecuVoltageV = pid(0x42), adapterVoltageV = adapterV
        )
    }

    fun readDtcReport(): DtcReport {
        val confirmed = ObdDecoders.parseDtcs(command("03", 3000), 0x43)
        val pending = ObdDecoders.parseDtcs(command("07", 3000), 0x47)
        val permanent = ObdDecoders.parseDtcs(command("0A", 3000), 0x4A)
        return DtcReport(confirmed, pending, permanent)
    }

    fun clearDtcs(): String = command("04", 3000)

    private fun cleanText(raw: String): String = raw.replace(">", "").lineSequence()
        .map { it.trim() }.filter { it.isNotBlank() }.joinToString(" ")

    companion object {
        private const val SPP_UUID = "00001101-0000-1000-8000-00805F9B34FB"
        private const val CCCD_UUID = "00002902-0000-1000-8000-00805f9b34fb"
    }
}
