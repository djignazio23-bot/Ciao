package com.peugeot208technician.app

import android.Manifest
import android.app.PendingIntent
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.bluetooth.BluetoothDevice
import android.hardware.usb.UsbDevice
import android.hardware.usb.UsbManager
import android.os.Build
import android.os.Bundle
import android.view.View
import android.widget.ArrayAdapter
import android.widget.EditText
import android.widget.Toast
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.activity.result.contract.ActivityResultContracts
import androidx.core.content.ContextCompat
import androidx.lifecycle.lifecycleScope
import com.peugeot208technician.app.databinding.ActivityMainBinding
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.time.Instant
import java.time.ZoneId
import java.time.format.DateTimeFormatter

class MainActivity : AppCompatActivity() {
    private lateinit var binding: ActivityMainBinding
    private lateinit var usbManager: UsbManager
    private lateinit var elm: Elm327UsbClient
    private lateinit var radioScanner: SafeUsbScanner
    private val localAi = LocalAiAdvisor()

    private enum class EndpointKind { USB, BLUETOOTH_CLASSIC, BLUETOOTH_LE }
    private data class ObdEndpoint(
        val kind: EndpointKind,
        val label: String,
        val usb: UsbDevice? = null,
        val bluetooth: BluetoothDevice? = null
    )

    private var endpoints: List<ObdEndpoint> = emptyList()
    private var radioDevices: List<UsbDevice> = emptyList()
    private var pendingDevice: UsbDevice? = null
    private var pendingBaud: Int = 38400
    private var elmInfo: ElmInfo? = null
    private var lastSnapshot: LiveSnapshot? = null
    private var lastDtc: DtcReport? = null
    private val coldRows = mutableListOf<LiveSnapshot>()
    private var coldStartedAt = 0L
    private var liveJob: Job? = null
    private var coldJob: Job? = null
    private val appLog = StringBuilder()
    private val timeFmt = DateTimeFormatter.ofPattern("HH:mm:ss")

    private val bluetoothPermissionLauncher =
        registerForActivityResult(ActivityResultContracts.RequestMultiplePermissions()) { grants ->
            val ok = grants.values.all { it }
            if (ok) {
                log("Permessi Bluetooth concessi")
                refreshDevices()
            } else {
                toast("Permessi Bluetooth non concessi. L'USB continua a funzionare.")
                log("Permessi Bluetooth negati")
            }
        }

    private val usbPermissionReceiver = object : BroadcastReceiver() {
        override fun onReceive(context: Context?, intent: Intent?) {
            if (intent?.action != ACTION_USB_PERMISSION) return
            val granted = intent.getBooleanExtra(UsbManager.EXTRA_PERMISSION_GRANTED, false)
            val device = pendingDevice
            pendingDevice = null
            if (granted && device != null) connectNow(ObdEndpoint(EndpointKind.USB, "USB", usb = device), pendingBaud)
            else toast("Permesso USB negato")
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)
        usbManager = getSystemService(Context.USB_SERVICE) as UsbManager
        elm = Elm327UsbClient(this)
        radioScanner = SafeUsbScanner(usbManager)

        ContextCompat.registerReceiver(
            this,
            usbPermissionReceiver,
            IntentFilter(ACTION_USB_PERMISSION),
            ContextCompat.RECEIVER_NOT_EXPORTED
        )

        binding.vehicleText.text = Peugeot208Profile.VEHICLE
        binding.baudSpinner.adapter = ArrayAdapter(
            this,
            android.R.layout.simple_spinner_dropdown_item,
            listOf("38400 baud", "115200 baud", "9600 baud")
        )

        wireTabs()
        wireConnect()
        wireLive()
        wireDtc()
        wireRadio()
        wireColdStart()
        wireAi()
        wireLog()
        refreshDevices()
        log("Avvio Peugeot 208 Technician. Profilo: ${Peugeot208Profile.VEHICLE}")
    }

    private fun wireTabs() {
        binding.tabConnect.setOnClickListener { showPanel("connect") }
        binding.tabLive.setOnClickListener { showPanel("live") }
        binding.tabDtc.setOnClickListener { showPanel("dtc") }
        binding.tabRadio.setOnClickListener { showPanel("radio") }
        binding.tabCold.setOnClickListener { showPanel("cold") }
        binding.tabAi.setOnClickListener { showPanel("ai") }
        binding.tabLog.setOnClickListener { showPanel("log") }
    }

    private fun showPanel(which: String) {
        binding.panelConnect.visibility = if (which == "connect") View.VISIBLE else View.GONE
        binding.panelLive.visibility = if (which == "live") View.VISIBLE else View.GONE
        binding.panelDtc.visibility = if (which == "dtc") View.VISIBLE else View.GONE
        binding.panelRadio.visibility = if (which == "radio") View.VISIBLE else View.GONE
        binding.panelCold.visibility = if (which == "cold") View.VISIBLE else View.GONE
        binding.panelAi.visibility = if (which == "ai") View.VISIBLE else View.GONE
        binding.panelLog.visibility = if (which == "log") View.VISIBLE else View.GONE
    }

    private fun wireConnect() {
        binding.refreshUsb.setOnClickListener { refreshDevices() }
        binding.bluetoothPermissions.setOnClickListener {
            val needed = bluetoothPermissionsNeeded()
            if (needed.isEmpty()) {
                toast("Permessi Bluetooth già disponibili")
                refreshDevices()
            } else bluetoothPermissionLauncher.launch(needed)
        }
        binding.connectBtn.setOnClickListener {
            val endpoint = selectedEndpoint() ?: run {
                toast("Nessun adattatore OBD selezionabile")
                return@setOnClickListener
            }
            val baud = selectedBaud()
            when (endpoint.kind) {
                EndpointKind.USB -> {
                    val device = endpoint.usb ?: return@setOnClickListener
                    if (usbManager.hasPermission(device)) connectNow(endpoint, baud)
                    else requestUsbPermission(device, baud)
                }
                EndpointKind.BLUETOOTH_CLASSIC,
                EndpointKind.BLUETOOTH_LE -> {
                    if (!hasBluetoothRuntimePermissions()) {
                        bluetoothPermissionLauncher.launch(bluetoothPermissionsNeeded())
                        return@setOnClickListener
                    }
                    connectNow(endpoint, baud)
                }
            }
        }
        binding.disconnectBtn.setOnClickListener { disconnect() }
        binding.readCapabilities.setOnClickListener {
            if (!requireConnected()) return@setOnClickListener
            lifecycleScope.launch(Dispatchers.IO) {
                try {
                    val pids = elm.supportedPids().sorted()
                    val text = if (pids.isEmpty()) "Nessun bitmap PID standard letto." else
                        "PID Mode 01 supportati (${pids.size}):\n" + pids.joinToString(" ") { "%02X".format(it) }
                    withContext(Dispatchers.Main) {
                        binding.connectionOutput.append("\n\n$text")
                        log("Letti ${pids.size} PID supportati")
                    }
                } catch (e: Exception) { uiError("Lettura PID", e) }
            }
        }
    }

    private fun bluetoothPermissionsNeeded(): Array<String> {
        val missing = mutableListOf<String>()
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
            if (ContextCompat.checkSelfPermission(this, Manifest.permission.BLUETOOTH_SCAN) != android.content.pm.PackageManager.PERMISSION_GRANTED)
                missing += Manifest.permission.BLUETOOTH_SCAN
            if (ContextCompat.checkSelfPermission(this, Manifest.permission.BLUETOOTH_CONNECT) != android.content.pm.PackageManager.PERMISSION_GRANTED)
                missing += Manifest.permission.BLUETOOTH_CONNECT
        } else {
            if (ContextCompat.checkSelfPermission(this, Manifest.permission.ACCESS_FINE_LOCATION) != android.content.pm.PackageManager.PERMISSION_GRANTED)
                missing += Manifest.permission.ACCESS_FINE_LOCATION
        }
        return missing.toTypedArray()
    }

    private fun hasBluetoothRuntimePermissions(): Boolean = bluetoothPermissionsNeeded().isEmpty()

    private fun refreshDevices() {
        val usbEndpoints = elm.compatibleDevices().map { d ->
            val product = try { d.productName ?: d.deviceName } catch (_: SecurityException) { d.deviceName }
            ObdEndpoint(
                EndpointKind.USB,
                "USB  %04X:%04X  %s".format(d.vendorId, d.productId, product),
                usb = d
            )
        }

        val classicEndpoints = if (hasBluetoothRuntimePermissions()) {
            elm.bondedClassicDevices().map { d ->
                ObdEndpoint(
                    EndpointKind.BLUETOOTH_CLASSIC,
                    "BT CLASSIC  ${elm.safeDeviceName(d)}  ${elm.safeAddress(d)}",
                    bluetooth = d
                )
            }
        } else emptyList()

        endpoints = usbEndpoints + classicEndpoints
        updateEndpointSpinner()
        log("Rilevati: USB=${usbEndpoints.size}, BT associati=${classicEndpoints.size}")

        if (!hasBluetoothRuntimePermissions()) {
            binding.connectionOutput.text =
                "USB disponibile. Per usare il tuo ELM327 Bluetooth premi PERMESSI BLUETOOTH e poi RILEVA OBD.\n" +
                "Per gli ELM327 Bluetooth classici, associa prima l'adattatore dalle impostazioni Android (PIN spesso 1234/0000)."
            return
        }

        if (!elm.bluetoothAvailable()) {
            binding.connectionOutput.text = "Bluetooth non disponibile su questo telefono. Puoi usare l'ELM327 USB/OTG."
            return
        }
        if (!elm.bluetoothEnabled()) {
            binding.connectionOutput.text = "Bluetooth è disattivato. Attivalo sul telefono e premi RILEVA OBD."
            return
        }

        binding.connectionOutput.text = "Ricerca BLE in corso per circa 6 secondi…\nGli adattatori BT classici già associati sono già elencati."
        lifecycleScope.launch(Dispatchers.IO) {
            try {
                val ble = elm.scanBle()
                val classicAddresses = classicEndpoints.mapNotNull { it.bluetooth?.let(elm::safeAddress) }.toSet()
                val bleEndpoints = ble
                    .filter { it.address !in classicAddresses }
                    .map {
                        ObdEndpoint(
                            EndpointKind.BLUETOOTH_LE,
                            "BLE  ${it.name}  ${it.address}  RSSI ${it.rssi}",
                            bluetooth = it.device
                        )
                    }
                withContext(Dispatchers.Main) {
                    endpoints = usbEndpoints + classicEndpoints + bleEndpoints
                    updateEndpointSpinner()
                    binding.connectionOutput.text = buildString {
                        appendLine("Ricerca completata.")
                        appendLine("USB: ${usbEndpoints.size}")
                        appendLine("Bluetooth classico associato: ${classicEndpoints.size}")
                        appendLine("BLE rilevati: ${bleEndpoints.size}")
                        if (endpoints.isEmpty()) appendLine("Nessun adattatore rilevato.")
                        appendLine()
                        appendLine("Se il tuo ELM327 è Bluetooth classico e non appare, abbinalo prima nelle impostazioni Android.")
                    }
                    log("BLE rilevati=${bleEndpoints.size}")
                }
            } catch (e: Exception) {
                withContext(Dispatchers.Main) {
                    updateEndpointSpinner()
                    binding.connectionOutput.text = "Bluetooth classico disponibile; scansione BLE non riuscita: ${e.message}"
                    log("Scan BLE: ${e.message}")
                }
            }
        }
    }

    private fun updateEndpointSpinner() {
        val labels = if (endpoints.isEmpty()) listOf("Nessun adattatore OBD rilevato") else endpoints.map { it.label }
        binding.deviceSpinner.adapter = ArrayAdapter(this, android.R.layout.simple_spinner_dropdown_item, labels)
    }

    private fun selectedEndpoint(): ObdEndpoint? = if (endpoints.isEmpty()) null
    else endpoints[binding.deviceSpinner.selectedItemPosition.coerceIn(0, endpoints.lastIndex)]

    private fun selectedBaud(): Int = when (binding.baudSpinner.selectedItemPosition) {
        1 -> 115200
        2 -> 9600
        else -> 38400
    }

    private fun requestUsbPermission(device: UsbDevice, baud: Int) {
        pendingDevice = device
        pendingBaud = baud
        val intent = Intent(ACTION_USB_PERMISSION).setPackage(packageName)
        val flags = PendingIntent.FLAG_UPDATE_CURRENT or
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) PendingIntent.FLAG_MUTABLE else 0
        usbManager.requestPermission(device, PendingIntent.getBroadcast(this, 0, intent, flags))
        log("Richiesto permesso USB")
    }

    private fun connectNow(endpoint: ObdEndpoint, baud: Int) {
        binding.connectionOutput.text = "Connessione ELM327 tramite ${endpoint.kind}…"
        lifecycleScope.launch(Dispatchers.IO) {
            try {
                when (endpoint.kind) {
                    EndpointKind.USB -> elm.open(endpoint.usb ?: error("USB assente"), baud)
                    EndpointKind.BLUETOOTH_CLASSIC -> elm.openBluetoothClassic(endpoint.bluetooth ?: error("Bluetooth assente"))
                    EndpointKind.BLUETOOTH_LE -> elm.openBluetoothLe(endpoint.bluetooth ?: error("BLE assente"))
                }
                val info = elm.initialize()
                elmInfo = info
                val text = buildString {
                    appendLine("CONNESSO")
                    appendLine("Trasporto: ${elm.transportLabel()}")
                    appendLine("Adattatore: ${info.identity}")
                    appendLine("Protocollo ELM: ${info.protocol}")
                    appendLine("Tensione adattatore: ${info.adapterVoltage}")
                    appendLine("VIN: ${info.vin ?: "non disponibile via Mode 09"}")
                    appendLine("Calibration ID: ${info.calibrationId ?: "n/d"}")
                    appendLine("CVN: ${info.cvn ?: "n/d"}")
                    appendLine()
                    appendLine("Profilo: ${Peugeot208Profile.VEHICLE}")
                    appendLine("Protocollo atteso dal precedente fingerprint: ${Peugeot208Profile.EXPECTED_PROTOCOL}")
                    if (info.calibrationId != null) appendLine("Calibration ID atteso: ${Peugeot208Profile.KNOWN_CALIBRATION_ID} • ${if (info.calibrationId.contains(Peugeot208Profile.KNOWN_CALIBRATION_ID, true)) "COERENTE" else "DIVERSO/DA VERIFICARE"}")
                    if (info.cvn != null) appendLine("CVN atteso: ${Peugeot208Profile.KNOWN_CVN} • ${if (info.cvn.equals(Peugeot208Profile.KNOWN_CVN, true)) "COERENTE" else "DIVERSO/DA VERIFICARE"}")
                    appendLine("ATSP0: selezione automatica del protocollo OBD da parte dell'ELM327.")
                }
                withContext(Dispatchers.Main) {
                    binding.connectionOutput.text = text
                    log("ELM327 connesso via ${elm.transportLabel()}: ${info.identity}; ${info.protocol}")
                }
            } catch (e: Exception) {
                try { elm.close() } catch (_: Exception) {}
                uiError("Connessione ELM327", e)
            }
        }
    }

    private fun disconnect() {
        liveJob?.cancel(); liveJob = null
        coldJob?.cancel(); coldJob = null
        elm.close()
        elmInfo = null
        binding.connectionOutput.text = "Disconnesso."
        log("ELM327 disconnesso")
    }

    private fun wireLive() {
        binding.readLive.setOnClickListener { readLiveOnce() }
        binding.startLive.setOnClickListener {
            if (!requireConnected() || liveJob?.isActive == true) return@setOnClickListener
            liveJob = lifecycleScope.launch(Dispatchers.IO) {
                while (isActive && elm.isOpen()) {
                    try {
                        val s = elm.readLiveSnapshot()
                        lastSnapshot = s
                        val advice = PeugeotAdvisor.analyze(s, allCodes())
                        withContext(Dispatchers.Main) {
                            binding.liveOutput.text = s.humanReadable()
                            binding.liveAdvice.text = advice
                        }
                    } catch (e: Exception) {
                        withContext(Dispatchers.Main) { log("Live error: ${e.message}") }
                    }
                    delay(1200)
                }
            }
            log("Live continuo avviato")
        }
        binding.stopLive.setOnClickListener { liveJob?.cancel(); liveJob = null; log("Live continuo fermato") }
    }

    private fun readLiveOnce() {
        if (!requireConnected()) return
        lifecycleScope.launch(Dispatchers.IO) {
            try {
                val s = elm.readLiveSnapshot()
                lastSnapshot = s
                val advice = PeugeotAdvisor.analyze(s, allCodes())
                withContext(Dispatchers.Main) {
                    binding.liveOutput.text = s.humanReadable()
                    binding.liveAdvice.text = advice
                    log("Live data aggiornati")
                }
            } catch (e: Exception) { uiError("Live data", e) }
        }
    }

    private fun wireDtc() {
        binding.readDtc.setOnClickListener {
            if (!requireConnected()) return@setOnClickListener
            lifecycleScope.launch(Dispatchers.IO) {
                try {
                    val r = elm.readDtcReport()
                    lastDtc = r
                    val text = formatDtc(r)
                    withContext(Dispatchers.Main) { binding.dtcOutput.text = text; log("DTC letti: ${allCodes().size}") }
                } catch (e: Exception) { uiError("Lettura DTC", e) }
            }
        }

        binding.clearDtc.setOnClickListener {
            if (!requireConnected()) return@setOnClickListener
            val confirm = EditText(this).apply { hint = "Scrivi CANCELLA" }
            AlertDialog.Builder(this)
                .setTitle("Cancellazione DTC")
                .setMessage("Mode 04 cancella DTC e può cancellare dati diagnostici/freeze-frame. Prima salva i codici e registra il difetto. Per procedere scrivi CANCELLA.")
                .setView(confirm)
                .setNegativeButton("ANNULLA", null)
                .setPositiveButton("PROCEDI") { _, _ ->
                    if (confirm.text.toString().trim() != "CANCELLA") { toast("Conferma non valida"); return@setPositiveButton }
                    lifecycleScope.launch(Dispatchers.IO) {
                        try {
                            val raw = elm.clearDtcs()
                            withContext(Dispatchers.Main) {
                                binding.dtcOutput.append("\n\nRisposta Mode 04: $raw\nRileggi i DTC per verificare.")
                                log("Mode 04 eseguito su richiesta esplicita")
                            }
                        } catch (e: Exception) { uiError("Cancellazione DTC", e) }
                    }
                }.show()
        }
    }

    private fun formatDtc(r: DtcReport): String = buildString {
        fun section(name: String, list: List<String>) {
            appendLine("$name (${list.size})")
            if (list.isEmpty()) appendLine("  nessuno")
            else list.forEach { appendLine("  $it — ${PeugeotAdvisor.explainDtc(it)}") }
            appendLine()
        }
        section("CONFERMATI", r.confirmed)
        section("PENDING", r.pending)
        section("PERMANENTI", r.permanent)
        appendLine("Nota: i DTC PSA/UDS manufacturer-specific non vengono interpretati inventando descrizioni.")
    }

    private fun wireRadio() {
        binding.radioRefresh.setOnClickListener { refreshRadioDevices() }
        binding.radioScan.setOnClickListener {
            if (radioDevices.isEmpty()) {
                toast("Nessun dispositivo USB enumerato dal telefono")
                return@setOnClickListener
            }
            val device = radioDevices[binding.radioSpinner.selectedItemPosition.coerceIn(0, radioDevices.lastIndex)]
            val report = radioScanner.scan(device)
            val profile = DeviceProfileAnalyzer.analyze(report)
            binding.radioOutput.text = report.humanReadable() + "\n\n" + profile.humanReadable()
            log("Analisi USB autoradio passiva: %04X:%04X".format(device.vendorId, device.productId))
        }
        refreshRadioDevices()
    }

    private fun refreshRadioDevices() {
        radioDevices = radioScanner.listDevices()
        val labels = if (radioDevices.isEmpty()) listOf("Nessun dispositivo USB enumerato") else radioDevices.map { d ->
            val product = try { d.productName ?: d.deviceName } catch (_: SecurityException) { d.deviceName }
            "%04X:%04X  %s".format(d.vendorId, d.productId, product)
        }
        binding.radioSpinner.adapter = ArrayAdapter(this, android.R.layout.simple_spinner_dropdown_item, labels)
        if (radioDevices.isEmpty()) {
            binding.radioOutput.text = "Il telefono non vede alcun USB DEVICE. Se sei collegato alla normale USB della Peugeot, è probabile che la radio sia HOST: quella porta non espone internamente la head-unit come periferica diagnostica."
        }
    }

    private fun wireColdStart() {
        binding.startCold.setOnClickListener {
            if (!requireConnected() || coldJob?.isActive == true) return@setOnClickListener
            coldRows.clear()
            coldStartedAt = System.currentTimeMillis()
            coldJob = lifecycleScope.launch(Dispatchers.IO) {
                val deadline = coldStartedAt + 180_000L
                while (isActive && elm.isOpen() && System.currentTimeMillis() < deadline) {
                    try {
                        val s = elm.readLiveSnapshot()
                        coldRows += s
                        lastSnapshot = s
                        val elapsed = (System.currentTimeMillis() - coldStartedAt) / 1000
                        withContext(Dispatchers.Main) {
                            binding.coldStatus.text = "Registrazione: ${elapsed}s / 180s • campioni ${coldRows.size} • RPM ${s.rpm?.let { "%.0f".format(it) } ?: "n/d"}"
                            binding.coldOutput.text = s.humanReadable()
                        }
                    } catch (e: Exception) {
                        withContext(Dispatchers.Main) { log("Cold-start sample error: ${e.message}") }
                    }
                    delay(900)
                }
                withContext(Dispatchers.Main) {
                    binding.coldStatus.text = "Registrazione terminata • ${coldRows.size} campioni"
                    binding.coldOutput.text = PeugeotAdvisor.analyzeColdStart(coldRows.toList())
                    log("Cold-start terminato: ${coldRows.size} campioni")
                }
            }
            log("Cold-start recorder avviato")
        }
        binding.stopCold.setOnClickListener {
            coldJob?.cancel(); coldJob = null
            binding.coldStatus.text = "Registrazione fermata • ${coldRows.size} campioni"
            if (coldRows.isNotEmpty()) binding.coldOutput.text = PeugeotAdvisor.analyzeColdStart(coldRows.toList())
            log("Cold-start fermato manualmente")
        }
        binding.analyzeCold.setOnClickListener {
            binding.coldOutput.text = PeugeotAdvisor.analyzeColdStart(coldRows.toList())
        }
        binding.shareCold.setOnClickListener {
            if (coldRows.isEmpty()) { toast("Nessun campione da condividere"); return@setOnClickListener }
            shareText("Peugeot208_cold_start.csv", coldCsv())
        }
    }

    private fun coldCsv(): String = buildString {
        appendLine("timestamp,elapsed_s,rpm,speed_kmh,coolant_c,intake_c,timing_deg,load_pct,stft_pct,ltft_pct,map_kpa,maf_gps,throttle_pct,fuel_pct,ecu_v,adapter_v")
        coldRows.forEach { s ->
            val elapsed = if (coldStartedAt > 0) (s.timestampMs - coldStartedAt) / 1000.0 else 0.0
            fun v(x: Double?) = x?.let { "%.3f".format(java.util.Locale.US, it) } ?: ""
            appendLine(listOf(
                Instant.ofEpochMilli(s.timestampMs).toString(), v(elapsed), v(s.rpm), v(s.speedKmh), v(s.coolantC), v(s.intakeC),
                v(s.timingAdvanceDeg), v(s.engineLoadPct), v(s.stftPct), v(s.ltftPct), v(s.mapKpa), v(s.mafGps), v(s.throttlePct),
                v(s.fuelLevelPct), v(s.ecuVoltageV), v(s.adapterVoltageV)
            ).joinToString(","))
        }
    }

    private fun wireAi() {
        binding.checkAi.setOnClickListener {
            lifecycleScope.launch {
                binding.checkAi.isEnabled = false
                localAi.prepare { status -> runOnUiThread { binding.aiStatus.text = status } }
                binding.checkAi.isEnabled = true
            }
        }
        binding.askAi.setOnClickListener {
            val q = binding.aiQuestion.text.toString().trim()
            if (q.isEmpty()) { toast("Scrivi una domanda"); return@setOnClickListener }
            val context = aiContext()
            lifecycleScope.launch {
                binding.askAi.isEnabled = false
                binding.aiOutput.text = "Analisi…"
                val ai = localAi.analyze(q, context)
                binding.aiOutput.text = ai ?: OfflineAdvisor.answer(q, lastSnapshot, lastDtc, coldRows.toList())
                binding.askAi.isEnabled = true
                log("Analisi tecnica richiesta")
            }
        }
    }

    private fun aiContext(): String = buildString {
        appendLine(Peugeot208Profile.VEHICLE)
        elmInfo?.let { appendLine("ELM=${it.identity}; transport=${elm.transportLabel()}; protocol=${it.protocol}; VIN=${it.vin ?: "n/d"}") }
        lastSnapshot?.let { appendLine("LIVE:\n${it.humanReadable()}") }
        lastDtc?.let { appendLine("DTC:\n${formatDtc(it)}") }
        if (coldRows.isNotEmpty()) appendLine("COLD START:\n${PeugeotAdvisor.analyzeColdStart(coldRows.toList())}")
        appendLine("Limiti: niente coding PSA, security access, firmware o test attuatori.")
    }

    private fun wireLog() {
        binding.clearLog.setOnClickListener { appLog.clear(); binding.logOutput.text = "" }
        binding.shareLog.setOnClickListener { shareText("Peugeot 208 Technician report", fullReport()) }
    }

    private fun fullReport(): String = buildString {
        appendLine(Peugeot208Profile.VEHICLE)
        appendLine("Generato: ${Instant.now()}")
        appendLine()
        elmInfo?.let { appendLine("ELM: $it") }
        lastSnapshot?.let { appendLine("\nLIVE:\n${it.humanReadable()}") }
        lastDtc?.let { appendLine("\nDTC:\n${formatDtc(it)}") }
        if (coldRows.isNotEmpty()) appendLine("\nCOLD START:\n${PeugeotAdvisor.analyzeColdStart(coldRows.toList())}")
        appendLine("\nLOG:\n$appLog")
    }

    private fun allCodes(): List<String> = listOfNotNull(lastDtc?.confirmed, lastDtc?.pending, lastDtc?.permanent).flatten().distinct()

    private fun requireConnected(): Boolean {
        if (!elm.isOpen()) { toast("Connetti prima l'ELM327 via Bluetooth o USB"); return false }
        return true
    }

    private fun shareText(title: String, text: String) {
        val i = Intent(Intent.ACTION_SEND).apply {
            type = "text/plain"
            putExtra(Intent.EXTRA_SUBJECT, title)
            putExtra(Intent.EXTRA_TEXT, text)
        }
        startActivity(Intent.createChooser(i, "Condividi"))
    }

    private fun log(message: String) {
        val stamp = java.time.LocalTime.now().format(timeFmt)
        appLog.appendLine("[$stamp] $message")
        binding.logOutput.text = appLog.toString()
    }

    private suspend fun uiError(where: String, e: Exception) = withContext(Dispatchers.Main) {
        val msg = "$where: ${e.message ?: e.javaClass.simpleName}"
        toast(msg)
        log(msg)
    }

    private fun toast(message: String) = Toast.makeText(this, message, Toast.LENGTH_LONG).show()

    override fun onDestroy() {
        liveJob?.cancel(); coldJob?.cancel()
        try { elm.close() } catch (_: Exception) {}
        try { unregisterReceiver(usbPermissionReceiver) } catch (_: Exception) {}
        super.onDestroy()
    }

    companion object {
        private const val ACTION_USB_PERMISSION = "com.peugeot208technician.USB_PERMISSION"
    }
}
