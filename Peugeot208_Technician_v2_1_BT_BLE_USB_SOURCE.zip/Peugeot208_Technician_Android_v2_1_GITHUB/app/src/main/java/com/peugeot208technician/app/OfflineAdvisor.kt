package com.peugeot208technician.app

object OfflineAdvisor {
    fun answer(question: String, snapshot: LiveSnapshot?, dtcs: DtcReport?, cold: List<LiveSnapshot>): String {
        val allCodes = listOfNotNull(dtcs?.confirmed, dtcs?.pending, dtcs?.permanent).flatten().distinct()
        return buildString {
            appendLine("Advisor offline — ${Peugeot208Profile.VEHICLE}")
            appendLine()
            if (snapshot != null) appendLine(PeugeotAdvisor.analyze(snapshot, allCodes))
            if (cold.isNotEmpty() && (question.contains("fredd", true) || question.contains("p050b", true) || question.contains("avvi", true))) {
                appendLine(PeugeotAdvisor.analyzeColdStart(cold))
            }
            if (snapshot == null && allCodes.isEmpty() && cold.isEmpty()) {
                appendLine("Non ci sono ancora dati della vettura. Connetti l'ELM327, leggi DTC e acquisisci LIVE DATA.")
            }
            appendLine()
            appendLine("Domanda: $question")
        }
    }
}
