package com.peugeot208technician.app

object ObdDecoders {
    fun pidValue(response: String, pid: Int): Double? {
        val data = frameData(response, 0x41, pid) ?: return null
        val a = data.getOrNull(0)?.toDouble()
        val b = data.getOrNull(1)?.toDouble()
        return when (pid) {
            0x04 -> a?.times(100.0)?.div(255.0)
            0x05 -> a?.minus(40.0)
            0x06, 0x07 -> a?.times(100.0)?.div(128.0)?.minus(100.0)
            0x0B -> a
            0x0C -> if (a != null && b != null) ((a * 256.0) + b) / 4.0 else null
            0x0D -> a
            0x0E -> a?.div(2.0)?.minus(64.0)
            0x0F -> a?.minus(40.0)
            0x10 -> if (a != null && b != null) ((a * 256.0) + b) / 100.0 else null
            0x11 -> a?.times(100.0)?.div(255.0)
            0x2F -> a?.times(100.0)?.div(255.0)
            0x42 -> if (a != null && b != null) ((a * 256.0) + b) / 1000.0 else null
            0x46 -> a?.minus(40.0)
            0x5C -> a?.minus(40.0)
            else -> null
        }
    }

    fun supportedPids(response: String, basePid: Int): Set<Int> {
        val data = frameData(response, 0x41, basePid) ?: return emptySet()
        if (data.size < 4) return emptySet()
        var bits = 0L
        repeat(4) { i -> bits = (bits shl 8) or (data[i].toLong() and 0xFF) }
        val out = linkedSetOf<Int>()
        for (i in 0 until 32) {
            val mask = 1L shl (31 - i)
            if ((bits and mask) != 0L) out += basePid + i + 1
        }
        return out
    }

    fun parseDtcs(response: String, positiveService: Int): List<String> {
        val all = frames(response)
        val out = linkedSetOf<String>()
        all.forEach { frame ->
            val index = frame.indexOf(positiveService)
            if (index < 0) return@forEach
            val data = frame.drop(index + 1)
            var i = 0
            while (i + 1 < data.size) {
                val a = data[i]
                val b = data[i + 1]
                if (a == 0 && b == 0) break
                out += decodeDtc(a, b)
                i += 2
            }
        }
        return out.toList()
    }

    fun parseVin(response: String): String? {
        val bytes = mutableListOf<Int>()
        frames(response).forEach { frame ->
            val idx = frame.windowed(2).indexOfFirst { it[0] == 0x49 && it[1] == 0x02 }
            if (idx >= 0) {
                var data = frame.drop(idx + 2)
                if (data.firstOrNull()?.let { it in 0x00..0x10 } == true) data = data.drop(1)
                bytes += data
            }
        }
        val vin = bytes.filter { it in 0x20..0x7E }.map { it.toChar() }.joinToString("")
            .replace("\u0000", "").trim()
        return vin.takeIf { it.length >= 11 }?.take(17)
    }

    fun parseMode09Ascii(response: String, pid: Int): String? {
        val bytes = mutableListOf<Int>()
        frames(response).forEach { frame ->
            val idx = frame.windowed(2).indexOfFirst { it[0] == 0x49 && it[1] == pid }
            if (idx >= 0) {
                var data = frame.drop(idx + 2)
                if (data.firstOrNull()?.let { it in 0x00..0x10 } == true) data = data.drop(1)
                bytes += data
            }
        }
        val text = bytes.filter { it in 0x20..0x7E }.map { it.toChar() }.joinToString("").trim()
        return text.takeIf { it.isNotBlank() }
    }

    fun parseCvn(response: String): String? {
        val bytes = mutableListOf<Int>()
        frames(response).forEach { frame ->
            val idx = frame.windowed(2).indexOfFirst { it[0] == 0x49 && it[1] == 0x06 }
            if (idx >= 0) {
                var data = frame.drop(idx + 2)
                if (data.firstOrNull()?.let { it in 0x00..0x10 } == true) data = data.drop(1)
                bytes += data
            }
        }
        if (bytes.size < 4) return null
        return bytes.take(4).joinToString("") { "%02X".format(it) }
    }

    fun parseVoltage(raw: String): Double? {
        val m = Regex("([0-9]{1,2}(?:\\.[0-9]+)?)\\s*V", RegexOption.IGNORE_CASE).find(raw)
        return m?.groupValues?.getOrNull(1)?.toDoubleOrNull()
    }

    fun isNoData(raw: String): Boolean {
        val t = raw.uppercase()
        return "NO DATA" in t || "UNABLE TO CONNECT" in t || "STOPPED" in t || "ERROR" in t
    }

    private fun frameData(response: String, service: Int, pid: Int): List<Int>? {
        frames(response).forEach { frame ->
            for (i in 0 until frame.size - 1) {
                if (frame[i] == service && frame[i + 1] == pid) return frame.drop(i + 2)
            }
        }
        return null
    }

    private fun frames(response: String): List<List<Int>> {
        val cleaned = response
            .replace(">", "\n")
            .replace("SEARCHING...", "", ignoreCase = true)
            .replace("BUS INIT: OK", "", ignoreCase = true)
        return cleaned.lines().mapNotNull { line ->
            val hex = Regex("(?i)(?<![0-9A-F])[0-9A-F]{2}(?![0-9A-F])")
                .findAll(line.replace(":", " ")).map { it.value.toInt(16) }.toList()
            if (hex.isNotEmpty()) hex else {
                val compact = line.replace(Regex("[^0-9A-Fa-f]"), "")
                if (compact.length >= 4 && compact.length % 2 == 0) {
                    compact.chunked(2).mapNotNull { it.toIntOrNull(16) }.takeIf { it.isNotEmpty() }
                } else null
            }
        }
    }

    private fun decodeDtc(a: Int, b: Int): String {
        val system = when ((a shr 6) and 0x03) {
            0 -> 'P'; 1 -> 'C'; 2 -> 'B'; else -> 'U'
        }
        val d2 = (a shr 4) and 0x03
        val d3 = a and 0x0F
        val d4 = (b shr 4) and 0x0F
        val d5 = b and 0x0F
        return "$system$d2${d3.toString(16).uppercase()}${d4.toString(16).uppercase()}${d5.toString(16).uppercase()}"
    }
}
