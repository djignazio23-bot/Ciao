package com.peugeot208technician.app

import android.hardware.usb.UsbConstants
import android.hardware.usb.UsbDevice
import android.hardware.usb.UsbManager

/**
 * Scanner strettamente passivo: legge soltanto i descrittori già enumerati da Android.
 * Non apre UsbDeviceConnection, non reclama interfacce e non esegue transfer USB.
 */
class SafeUsbScanner(private val usbManager: UsbManager) {

    fun listDevices(): List<UsbDevice> =
        usbManager.deviceList.values.sortedWith(compareBy({ it.vendorId }, { it.productId }))

    fun scan(device: UsbDevice): UsbScanReport {
        val interfaces = (0 until device.interfaceCount).map { index ->
            val intf = device.getInterface(index)
            val endpoints = (0 until intf.endpointCount).map { epIndex ->
                val ep = intf.getEndpoint(epIndex)
                UsbEndpointInfo(
                    address = ep.address,
                    direction = if (ep.direction == UsbConstants.USB_DIR_IN) "IN" else "OUT",
                    type = endpointTypeName(ep.type),
                    maxPacketSize = ep.maxPacketSize
                )
            }
            UsbInterfaceInfo(
                index = index,
                interfaceClass = intf.interfaceClass,
                interfaceClassName = usbClassName(intf.interfaceClass),
                subclass = intf.interfaceSubclass,
                protocol = intf.interfaceProtocol,
                endpoints = endpoints
            )
        }

        val notes = mutableListOf<String>()
        val classes = interfaces.map { it.interfaceClass }.toSet()
        val adb = interfaces.any {
            it.interfaceClass == UsbConstants.USB_CLASS_VENDOR_SPEC &&
                    it.subclass == 0x42 && it.protocol == 0x01
        }

        if (UsbConstants.USB_CLASS_AUDIO in classes) notes += "USB Audio presente."
        if (UsbConstants.USB_CLASS_MASS_STORAGE in classes)
            notes += "Mass Storage presente: SAFE MODE non monta, scrive o modifica il contenuto."
        if (UsbConstants.USB_CLASS_STILL_IMAGE in classes)
            notes += "PTP/MTP-style interface presente."
        if (UsbConstants.USB_CLASS_HID in classes)
            notes += "HID presente: vengono letti soltanto i descrittori."
        if (UsbConstants.USB_CLASS_COMM in classes || UsbConstants.USB_CLASS_CDC_DATA in classes)
            notes += "Possibile CDC/seriale. L'apertura della porta è separata e classificata GIALLO."
        if (adb) notes += "Pattern ADB Android rilevato. Nessuna sessione ADB viene avviata automaticamente."
        else if (UsbConstants.USB_CLASS_VENDOR_SPEC in classes)
            notes += "Interfaccia vendor-specific rilevata: nessun probing automatico."
        if (interfaces.any { i -> i.endpoints.any { it.direction == "OUT" } })
            notes += "Sono presenti endpoint OUT, ma AUTO SAFE non trasmette mai dati."

        val manufacturer = try { device.manufacturerName } catch (_: SecurityException) { null }
        val product = try { device.productName } catch (_: SecurityException) { null }

        return UsbScanReport(
            deviceName = device.deviceName,
            vendorId = device.vendorId,
            productId = device.productId,
            manufacturer = manufacturer,
            product = product,
            deviceClass = device.deviceClass,
            deviceClassName = usbClassName(device.deviceClass),
            interfaces = interfaces,
            notes = notes
        )
    }

    companion object {
        fun usbClassName(clazz: Int): String = when (clazz) {
            UsbConstants.USB_CLASS_PER_INTERFACE -> "Per-interface"
            UsbConstants.USB_CLASS_AUDIO -> "Audio"
            UsbConstants.USB_CLASS_COMM -> "Communications / CDC control"
            UsbConstants.USB_CLASS_HID -> "HID"
            UsbConstants.USB_CLASS_PHYSICA -> "Physical"
            UsbConstants.USB_CLASS_STILL_IMAGE -> "Image / PTP-MTP"
            UsbConstants.USB_CLASS_PRINTER -> "Printer"
            UsbConstants.USB_CLASS_MASS_STORAGE -> "Mass Storage"
            UsbConstants.USB_CLASS_HUB -> "Hub"
            UsbConstants.USB_CLASS_CDC_DATA -> "CDC Data"
            UsbConstants.USB_CLASS_CSCID -> "Smart Card"
            UsbConstants.USB_CLASS_CONTENT_SEC -> "Content Security"
            UsbConstants.USB_CLASS_VIDEO -> "Video"
            UsbConstants.USB_CLASS_WIRELESS_CONTROLLER -> "Wireless Controller"
            UsbConstants.USB_CLASS_MISC -> "Miscellaneous"
            UsbConstants.USB_CLASS_APP_SPEC -> "Application Specific"
            UsbConstants.USB_CLASS_VENDOR_SPEC -> "Vendor Specific"
            else -> "Unknown"
        }

        fun endpointTypeName(type: Int): String = when (type) {
            UsbConstants.USB_ENDPOINT_XFER_CONTROL -> "CONTROL"
            UsbConstants.USB_ENDPOINT_XFER_ISOC -> "ISOCHRONOUS"
            UsbConstants.USB_ENDPOINT_XFER_BULK -> "BULK"
            UsbConstants.USB_ENDPOINT_XFER_INT -> "INTERRUPT"
            else -> "UNKNOWN"
        }
    }
}
