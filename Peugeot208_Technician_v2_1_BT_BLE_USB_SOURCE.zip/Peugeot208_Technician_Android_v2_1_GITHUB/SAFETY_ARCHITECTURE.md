# Safety architecture — v2 Bluetooth + USB

## Separazione AI / trasporto

`LocalAiAdvisor` e `OfflineAdvisor` ricevono esclusivamente dati testuali/strutturati. Non ricevono un riferimento a `Elm327UsbClient`, `BluetoothGatt`, `BluetoothSocket`, `UsbManager` o `UsbSerialPort`.

L'AI non può quindi trasmettere autonomamente comandi all'auto.

## Trasporti OBD ammessi

`Elm327UsbClient` implementa esclusivamente il trasporto seriale necessario a un adattatore ELM327:

- USB seriale;
- Bluetooth Classic RFCOMM/SPP;
- BLE GATT write + notify.

Il livello OBD sopra il trasporto resta limitato ai comandi AT dell'ELM e ai servizi OBD implementati nell'app.

## Scrittura diagnostica

Le normali funzioni usano Mode 01/03/07/09/0A e comandi AT dell'adattatore.

Mode 04 (clear DTC) è l'unica operazione OBD implementata che modifica lo stato diagnostico ed è protetta da conferma testuale `CANCELLA`.

## Capacità volutamente assenti

Non sono implementati UDS SecurityAccess (0x27), WriteDataByIdentifier (0x2E), RequestDownload (0x34), TransferData (0x36), RoutineControl (0x31), ECUReset proprietario, raw CAN injection, programmazione immobilizer/chiavi, coding BSI/ECU o flashing.

## BLE

La scansione BLE è passiva. La connessione GATT viene aperta soltanto quando l'utente seleziona esplicitamente un dispositivo. L'app richiede una caratteristica scrivibile e una notificabile; se non le trova, interrompe la connessione.

## RADIO USB

`SafeUsbScanner` continua a leggere soltanto descrittori già enumerati dal framework Android e non apre connessioni USB né effettua transfer.
