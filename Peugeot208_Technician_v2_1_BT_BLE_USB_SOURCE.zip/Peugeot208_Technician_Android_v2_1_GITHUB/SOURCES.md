# Riferimenti tecnici

- ELM Electronics — ELM327 data sheet / AT command reference: https://elmelectronics.com/wp-content/uploads/2020/05/ELM327DSL.pdf
- Android Developers — Bluetooth permissions: https://developer.android.com/develop/connectivity/bluetooth/bt-permissions
- Android Developers — BluetoothGatt / BluetoothGattCallback API: https://developer.android.com/reference/android/bluetooth/BluetoothGatt
- Google ML Kit — Prompt API per Gemini Nano: https://developers.google.com/ml-kit/genai/prompt/android/get-started
- mik3y — usb-serial-for-android: https://github.com/mik3y/usb-serial-for-android

Nota: le formule implementate sono quelle dei PID OBD-II standard usati dal progetto. PID PSA proprietari non vengono aggiunti senza una mappatura verificata.
