# Build APK con GitHub Actions

Questo repository compila automaticamente l'app Peugeot 208 Technician.

## Build automatica
- Ogni push sul branch `main` avvia la build.
- Puoi anche aprire **Actions > Build Peugeot 208 Technician APK > Run workflow**.
- Al termine apri il job completato e scarica l'artifact **Peugeot208Technician-debug-apk**.
- Dentro trovi `app-debug.apk`, installabile su Android dopo aver autorizzato l'installazione da quella sorgente.

## Release APK
Creando un tag del tipo `v2.0.0`, il workflow `release-apk.yml` compila l'APK e lo allega a una GitHub Release.

## Sicurezza
L'app usa OBD-II/ELM327 per diagnosi della Peugeot 208. Non contiene coding BSI/ECU, programmazione chiavi, flashing firmware o trasmissione CAN arbitraria.
