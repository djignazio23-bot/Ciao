# Peugeot 208 ECU SAFE Android v1

App Android per **Peugeot 208 II 2022 1.2 PureTech 100** con ELM327 Bluetooth Classic.

## Obiettivo
Identificare la ECU nel modo più conservativo possibile prima di costruire il reset degli autoadattativi.

## Sicurezza
La build è **solo lettura**.

Comandi veicolo consentiti:
- `0100`
- `0900`
- `0902`
- `0904`
- `0906`
- `090A`
- `03`

Comandi ELM consentiti:
- `ATI`
- `ATE0`
- `ATL0`
- `ATS0`
- `ATH0`
- `ATSP6`
- `ATDPN`
- `ATDP`
- `ATRV`
- `ATPC`

La app usa una allowlist nel codice e rifiuta ogni altro comando.

### Non presenti
- `ATSP0`
- fallback KWP / ISO9141
- Mode 04
- UDS session control / reset / security access
- RoutineControl
- scrittura DID
- flash ECU
- reset autoadattativi

## Uso
1. Associa prima l'ELM327 dalle impostazioni Bluetooth Android.
2. Collega l'ELM alla presa OBD.
3. Metti il quadro acceso.
4. Apri l'app.
5. Seleziona l'ELM327.
6. Premi **Connetti ELM327**.
7. Premi **SAFE IDENTIFY**.
8. Al termine condividi `PEUGEOT_ECU_SAFE_REPORT_....txt`.

Il report viene salvato in:
`Download/PeugeotECUSafe/`

## Build APK con GitHub
Carica tutto il progetto in un repository GitHub. La workflow:
`.github/workflows/build-apk.yml`
genera automaticamente `app-debug.apk` come artifact.

## Importante
Questa v1 non effettua alcun reset. Il reset autoadattativi verrà aggiunto soltanto dopo aver identificato in modo affidabile la ECU dal report.
