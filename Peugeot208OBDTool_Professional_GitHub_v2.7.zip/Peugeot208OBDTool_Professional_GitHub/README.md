# Peugeot 208 OBD PRO v2.6

Aggiunge **208 Test Center** in sola lettura: test completo motore, tagliando/manutenzione, avviamento a freddo, minimo, accensione/candele, carburazione/lambda, turbo/boost, raffreddamento, batteria/alternatore, emissioni/EVAP, sensori e readiness pre-revisione.

I test avanzati che richiedono attuazione PSA (es. ventola forzata, attuatori, reset spia service proprietario) NON vengono inviati con comandi non verificati. Il Safe ECU Restart della v2.5 resta separato e protetto.

# Peugeot 208 OBD Tool Professional — v2.0

Android diagnostic app for Bluetooth ELM327 adapters, designed around a Peugeot 208 workflow.

## Professional features
- Bluetooth SPP connection to paired ELM327 adapters.
- Connection status, adapter identification, detected OBD protocol and adapter voltage.
- Live dashboard: RPM, speed, coolant temperature, MAP, throttle, battery/adapter voltage, STFT/LTFT.
- Built-in live RPM sparkline without third-party chart libraries.
- CSV logging for cold-start diagnosis in the app external files directory.
- Vehicle info / VIN request.
- DTC scan and clear with explicit confirmation.
- Dedicated Advanced page with safe ECU soft reset workflow.
- Reset Safety Gate requires verified 0 km/h, engine off and >= 11.8 V before sending a reset request.
- Manual OBD console with automatic blocks for common firmware-programming/write/security command families.
- Professional session log.

## ECU reset scope
The reset feature is a diagnostic soft reset request to the engine ECU. It does **not** emulate a physical power disconnect and therefore does not intentionally power-cycle the radio/infotainment. Support depends on the actual ECU, gateway and ELM327 adapter.

The application intentionally does not provide automated firmware flashing, immobilizer programming, airbag/SRS coding or write operations to safety-critical modules.

## Build
1. Open the project in Android Studio.
2. Allow Gradle to sync.
3. Pair the ELM327 in Android Bluetooth settings.
4. Build > Build App Bundle(s) / APK(s) > Build APK(s).
5. Install the generated debug APK for local testing.

Target SDK: 35. Minimum Android: 8.0 (API 26).

## GitHub Actions — APK automatico
Questa edizione include `.github/workflows/build-apk.yml` per compilare automaticamente un APK debug installabile. Consulta `BUILD_GITHUB.md` per la procedura passo-passo.


## v2.3 AI Diagnostic Mode
- Registrazione telemetria OBD in CSV
- Indicatori locali preliminari per tensione, fuel trim, MAP e temperatura
- Condivisione diretta del CSV verso ChatGPT tramite Android Share Sheet
- Nessun dato viene inviato automaticamente: la condivisione è esplicita e controllata dall'utente.

## v2.4 Extended Engine Diagnostic
- AI CSV esteso: BARO/boost, engine load, ignition timing, IAT, MAF, fuel pressure, direct-injection rail pressure e commanded lambda quando supportati.
- Valori non supportati non interrompono più l'intera acquisizione live.
- LTFT/STFT -100% a motore spento filtrati come non disponibili.
- Pannelli Turbo/Aspirazione e Accensione/Combustione.
- Scansione Mode $06 read-only per dati monitor ECU disponibili (interpretazione dipende dalla ECU).


## v2.5 Safe ECU Restart
- Doppia conferma prima del reset.
- Safety gate fail-closed: 0 km/h, RPM 0, tensione >= 11.8 V.
- Snapshot DTC obbligatorio prima del reset.
- UDS ECU Reset 0x11 0x01 solo sulla ECU motore (7E0), se supportato.
- Nessun clear adattamenti, coding, flashing, BSI, airbag, radio o immobilizer.
- Verifica post-reset con PID 0100 e richiesta di riconnessione se non verificabile.
- Non viene presentato come equivalente allo stacco batteria.


## v2.7 Peugeot ECU Auto Profile
- Mode 09 identification: VIN, Calibration ID, CVN, ECU name when supported.
- Automatic ECU family detection; Bosch MG1CS032 is only selected on an exact identifier match.
- Test Center reports are tagged with the detected ECU profile.
- Proprietary PSA write/actuation commands remain disabled unless a verified ECU-specific implementation exists.
