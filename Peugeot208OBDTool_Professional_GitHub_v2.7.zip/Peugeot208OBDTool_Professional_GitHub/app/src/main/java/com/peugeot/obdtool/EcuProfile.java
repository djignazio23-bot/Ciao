package com.peugeot.obdtool;

import java.util.Locale;

public final class EcuProfile {
    public final String vin;
    public final String protocol;
    public final String calibrationId;
    public final String cvn;
    public final String ecuName;
    public final String family;
    public final boolean exactFamilyMatch;

    private EcuProfile(String vin, String protocol, String calibrationId, String cvn, String ecuName,
                       String family, boolean exactFamilyMatch) {
        this.vin=vin; this.protocol=protocol; this.calibrationId=calibrationId; this.cvn=cvn; this.ecuName=ecuName;
        this.family=family; this.exactFamilyMatch=exactFamilyMatch;
    }

    public static EcuProfile detect(String vin, String protocol, String calibrationId, String cvn, String ecuName){
        String all=((calibrationId==null?"":calibrationId)+" "+(ecuName==null?"":ecuName)).toUpperCase(Locale.ROOT);
        String family="ECU motore OBD-II rilevata";
        boolean exact=false;
        if(all.contains("MG1CS032")){ family="Bosch MG1CS032"; exact=true; }
        else if(all.contains("MG1CS")){ family="Bosch MG1CS (variante da identificare)"; }
        else if(all.contains("BOSCH")){ family="Bosch (famiglia non determinata da Mode 09)"; }
        else if(all.contains("CONTINENTAL")||all.contains("SID")){ family="Continental/Siemens (famiglia da identificare)"; }
        return new EcuProfile(vin,protocol,calibrationId,cvn,ecuName,family,exact);
    }

    public String summary(){
        StringBuilder s=new StringBuilder();
        s.append("Profilo veicolo: Peugeot 208 II 1.2 PureTech 100\n");
        s.append("ECU: ").append(family).append(exactFamilyMatch?" (match esatto)":" (auto-detect)").append("\n");
        s.append("Protocollo: ").append(empty(protocol)?"N/D":protocol).append("\n");
        s.append("Calibration ID: ").append(empty(calibrationId)?"N/D":calibrationId).append("\n");
        s.append("CVN: ").append(empty(cvn)?"N/D":cvn).append("\n");
        s.append("ECU name: ").append(empty(ecuName)?"N/D":ecuName);
        return s.toString();
    }

    public String testPolicy(){
        if(exactFamilyMatch) return "AUTO PROFILE: MG1CS032 confermata • test OBD estesi adattati • scritture proprietarie disabilitate";
        return "AUTO PROFILE: ECU identificata via Mode 09 • test OBD adattivi • funzioni proprietarie PSA bloccate finché la famiglia non è confermata";
    }

    private static boolean empty(String s){ return s==null||s.trim().isEmpty(); }
}
