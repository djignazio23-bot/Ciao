package com.peugeot.obdtool;

import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

public final class ObdParser {
    private ObdParser() {}

    public static String hexOnly(String s) { return s == null ? "" : s.toUpperCase(Locale.ROOT).replaceAll("[^0-9A-F]", ""); }

    private static int[] bytesAfter(String raw, String marker, int count) {
        String h = hexOnly(raw), m = marker.toUpperCase(Locale.ROOT);
        int i = h.indexOf(m);
        if (i < 0) return null;
        i += m.length();
        if (h.length() < i + count * 2) return null;
        int[] b = new int[count];
        try {
            for (int n = 0; n < count; n++) b[n] = Integer.parseInt(h.substring(i + n * 2, i + n * 2 + 2), 16);
            return b;
        } catch (Exception e) { return null; }
    }

    public static double rpm(String raw){ int[] b=bytesAfter(raw,"410C",2); return b==null?-1:((b[0]*256+b[1])/4.0); }
    public static int speed(String raw){ int[] b=bytesAfter(raw,"410D",1); return b==null?-1:b[0]; }
    public static int coolant(String raw){ int[] b=bytesAfter(raw,"4105",1); return b==null?-999:b[0]-40; }
    public static int map(String raw){ int[] b=bytesAfter(raw,"410B",1); return b==null?-1:b[0]; }
    public static int baro(String raw){ int[] b=bytesAfter(raw,"4133",1); return b==null?-1:b[0]; }
    public static int intakeTemp(String raw){ int[] b=bytesAfter(raw,"410F",1); return b==null?-999:b[0]-40; }
    public static double throttle(String raw){ int[] b=bytesAfter(raw,"4111",1); return b==null?-1:(b[0]*100.0/255.0); }
    public static double engineLoad(String raw){ int[] b=bytesAfter(raw,"4104",1); return b==null?-1:(b[0]*100.0/255.0); }
    public static double fuelTrim(String raw,String pid){ int[] b=bytesAfter(raw,"41"+pid,1); return b==null?-999:(b[0]-128)*100.0/128.0; }
    public static double timingAdvance(String raw){ int[] b=bytesAfter(raw,"410E",1); return b==null?-999:(b[0]/2.0)-64.0; }
    public static double maf(String raw){ int[] b=bytesAfter(raw,"4110",2); return b==null?-1:(b[0]*256+b[1])/100.0; }
    public static double fuelPressure(String raw){ int[] b=bytesAfter(raw,"410A",1); return b==null?-1:b[0]*3.0; }
    public static double railPressure(String raw){ int[] b=bytesAfter(raw,"4123",2); return b==null?-1:(b[0]*256.0+b[1])*10.0; }
    public static double commandedLambda(String raw){ int[] b=bytesAfter(raw,"4144",2); return b==null?-1:(b[0]*256.0+b[1])/32768.0; }


    public static int engineRuntime(String raw){ int[] b=bytesAfter(raw,"411F",2); return b==null?-1:(b[0]*256+b[1]); }
    public static int distanceWithMil(String raw){ int[] b=bytesAfter(raw,"4121",2); return b==null?-1:(b[0]*256+b[1]); }
    public static double evapPurge(String raw){ int[] b=bytesAfter(raw,"412E",1); return b==null?-1:(b[0]*100.0/255.0); }
    public static double fuelLevel(String raw){ int[] b=bytesAfter(raw,"412F",1); return b==null?-1:(b[0]*100.0/255.0); }
    public static int warmupsSinceClear(String raw){ int[] b=bytesAfter(raw,"4130",1); return b==null?-1:b[0]; }
    public static int distanceSinceClear(String raw){ int[] b=bytesAfter(raw,"4131",2); return b==null?-1:(b[0]*256+b[1]); }
    public static int ambientTemp(String raw){ int[] b=bytesAfter(raw,"4146",1); return b==null?-999:b[0]-40; }
    public static double moduleVoltage(String raw){ int[] b=bytesAfter(raw,"4142",2); return b==null?-1:(b[0]*256.0+b[1])/1000.0; }
    public static double o2VoltageB1S1(String raw){ int[] b=bytesAfter(raw,"4114",2); return b==null?-1:b[0]/200.0; }

    public static String readinessSummary(String raw){
        int[] b=bytesAfter(raw,"4101",4);
        if(b==null) return "N/D";
        boolean mil=(b[0]&0x80)!=0; int dtc=b[0]&0x7F;
        int supported=((b[1]&0xFF)<<16)|((b[2]&0xFF)<<8)|(b[3]&0xFF);
        int incomplete=0;
        // Bit pairs vary by spark/compression ignition; counting set incomplete flags is still useful as a compact indicator.
        for(int i=0;i<12;i++){ if((supported&(1<<i))!=0) incomplete++; }
        return "MIL "+(mil?"ON":"OFF")+" • DTC memorizzati: "+dtc+" • readiness raw: "+String.format(Locale.ROOT,"%02X %02X %02X",b[1],b[2],b[3]);
    }

    public static double parseVoltage(String raw){
        if(raw==null) return -1;
        String x=raw.toUpperCase(Locale.ROOT).replace("V","").trim();
        try{return Double.parseDouble(x.replace(',','.'));}catch(Exception e){return -1;}
    }

    public static List<String> dtcs(String raw){
        String h=hexOnly(raw); int idx=h.indexOf("43"); List<String> out=new ArrayList<>(); if(idx<0)return out; h=h.substring(idx+2);
        for(int i=0;i+3<h.length();i+=4){ String w=h.substring(i,i+4); if("0000".equals(w))continue; try{int v=Integer.parseInt(w,16); char[] t={'P','C','B','U'}; char prefix=t[(v>>14)&3]; int d1=(v>>12)&3; int rest=v&0xFFF; out.add(String.format(Locale.ROOT,"%c%d%03X",prefix,d1,rest));}catch(Exception ignored){} }
        return out;
    }

    public static String mode09Ascii(String raw, String responseMarker){
        if(raw==null) return "";
        String h=hexOnly(raw);
        String marker=responseMarker.toUpperCase(Locale.ROOT);
        StringBuilder out=new StringBuilder();
        int from=0;
        while(true){
            int idx=h.indexOf(marker,from);
            if(idx<0) break;
            int start=idx+marker.length();
            // Mode 09 multi-frame responses may carry a sequence byte immediately after the PID.
            if(start+2<=h.length()){
                try{ int seq=Integer.parseInt(h.substring(start,start+2),16); if(seq<=0x20) start+=2; }catch(Exception ignored){}
            }
            int next=h.indexOf(marker,start);
            int end=next>=0?next:h.length();
            for(int i=start;i+1<end;i+=2){
                try{
                    int v=Integer.parseInt(h.substring(i,i+2),16);
                    if(v>=32&&v<=126) out.append((char)v);
                }catch(Exception ignored){}
            }
            from=end;
            if(next<0) break;
        }
        return out.toString().replaceAll("[^A-Za-z0-9._\\-/ ]","").trim();
    }

    public static String calibrationId(String raw){ return mode09Ascii(raw,"4904"); }
    public static String ecuName(String raw){ return mode09Ascii(raw,"490A"); }

    public static String cvn(String raw){
        if(raw==null) return "";
        String h=hexOnly(raw);
        int idx=h.indexOf("4906");
        if(idx<0) return "";
        idx+=4;
        if(idx+2<=h.length()){
            try{int seq=Integer.parseInt(h.substring(idx,idx+2),16); if(seq<=0x20) idx+=2;}catch(Exception ignored){}
        }
        String data=h.substring(Math.min(idx,h.length()));
        if(data.length()<8) return data;
        StringBuilder out=new StringBuilder();
        for(int i=0;i+7<data.length();i+=8){ if(out.length()>0) out.append(" "); out.append(data, i, i+8); }
        return out.toString();
    }

    public static String vin(String raw){
        if(raw==null)return ""; String h=hexOnly(raw); int idx=h.indexOf("4902"); if(idx<0)return "";
        StringBuilder ascii=new StringBuilder();
        for(int i=idx+4;i+1<h.length();i+=2){ try{int v=Integer.parseInt(h.substring(i,i+2),16); if(v>=32&&v<=90) ascii.append((char)v);}catch(Exception ignored){} }
        String s=ascii.toString().replaceAll("[^A-HJ-NPR-Z0-9]",""); return s.length()>=17?s.substring(s.length()-17):s;
    }
}
