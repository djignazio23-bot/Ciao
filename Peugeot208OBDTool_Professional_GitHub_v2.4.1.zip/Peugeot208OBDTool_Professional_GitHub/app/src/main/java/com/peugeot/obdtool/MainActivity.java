package com.peugeot.obdtool;

import android.Manifest;
import android.app.AlertDialog;
import android.bluetooth.BluetoothAdapter;
import android.bluetooth.BluetoothDevice;
import android.bluetooth.BluetoothManager;
import android.content.pm.PackageManager;
import android.content.Context;
import android.content.Intent;
import androidx.core.content.FileProvider;
import android.provider.Settings;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;

import com.peugeot.obdtool.databinding.ActivityMainBinding;

import java.io.File;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;
import java.util.Set;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

public class MainActivity extends AppCompatActivity {
    private static final int REQ_BT=50;
    private ActivityMainBinding b;
    private BluetoothAdapter bt;
    private final List<BluetoothDevice> devices=new ArrayList<>();
    private final Elm327Client elm=new Elm327Client();
    private final ExecutorService io=Executors.newSingleThreadExecutor();
    private final Handler handler=new Handler(Looper.getMainLooper());
    private final CsvLogger logger=new CsvLogger();
    private volatile boolean live=false, logging=false;
    private final Runnable liveTask=new Runnable(){@Override public void run(){if(!live)return; pollLive(); handler.postDelayed(this,900);}};

    @Override protected void onCreate(Bundle saved){
        super.onCreate(saved);
        try {
            b=ActivityMainBinding.inflate(getLayoutInflater());
            setContentView(b.getRoot());
            bind();
            showPage(b.pageDashboard);
            initBluetooth();
            requestBtAndLoad();
        } catch (Throwable t) {
            showStartupError(t);
        }
    }

    private void initBluetooth(){
        try {
            BluetoothManager bm=(BluetoothManager)getSystemService(Context.BLUETOOTH_SERVICE);
            bt=bm==null?null:bm.getAdapter();
        } catch (Throwable t) {
            bt=null;
            if(b!=null) setStatus("Bluetooth non inizializzato",false);
        }
    }

    private void showStartupError(Throwable t){
        try {
            android.widget.TextView tv=new android.widget.TextView(this);
            tv.setPadding(40,40,40,40);
            tv.setTextSize(16f);
            tv.setText("208 OBD PRO\n\nErrore di avvio intercettato:\n"+t.getClass().getSimpleName()+"\n"+(t.getMessage()==null?"Nessun dettaglio":t.getMessage())+"\n\nRiavvia l'app dopo aver concesso i permessi Bluetooth.");
            setContentView(tv);
        } catch (Throwable ignored) {}
    }

    private void bind(){
        b.tabDashboard.setOnClickListener(v->showPage(b.pageDashboard)); b.tabDiagnostics.setOnClickListener(v->showPage(b.pageDiagnostics)); b.tabAdvanced.setOnClickListener(v->showPage(b.pageAdvanced)); b.tabLogs.setOnClickListener(v->showPage(b.pageLogs));
        b.connectButton.setOnClickListener(v->connectSelected());
        b.liveToggleButton.setOnClickListener(v->toggleLive());
        b.coldStartButton.setOnClickListener(v->toggleLogging());
        b.shareSessionButton.setOnClickListener(v->shareLastSession());
        b.vehicleInfoButton.setOnClickListener(v->readVehicleInfo());
        b.readDtcButton.setOnClickListener(v->readDtcs()); b.clearDtcButton.setOnClickListener(v->confirmClear()); b.mode06Button.setOnClickListener(v->readMode06());
        b.precheckButton.setOnClickListener(v->runPrecheck(false)); b.resetButton.setOnClickListener(v->confirmReset());
        b.sendButton.setOnClickListener(v->sendConsole()); b.clearLogButton.setOnClickListener(v->b.logText.setText(""));
    }

    private void showPage(View page){b.pageDashboard.setVisibility(View.GONE);b.pageDiagnostics.setVisibility(View.GONE);b.pageAdvanced.setVisibility(View.GONE);b.pageLogs.setVisibility(View.GONE);page.setVisibility(View.VISIBLE);}

    private void requestBtAndLoad(){
        if(Build.VERSION.SDK_INT>=31){
            boolean connect=ActivityCompat.checkSelfPermission(this,Manifest.permission.BLUETOOTH_CONNECT)==PackageManager.PERMISSION_GRANTED;
            if(!connect){
                ActivityCompat.requestPermissions(this,new String[]{Manifest.permission.BLUETOOTH_CONNECT},REQ_BT);
                return;
            }
        }
        loadBonded();
    }
    private void loadBonded(){if(bt==null){setStatus("Bluetooth non disponibile",false);return;} devices.clear();List<String> names=new ArrayList<>();try{Set<BluetoothDevice> bonded=bt.getBondedDevices();for(BluetoothDevice d:bonded){devices.add(d);names.add((d.getName()==null?"Dispositivo":d.getName())+"  •  "+d.getAddress());}}catch(SecurityException e){setStatus("Permesso Bluetooth mancante",false);} b.deviceSpinner.setAdapter(new ArrayAdapter<>(this,android.R.layout.simple_spinner_dropdown_item,names));if(names.isEmpty())setStatus("Abbina prima l'ELM327 dalle impostazioni Bluetooth",false);}

    private void connectSelected(){if(devices.isEmpty()){toast("Nessun dispositivo Bluetooth associato");return;}BluetoothDevice d=devices.get(b.deviceSpinner.getSelectedItemPosition());setStatus("Connessione in corso…",false);io.execute(()->{try{elm.connect(d);String id=elm.adapterId(),proto=elm.protocol(),volt=elm.voltage();ui(()->{setStatus("Connesso",true);b.adapterInfo.setText("Adapter: "+id+"  •  "+volt);b.protocolText.setText(proto);b.ecuSummary.setText("Protocollo: "+proto);log("Connesso a "+id+" | "+proto+" | "+volt);});}catch(Exception e){elm.close();ui(()->{setStatus("Connessione fallita",false);log("ERRORE connessione: "+e.getMessage());});}});}

    private void toggleLive(){if(!ensureConnected())return;live=!live;if(live){b.liveToggleButton.setText("Ferma live data");handler.post(liveTask);log("Live data avviati");}else{handler.removeCallbacks(liveTask);b.liveToggleButton.setText("Avvia live data");log("Live data fermati");}}
    private void toggleLogging(){
        if(!ensureConnected())return;
        if(!logging){
            try{
                File f=logger.start(this,"ai_session");
                logging=true;
                b.coldStartButton.setText("Ferma AI Diagnostic Mode");
                b.aiStatusText.setText("AI SESSION: RECORDING • dati salvati localmente");
                b.shareSessionButton.setEnabled(false);
                if(!live){live=true;b.liveToggleButton.setText("Ferma live data");handler.post(liveTask);}
                log("AI Diagnostic Mode avviata: "+f.getAbsolutePath());
            }catch(Exception e){log("Impossibile avviare sessione AI: "+e.getMessage());}
        }else{
            logging=false;
            b.coldStartButton.setText("Avvia AI Diagnostic Mode");
            File f=logger.getFile();
            b.aiStatusText.setText("AI SESSION: PRONTA DA CONDIVIDERE");
            b.shareSessionButton.setEnabled(f!=null && f.exists());
            log("AI Diagnostic Mode terminata: "+(f==null?"—":f.getAbsolutePath()));
        }
    }

    private void shareLastSession(){
        File f=logger.getFile();
        if(f==null || !f.exists()){toast("Nessuna sessione registrata");return;}
        try{
            android.net.Uri uri=FileProvider.getUriForFile(this,getPackageName()+".fileprovider",f);
            Intent share=new Intent(Intent.ACTION_SEND);
            share.setType("text/csv");
            share.putExtra(Intent.EXTRA_STREAM,uri);
            share.putExtra(Intent.EXTRA_SUBJECT,"208 OBD PRO - AI Diagnostic Session");
            share.putExtra(Intent.EXTRA_TEXT,"Analizza questa sessione OBD della mia Peugeot 208. Crea un report completo su avviamento a freddo, candele/bobine e combustione, fuel trim/lambda, aspirazione, turbo/boost, temperature, MAF/MAP, pressione carburante e tensione. Distingui dati certi da ipotesi e segnala i PID non supportati.");
            share.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);
            startActivity(Intent.createChooser(share,"Condividi sessione con ChatGPT"));
        }catch(Exception e){log("Condivisione sessione: "+e.getMessage());toast("Impossibile condividere il CSV");}
    }

    private String readSafe(String cmd, long timeoutMs){
        try { return elm.command(cmd, timeoutMs); } catch (Exception ignored) { return ""; }
    }

    private void pollLive(){
        if(!elm.isConnected())return;
        io.execute(()->{
            try{
                double rpm=ObdParser.rpm(readSafe("010C",850));
                int speed=ObdParser.speed(readSafe("010D",850));
                int coolant=ObdParser.coolant(readSafe("0105",850));
                int map=ObdParser.map(readSafe("010B",850));
                int baro=ObdParser.baro(readSafe("0133",850));
                double throttle=ObdParser.throttle(readSafe("0111",850));
                double load=ObdParser.engineLoad(readSafe("0104",850));
                double stft=ObdParser.fuelTrim(readSafe("0106",850),"06");
                double ltft=ObdParser.fuelTrim(readSafe("0107",850),"07");
                double timing=ObdParser.timingAdvance(readSafe("010E",850));
                int iat=ObdParser.intakeTemp(readSafe("010F",850));
                double maf=ObdParser.maf(readSafe("0110",850));
                double fuelPressure=ObdParser.fuelPressure(readSafe("010A",850));
                double railPressure=ObdParser.railPressure(readSafe("0123",850));
                double lambda=ObdParser.commandedLambda(readSafe("0144",850));
                double voltage=ObdParser.parseVoltage(readSafe("ATRV",850));
                double boost=(map>0 && baro>0)?map-baro:-999;

                // -100% a motore spento/risposta non valida non deve entrare nel report come vero LTFT.
                if(rpm>=0 && rpm<50 && ltft<=-99.0) ltft=-999;
                if(rpm>=0 && rpm<50 && stft<=-99.0) stft=-999;

                if(logging) try {
                    logger.append(System.currentTimeMillis(),rpm,speed,coolant,map,baro,boost,throttle,load,stft,ltft,
                            timing,iat,maf,fuelPressure,railPressure,lambda,voltage);
                } catch(Exception e){ logUi("CSV: "+e.getMessage()); }

                final double fStft=stft, fLtft=ltft;
                ui(()->updateMetrics(rpm,speed,coolant,map,baro,boost,throttle,load,fStft,fLtft,timing,iat,maf,fuelPressure,railPressure,lambda,voltage));
            }catch(Exception e){logUi("Live data: "+e.getMessage());}
        });
    }

    private void updateMetrics(double rpm,int speed,int coolant,int map,int baro,double boost,double throttle,double load,double stft,double ltft,
                               double timing,int iat,double maf,double fuelPressure,double railPressure,double lambda,double voltage){
        b.rpmValue.setText(rpm<0?"—":String.format(Locale.ITALY,"%.0f",rpm));
        b.speedValue.setText(speed<0?"—":String.valueOf(speed));
        b.coolantValue.setText(coolant==-999?"—":String.valueOf(coolant));
        b.mapValue.setText(map<0?"—":String.valueOf(map));
        b.throttleValue.setText(throttle<0?"—":String.format(Locale.ITALY,"%.1f",throttle));
        b.voltageValue.setText(voltage<0?"—":String.format(Locale.ITALY,"%.2f",voltage));
        b.fuelTrimText.setText(String.format(Locale.ITALY,"STFT: %s    LTFT: %s",stft==-999?"—":String.format(Locale.ITALY,"%.1f%%",stft),ltft==-999?"—":String.format(Locale.ITALY,"%.1f%%",ltft)));

        String boostTxt=boost==-999?"N/D":String.format(Locale.ITALY,"%+.0f kPa (%+.2f bar)",boost,boost/100.0);
        String baroTxt=baro<0?"N/D":baro+" kPa";
        b.turboText.setText("MAP: "+(map<0?"N/D":map+" kPa")+"  •  BARO: "+baroTxt+"\nBoost calcolato: "+boostTxt+"  •  Carico: "+fmtPct(load));

        String timingTxt=timing==-999?"N/D":String.format(Locale.ITALY,"%.1f°",timing);
        String iatTxt=iat==-999?"N/D":iat+" °C";
        String mafTxt=maf<0?"N/D":String.format(Locale.ITALY,"%.2f g/s",maf);
        String fp=fuelPressure<0?"N/D":String.format(Locale.ITALY,"%.0f kPa",fuelPressure);
        String rp=railPressure<0?"N/D":String.format(Locale.ITALY,"%.0f kPa",railPressure);
        String lam=lambda<0?"N/D":String.format(Locale.ITALY,"%.3f",lambda);
        b.ignitionText.setText("Anticipo: "+timingTxt+"  •  IAT: "+iatTxt+"\nMAF: "+mafTxt+"  •  Lambda cmd: "+lam+"\nFuel pressure: "+fp+"  •  Rail: "+rp);

        if(rpm>=0)b.rpmGraph.addValue((float)rpm);
        b.aiInsightText.setText(buildAiInsight(rpm,coolant,map,boost,stft,ltft,voltage));
    }

    private String fmtPct(double v){ return v<0?"N/D":String.format(Locale.ITALY,"%.1f%%",v); }

    private String buildAiInsight(double rpm,int coolant,int map,double boost,double stft,double ltft,double voltage){
        List<String> flags=new ArrayList<>();
        if(voltage>0){
            if(rpm>400 && voltage<13.0) flags.add("tensione di carica bassa");
            if(rpm>=0 && rpm<50 && voltage<11.8) flags.add("batteria sotto 11,8 V");
        }
        if(stft!=-999 && ltft!=-999 && Math.abs(stft+ltft)>20.0) flags.add("correzione carburazione elevata");
        if(rpm>600 && map>0 && map<18) flags.add("MAP insolitamente basso");
        if(coolant!=-999 && coolant>110) flags.add("temperatura refrigerante elevata");
        if(boost!=-999 && boost>80) flags.add("boost elevato: verificare coerenza con carico/RPM");
        if(flags.isEmpty()) return logging?"AI: acquisizione estesa in corso • accensione/turbo/fuel inclusi":"AI: valori live disponibili • avvia una sessione per il report";
        return "AI indicatori: "+String.join(" • ",flags)+". Indicazioni preliminari, non diagnosi.";
    }

    private void readMode06(){
        if(!ensureConnected())return;
        io.execute(()->{
            StringBuilder out=new StringBuilder("MODE $06 (read-only)\n");
            String[] cmds={"0600","0620","0640","0660","0680","06A0","06C0"};
            for(String cmd:cmds){
                String r=readSafe(cmd,1800);
                if(!r.isEmpty() && !r.toUpperCase(Locale.ROOT).contains("NO DATA")) out.append(cmd).append(": ").append(r).append("\n");
            }
            ui(()->{
                b.mode06Text.setText(out.length()<=20?"Nessun dato Mode $06 disponibile":out.toString());
                log("Scansione Mode $06 completata (sola lettura)");
            });
        });
    }

    private void readVehicleInfo(){if(!ensureConnected())return;io.execute(()->{try{String vinRaw=elm.command("0902",3000),proto=elm.protocol(),id=elm.adapterId();String vin=ObdParser.vin(vinRaw);ui(()->{b.vinText.setText("VIN: "+(vin.isEmpty()?"non disponibile":vin));b.ecuSummary.setText("Protocollo: "+proto+"\nInterfaccia: "+id);log("Vehicle info | VIN raw: "+vinRaw);});}catch(Exception e){logUi("Vehicle info: "+e.getMessage());}});}
    private void readDtcs(){if(!ensureConnected())return;io.execute(()->{try{String raw=elm.command("03",3000);List<String> dtcs=ObdParser.dtcs(raw);ui(()->{b.dtcText.setText(dtcs.isEmpty()?"Nessun DTC OBD-II rilevato":String.join("\n",dtcs));log("DTC RAW: "+raw);});}catch(Exception e){logUi("DTC: "+e.getMessage());}});}
    private void confirmClear(){new AlertDialog.Builder(this).setTitle("Cancella DTC").setMessage("Cancella i codici OBD e i relativi freeze-frame. Non risolve la causa del guasto.").setNegativeButton("Annulla",null).setPositiveButton("Cancella",(d,w)->sendSafe("04","CLEAR DTC")).show();}

    private void runPrecheck(boolean thenReset){if(!ensureConnected())return;io.execute(()->{try{int speed=ObdParser.speed(elm.command("010D",1200));double rpm=ObdParser.rpm(elm.command("010C",1200));double voltage=ObdParser.parseVoltage(elm.voltage());boolean verified=speed>=0&&rpm>=0&&voltage>0;boolean safe=verified&&speed==0&&rpm<1&&voltage>=11.8;String msg=!verified?"BLOCCATO • dati non verificabili":safe?String.format(Locale.ITALY,"OK • 0 km/h • motore spento • %.2f V",voltage):String.format(Locale.ITALY,"BLOCCATO • %d km/h • %.0f rpm • %.2f V",speed,rpm,voltage);ui(()->{b.safetyText.setText("Safety gate: "+msg);log("Pre-check reset: "+msg);});if(safe&&thenReset)performEcuReset();}catch(Exception e){logUi("Pre-check: "+e.getMessage());}});}
    private void confirmReset(){new AlertDialog.Builder(this).setTitle("Soft reset ECU motore").setMessage("Il programma eseguirà nuovamente il safety gate. Non verranno toccati radio, infotainment, immobilizer, airbag o firmware ECU. Continuare solo con vettura ferma, motore spento e quadro acceso.").setNegativeButton("Annulla",null).setPositiveButton("Esegui pre-check e reset",(d,w)->runPrecheck(true)).show();}
    private void performEcuReset(){try{String hOn=elm.command("ATH1",800);elm.command("ATSH7E0",800);String resp=elm.command("1101",2200);elm.restoreAutomaticProtocol();String hex=ObdParser.hexOnly(resp);ui(()->{if(hex.contains("5101")){b.safetyText.setText("Safety gate: reset ECU accettato");setStatus("ECU riavviata — riconnessione consigliata",true);log("RESET ECU ACCETTATO: "+resp);}else{b.safetyText.setText("Safety gate: reset non confermato");log("RESET NON CONFERMATO/SUPPORTATO: "+resp);}});}catch(Exception e){elm.restoreAutomaticProtocol();logUi("Reset ECU: "+e.getMessage());}}

    private void sendConsole(){String cmd=b.commandInput.getText().toString().trim().toUpperCase(Locale.ROOT);if(cmd.isEmpty())return;if(isBlockedConsoleCommand(cmd)){new AlertDialog.Builder(this).setTitle("Comando bloccato").setMessage("La console Pro non consente comandi di flashing/programmazione firmware, immobilizer o scritture su moduli di sicurezza.").setPositiveButton("OK",null).show();return;}sendSafe(cmd,"CONSOLE");}
    private boolean isBlockedConsoleCommand(String cmd){String c=cmd.replace(" ","");return c.startsWith("34")||c.startsWith("35")||c.startsWith("36")||c.startsWith("37")||c.startsWith("270")||c.startsWith("2E")||c.startsWith("2F")||c.startsWith("3101");}
    private void sendSafe(String cmd,String label){if(!ensureConnected())return;io.execute(()->{try{String r=elm.command(cmd,3000);logUi(label+" > "+cmd+"\n"+r);}catch(Exception e){logUi(label+": "+e.getMessage());}});}

    private boolean ensureConnected(){if(elm.isConnected())return true;toast("Connetti prima l'ELM327");return false;}
    private void setStatus(String s,boolean ok){b.statusText.setText(s);b.statusDot.setBackgroundColor(getColor(ok?R.color.ok:R.color.danger));}
    private void log(String s){String stamp=java.text.DateFormat.getTimeInstance().format(new java.util.Date());b.logText.append("\n["+stamp+"] "+s+"\n");}
    private void logUi(String s){ui(()->log(s));}
    private void ui(Runnable r){runOnUiThread(r);} private void toast(String s){Toast.makeText(this,s,Toast.LENGTH_SHORT).show();}

    @Override public void onRequestPermissionsResult(int req,@NonNull String[] p,@NonNull int[] g){
        super.onRequestPermissionsResult(req,p,g);
        if(req==REQ_BT){
            boolean granted=g.length>0&&g[0]==PackageManager.PERMISSION_GRANTED;
            if(granted) loadBonded();
            else {
                setStatus("Permesso Bluetooth necessario",false);
                toast("Concedi il permesso Dispositivi nelle vicinanze per usare ELM327");
            }
        }
    }
    @Override protected void onDestroy(){live=false;handler.removeCallbacks(liveTask);elm.close();io.shutdownNow();super.onDestroy();}
}
