package com.peugeot208technician.app

object Peugeot208Profile {
    const val VEHICLE = "Peugeot 208 II • 2022 • 1.2 PureTech Turbo 100 CV • HNK/EB2ADT • cambio manuale"
    const val CONNECTION = "Android → ELM327 Bluetooth Classic/BLE oppure USB/OTG → presa OBD-II"
    const val EXPECTED_PROTOCOL = "ISO 15765-4 CAN 11 bit / 500 kbit/s"
    const val KNOWN_CALIBRATION_ID = "9609SsCS"
    const val KNOWN_CVN = "A86E9F62"

    val focusNotes = listOf(
        "Avviamento a freddo / P050B: registra ECT, IAT, anticipo, RPM, carico, fuel trim e tensione.",
        "Consumi: osserva fuel trim, MAP/MAF se supportati, temperatura e carico; il consumo stimato resta indicativo.",
        "Rumore frizione/cambio: è soprattutto meccanico e non è diagnosticabile direttamente via OBD-II.",
        "Cinghia a bagno d'olio: lo stato fisico non è misurabile via OBD-II; servono ispezione e procedure meccaniche corrette.",
        "Codici PSA/UDS proprietari: questa build non inventa descrizioni né effettua coding, security access o test attuatori."
    )
}
