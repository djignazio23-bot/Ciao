# Chrome Ad Shield MAX
Versione aggressiva per Chrome Android.

- VPN DNS locale per domini pubblicitari noti.
- AccessibilityService per leggere l'URL della scheda Chrome e tornare automaticamente indietro su redirect esterni.
- Modalita protetta attivata quando l'URL contiene un pattern configurato (default: `streamingcommunity`).
- `aj267.com` bloccato esplicitamente.

Dopo l'installazione:
1. Apri Chrome Ad Shield MAX.
2. Attiva Filtro VPN/DNS.
3. Lascia attivo Blocca TUTTI i redirect esterni in Chrome.
4. Tocca ATTIVA CONTROLLO CHROME (ACCESSIBILITA) e abilita Chrome Redirect Guard.
5. Apri Streaming Community in Chrome.

Per navigare liberamente altrove, disattiva la modalita aggressiva nell'app.
