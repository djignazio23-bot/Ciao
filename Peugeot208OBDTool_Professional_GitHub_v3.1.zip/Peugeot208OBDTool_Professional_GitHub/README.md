# Chrome Ad Shield

App Android sperimentale che usa `VpnService` come filtro DNS locale. È pensata per funzionare mentre navighi con Chrome Android.

## Cosa blocca
- domini pubblicitari presenti nella lista dell'app;
- redirect verso domini pubblicitari noti;
- richieste DNS verso sottodomini dei domini bloccati.

## Cosa NON può bloccare
- popup o nuove schede generati interamente dallo stesso dominio del sito;
- pubblicità servite dallo stesso hostname del video/sito;
- contenuti già caricati prima dell'attivazione.

## Installazione / build
1. Apri la cartella con Android Studio.
2. Attendi il sync Gradle.
3. Collega il telefono Android con Debug USB attivo oppure genera un APK da **Build > Build APK(s)**.
4. Installa l'APK.
5. Apri l'app, attiva **Protezione attiva** e accetta la richiesta VPN Android.
6. Lascia Chrome configurato con **Popup e reindirizzamenti bloccati**.

## Privacy
Il filtro gira localmente. Le richieste DNS non bloccate vengono inoltrate a `1.1.1.1` (Cloudflare) direttamente dal telefono.

## Build con GitHub Actions

Il progetto include `.github/workflows/build-apk.yml`. Dopo aver caricato i file in un repository GitHub, apri **Actions → Build Android APK → Run workflow**. Al termine scarica l'artifact `ChromeAdShield-debug-apk` e installa `app-debug.apk` sul telefono.
