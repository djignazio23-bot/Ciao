# 208 OBD PRO v3.1 – Live Cylinder Diagnostics

- Mantiene le funzioni della v3.0 (DTC Expert, Freeze Frame, Test Center, Safe ECU Restart, live data, CSV).
- Rimossa completamente la scansione Extended ECU ID / UDS 0x22. Il profilo veicolo usa soltanto Mode 09 OBD-II standard.
- AI Diagnostic Mode esteso con campionamento read-only Mode $06 C1/C2/C3 circa ogni 30 s a motore acceso, quando supportato.
- CSV arricchito con misfire current/EWMA per cilindro, spread/total, età campione, stato monitor misfire, lambda reale campionata, stabilità RPM al minimo e fase motore.
- I dati per cilindro non vengono inventati: se la ECU non espone il mapping standard vengono salvati come -1/N.D.

# 208 OBD PRO v3.0

Peugeot 208 II 1.2 PureTech 100 diagnostic companion for Bluetooth Classic ELM327.

## v3.0 Deep Engine Diagnostics
- ECU Auto Profile + read-only UDS Extended Identification.
- Structured SAE J1979 Mode $06 misfire scan for the 3-cylinder EB2 engine:
  - OBDMID A2 = cylinder 1
  - OBDMID A3 = cylinder 2
  - OBDMID A4 = cylinder 3
  - TID 0C = current/last driving-cycle misfire counts
  - TID 0B = EWMA misfire counts over the last 10 driving cycles
- Standard wideband equivalence-ratio (actual lambda) lookup when the ECU advertises a compatible PID.
- Confirmed, pending and permanent OBD-II DTC separation in the emissions/readiness report.
- Existing live data, CSV AI Diagnostic Mode, turbo/fuel/temperature/charging tests and Safe ECU Restart retained.

## Safety
Default use is read-only. Extended ECU identification has been removed. Mode $06 and Mode $01 diagnostics are read-only. Proprietary PSA writes, coding, flashing, immobilizer and safety-module programming remain blocked.
