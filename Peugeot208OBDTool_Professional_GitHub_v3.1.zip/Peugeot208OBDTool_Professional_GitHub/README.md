# Streaming Community Shield

Versione 3.0 "Streaming-only".

- Nessuna VPN globale.
- Nessun blocco sugli altri siti.
- Il servizio di Accessibilità si arma solo quando Chrome mostra un URL Streaming Community.
- Se subito dopo compare una nuova scheda / popup / redirect esterno, esegue BACK una volta e si disarma.
- Quando Chrome torna su Streaming Community, si riarma automaticamente.

Dopo l'installazione: aprire l'app, lasciare attiva "Protezione solo Streaming Community" e abilitare "Streaming Community Redirect Guard" nelle impostazioni Accessibilità di Android.
