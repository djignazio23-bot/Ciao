package com.example.chromeadshield

import android.accessibilityservice.AccessibilityService
import android.net.Uri
import android.os.SystemClock
import android.view.accessibility.AccessibilityEvent
import android.view.accessibility.AccessibilityNodeInfo
import java.util.Locale

/**
 * Protezione limitata a Streaming Community.
 *
 * Il servizio NON interviene durante la normale navigazione in Chrome.
 * Si arma soltanto quando rileva un URL il cui host contiene "streamingcommunity".
 * Se, subito dopo, una pubblicità / popup / redirect porta Chrome fuori da quel sito,
 * esegue BACK una sola volta. Quando Chrome torna su Streaming Community si riarma.
 */
class RedirectGuardAccessibilityService : AccessibilityService() {
    private val prefs by lazy { getSharedPreferences("shield", MODE_PRIVATE) }
    private var lastProtectedSeenAt = 0L
    private var lastBlockedUrl: String? = null
    private var lastBackAt = 0L

    override fun onAccessibilityEvent(event: AccessibilityEvent?) {
        if (event == null || event.packageName?.toString() != CHROME_PACKAGE) return
        if (!prefs.getBoolean("streaming_only_enabled", true)) return

        val root = rootInActiveWindow ?: event.source ?: return
        val rawUrl = readChromeUrl(root)?.trim().orEmpty()
        if (rawUrl.isEmpty()) return

        val normalized = normalizeUrl(rawUrl)
        val host = extractHost(normalized)
        val now = SystemClock.elapsedRealtime()

        if (isStreamingCommunity(host, rawUrl)) {
            lastProtectedSeenAt = now
            return
        }

        // Fuori da Streaming Community il servizio resta inattivo, tranne nella breve
        // finestra immediatamente successiva alla pagina protetta: è lì che nascono
        // normalmente popup, nuove schede e redirect pubblicitari.
        if (lastProtectedSeenAt == 0L || now - lastProtectedSeenAt > ARM_WINDOW_MS) {
            lastProtectedSeenAt = 0L
            return
        }

        val shouldBlock = when {
            rawUrl.equals("about:blank", ignoreCase = true) -> true
            rawUrl.startsWith("intent://", ignoreCase = true) -> true
            rawUrl.startsWith("market://", ignoreCase = true) -> true
            rawUrl.startsWith("tel:", ignoreCase = true) -> true
            rawUrl.startsWith("sms:", ignoreCase = true) -> true
            rawUrl.startsWith("mailto:", ignoreCase = true) -> true
            !host.isNullOrBlank() -> true // qualsiasi uscita verso un altro dominio
            else -> false
        }

        if (shouldBlock) {
            blockNavigation(rawUrl)
            // Disarma dopo un solo BACK. Se Chrome torna su Streaming Community,
            // il prossimo evento lo armerà nuovamente. Così gli altri siti non vengono toccati.
            lastProtectedSeenAt = 0L
        }
    }

    private fun isStreamingCommunity(host: String?, rawUrl: String): Boolean {
        val h = host?.lowercase(Locale.ROOT).orEmpty()
        val u = rawUrl.lowercase(Locale.ROOT)
        return h.contains("streamingcommunity") || u.contains("streamingcommunity")
    }

    private fun readChromeUrl(root: AccessibilityNodeInfo): String? {
        val direct = root.findAccessibilityNodeInfosByViewId("$CHROME_PACKAGE:id/url_bar")
        direct.firstOrNull()?.text?.toString()?.takeIf { it.isNotBlank() }?.let { return it }

        val stack = ArrayDeque<AccessibilityNodeInfo>()
        stack.add(root)
        var visited = 0
        while (stack.isNotEmpty() && visited < 350) {
            val node = stack.removeLast()
            visited++
            val id = node.viewIdResourceName.orEmpty().lowercase(Locale.ROOT)
            if ((id.contains("url_bar") || id.contains("location_bar")) && !node.text.isNullOrBlank()) {
                return node.text.toString()
            }
            for (i in 0 until node.childCount) node.getChild(i)?.let { stack.add(it) }
        }
        return null
    }

    private fun blockNavigation(url: String) {
        val now = SystemClock.elapsedRealtime()
        if (url == lastBlockedUrl && now - lastBackAt < 1200) return
        if (now - lastBackAt < 650) return
        lastBlockedUrl = url
        lastBackAt = now
        performGlobalAction(GLOBAL_ACTION_BACK)
    }

    private fun normalizeUrl(raw: String): String {
        val s = raw.trim()
        if (s.contains("://") || s.startsWith("about:") || s.startsWith("intent:") || s.startsWith("market:")) return s
        return "https://$s"
    }

    private fun extractHost(url: String): String? = try {
        Uri.parse(url).host?.lowercase(Locale.ROOT)
    } catch (_: Exception) {
        null
    }

    override fun onInterrupt() = Unit

    override fun onServiceConnected() {
        super.onServiceConnected()
        lastProtectedSeenAt = 0L
    }

    companion object {
        private const val CHROME_PACKAGE = "com.android.chrome"
        private const val ARM_WINDOW_MS = 12_000L
    }
}
