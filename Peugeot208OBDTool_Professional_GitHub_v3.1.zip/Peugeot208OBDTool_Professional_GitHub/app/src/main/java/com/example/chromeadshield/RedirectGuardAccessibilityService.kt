package com.example.chromeadshield

import android.accessibilityservice.AccessibilityService
import android.net.Uri
import android.os.SystemClock
import android.view.accessibility.AccessibilityEvent
import android.view.accessibility.AccessibilityNodeInfo
import java.util.Locale

class RedirectGuardAccessibilityService : AccessibilityService() {
    private val prefs by lazy { getSharedPreferences("shield", MODE_PRIVATE) }
    private var protectedSession = false
    private var lastSafeUrl: String? = null
    private var lastBlockedUrl: String? = null
    private var lastBackAt = 0L

    override fun onAccessibilityEvent(event: AccessibilityEvent?) {
        if (event == null || event.packageName?.toString() != CHROME_PACKAGE) return
        if (!prefs.getBoolean("aggressive", true)) return

        val root = rootInActiveWindow ?: event.source ?: return
        val rawUrl = readChromeUrl(root)?.trim().orEmpty()
        if (rawUrl.isEmpty()) return

        val normalized = normalizeUrl(rawUrl)
        val host = extractHost(normalized)
        val protectedPatterns = protectedPatterns()
        val explicitBlocked = blockedDomains()

        val isProtectedSite = matchesAny(host, rawUrl, protectedPatterns)
        if (isProtectedSite) {
            protectedSession = true
            lastSafeUrl = normalized
            return
        }

        // The guard only locks Chrome after the user has visited a protected site.
        if (!protectedSession) return

        val mustBlock = when {
            rawUrl.equals("about:blank", ignoreCase = true) -> true
            rawUrl.startsWith("intent://", ignoreCase = true) -> true
            rawUrl.startsWith("market://", ignoreCase = true) -> true
            rawUrl.startsWith("tel:", ignoreCase = true) -> true
            rawUrl.startsWith("sms:", ignoreCase = true) -> true
            rawUrl.startsWith("mailto:", ignoreCase = true) -> true
            host.isNullOrBlank() -> false
            explicitBlocked.any { host == it || host.endsWith(".$it") } -> true
            !isTrustedExternal(host, rawUrl) -> true
            else -> false
        }

        if (mustBlock) blockNavigation(rawUrl)
    }

    private fun readChromeUrl(root: AccessibilityNodeInfo): String? {
        val direct = root.findAccessibilityNodeInfosByViewId("$CHROME_PACKAGE:id/url_bar")
        direct.firstOrNull()?.text?.toString()?.takeIf { it.isNotBlank() }?.let { return it }

        // Fallback for Chrome UI variants: recursively inspect nodes whose id mentions url/location bar.
        val stack = ArrayDeque<AccessibilityNodeInfo>()
        stack.add(root)
        var visited = 0
        while (stack.isNotEmpty() && visited < 350) {
            val node = stack.removeLast()
            visited++
            val id = node.viewIdResourceName.orEmpty().lowercase(Locale.ROOT)
            if ((id.contains("url_bar") || id.contains("location_bar")) && !node.text.isNullOrBlank()) {
                return node.text.toString()
            }
            for (i in 0 until node.childCount) node.getChild(i)?.let { stack.add(it) }
        }
        return null
    }

    private fun blockNavigation(url: String) {
        val now = SystemClock.elapsedRealtime()
        if (url == lastBlockedUrl && now - lastBackAt < 1200) return
        if (now - lastBackAt < 650) return
        lastBlockedUrl = url
        lastBackAt = now
        performGlobalAction(GLOBAL_ACTION_BACK)
    }

    private fun protectedPatterns(): Set<String> {
        val raw = prefs.getString("protected_patterns", DEFAULT_PROTECTED) ?: DEFAULT_PROTECTED
        return raw.lineSequence().map { it.trim().lowercase(Locale.ROOT) }
            .filter { it.isNotEmpty() && !it.startsWith("#") }.toSet()
    }

    private fun trustedExternalDomains(): Set<String> {
        val raw = prefs.getString("trusted_domains", "") ?: ""
        return raw.lineSequence().map { it.trim().lowercase(Locale.ROOT) }
            .filter { it.isNotEmpty() && !it.startsWith("#") }.toSet()
    }

    private fun blockedDomains(): Set<String> {
        val raw = prefs.getString("domains", "") ?: ""
        return raw.lineSequence().map { it.trim().lowercase(Locale.ROOT) }
            .filter { it.isNotEmpty() && !it.startsWith("#") }.toSet()
    }

    private fun isTrustedExternal(host: String, rawUrl: String): Boolean {
        return matchesAny(host, rawUrl, trustedExternalDomains())
    }

    private fun matchesAny(host: String?, rawUrl: String, patterns: Set<String>): Boolean {
        val h = host?.lowercase(Locale.ROOT).orEmpty()
        val u = rawUrl.lowercase(Locale.ROOT)
        return patterns.any { p ->
            when {
                p.isBlank() -> false
                p.contains(".") -> h == p || h.endsWith(".$p")
                else -> h.contains(p) || u.contains(p)
            }
        }
    }

    private fun normalizeUrl(raw: String): String {
        val s = raw.trim()
        if (s.contains("://") || s.startsWith("about:") || s.startsWith("intent:") || s.startsWith("market:")) return s
        return "https://$s"
    }

    private fun extractHost(url: String): String? = try {
        Uri.parse(url).host?.lowercase(Locale.ROOT)
    } catch (_: Exception) { null }

    override fun onInterrupt() = Unit

    override fun onServiceConnected() {
        super.onServiceConnected()
        protectedSession = false
        lastSafeUrl = null
    }

    companion object {
        private const val CHROME_PACKAGE = "com.android.chrome"
        private const val DEFAULT_PROTECTED = "streamingcommunity"
    }
}
