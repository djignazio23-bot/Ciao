package com.example.chromeadshield

import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.Intent
import android.net.VpnService
import android.os.Build
import android.os.ParcelFileDescriptor
import androidx.core.app.NotificationCompat
import java.io.FileInputStream
import java.io.FileOutputStream
import java.net.DatagramPacket
import java.net.DatagramSocket
import java.net.InetAddress
import java.nio.ByteBuffer
import java.util.concurrent.atomic.AtomicBoolean
import kotlin.concurrent.thread

class AdBlockVpnService : VpnService() {
    private var vpnInterface: ParcelFileDescriptor? = null
    private val running = AtomicBoolean(false)
    private val localDnsIp = byteArrayOf(10, 10, 0, 2)

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (running.getAndSet(true)) return START_STICKY
        startForeground(1, buildNotification())

        vpnInterface = Builder()
            .setSession("Chrome Ad Shield")
            .addAddress("10.10.0.1", 32)
            .addDnsServer("10.10.0.2")
            .addRoute("10.10.0.2", 32)
            .setBlocking(true)
            .establish()

        val pfd = vpnInterface ?: run {
            stopSelf(); return START_NOT_STICKY
        }

        thread(name = "dns-vpn") {
            FileInputStream(pfd.fileDescriptor).use { input ->
                FileOutputStream(pfd.fileDescriptor).use { output ->
                    val buffer = ByteArray(32767)
                    while (running.get()) {
                        val len = try { input.read(buffer) } catch (_: Exception) { break }
                        if (len <= 0) continue
                        val response = handlePacket(buffer.copyOf(len)) ?: continue
                        try { output.write(response) } catch (_: Exception) { break }
                    }
                }
            }
        }
        return START_STICKY
    }

    private fun blockedDomains(): Set<String> {
        val raw = getSharedPreferences("shield", MODE_PRIVATE).getString("domains", "") ?: ""
        return raw.lineSequence().map { it.trim().lowercase() }
            .filter { it.isNotEmpty() && !it.startsWith("#") }
            .toSet()
    }

    private fun handlePacket(packet: ByteArray): ByteArray? {
        if (packet.size < 28) return null
        val version = (packet[0].toInt() ushr 4) and 0xF
        if (version != 4) return null
        val ihl = (packet[0].toInt() and 0xF) * 4
        if (packet.size < ihl + 8 || packet[9].toInt() != 17) return null // UDP only

        val dstIp = packet.copyOfRange(16, 20)
        if (!dstIp.contentEquals(localDnsIp)) return null

        val udpOffset = ihl
        val dstPort = ((packet[udpOffset + 2].toInt() and 0xff) shl 8) or (packet[udpOffset + 3].toInt() and 0xff)
        if (dstPort != 53) return null

        val dns = packet.copyOfRange(udpOffset + 8, packet.size)
        val host = parseQName(dns)?.lowercase() ?: return null
        val blocked = blockedDomains().any { host == it || host.endsWith(".$it") }
        val dnsResponse = if (blocked) buildNxDomain(dns) else forwardDns(dns) ?: return null
        return buildUdpIpv4Response(packet, dnsResponse, ihl)
    }

    private fun parseQName(dns: ByteArray): String? {
        if (dns.size < 13) return null
        var i = 12
        val labels = mutableListOf<String>()
        while (i < dns.size) {
            val l = dns[i].toInt() and 0xff
            if (l == 0) break
            if (l > 63 || i + 1 + l > dns.size) return null
            labels += dns.copyOfRange(i + 1, i + 1 + l).toString(Charsets.US_ASCII)
            i += l + 1
        }
        return labels.joinToString(".")
    }

    private fun buildNxDomain(query: ByteArray): ByteArray {
        val r = query.copyOf()
        if (r.size >= 12) {
            r[2] = (r[2].toInt() or 0x80).toByte() // QR=1
            r[3] = ((r[3].toInt() and 0xF0) or 0x03).toByte() // NXDOMAIN
            r[6] = 0; r[7] = 0 // ANCOUNT
            r[8] = 0; r[9] = 0 // NSCOUNT
            r[10] = 0; r[11] = 0 // ARCOUNT
        }
        return r
    }

    private fun forwardDns(query: ByteArray): ByteArray? {
        val upstream = InetAddress.getByName("1.1.1.1")
        DatagramSocket().use { socket ->
            protect(socket)
            socket.soTimeout = 2500
            socket.send(DatagramPacket(query, query.size, upstream, 53))
            val buf = ByteArray(4096)
            val reply = DatagramPacket(buf, buf.size)
            return try {
                socket.receive(reply)
                buf.copyOf(reply.length)
            } catch (_: Exception) { null }
        }
    }

    private fun buildUdpIpv4Response(request: ByteArray, dns: ByteArray, ihl: Int): ByteArray {
        val totalLen = ihl + 8 + dns.size
        val out = ByteArray(totalLen)
        System.arraycopy(request, 0, out, 0, ihl)

        // swap src/dst IPv4
        System.arraycopy(request, 16, out, 12, 4)
        System.arraycopy(request, 12, out, 16, 4)
        out[2] = (totalLen ushr 8).toByte(); out[3] = totalLen.toByte()
        out[10] = 0; out[11] = 0
        val ipCsum = checksum(out, 0, ihl)
        out[10] = (ipCsum ushr 8).toByte(); out[11] = ipCsum.toByte()

        val ro = ihl
        // swap ports
        out[ro] = request[ro + 2]; out[ro + 1] = request[ro + 3]
        out[ro + 2] = request[ro]; out[ro + 3] = request[ro + 1]
        val udpLen = 8 + dns.size
        out[ro + 4] = (udpLen ushr 8).toByte(); out[ro + 5] = udpLen.toByte()
        out[ro + 6] = 0; out[ro + 7] = 0 // IPv4 UDP checksum optional
        System.arraycopy(dns, 0, out, ro + 8, dns.size)
        return out
    }

    private fun checksum(bytes: ByteArray, off: Int, len: Int): Int {
        var sum = 0L
        var i = off
        while (i < off + len - 1) {
            sum += (((bytes[i].toInt() and 0xff) shl 8) or (bytes[i + 1].toInt() and 0xff)).toLong()
            while (sum > 0xffff) sum = (sum and 0xffff) + (sum ushr 16)
            i += 2
        }
        if (len % 2 == 1) sum += ((bytes[off + len - 1].toInt() and 0xff) shl 8).toLong()
        while (sum > 0xffff) sum = (sum and 0xffff) + (sum ushr 16)
        return sum.inv().toInt() and 0xffff
    }

    private fun buildNotification(): android.app.Notification {
        val channelId = "shield"
        if (Build.VERSION.SDK_INT >= 26) {
            val channel = NotificationChannel(channelId, "Chrome Ad Shield", NotificationManager.IMPORTANCE_LOW)
            getSystemService(NotificationManager::class.java).createNotificationChannel(channel)
        }
        val pi = PendingIntent.getActivity(
            this, 0, Intent(this, MainActivity::class.java),
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )
        return NotificationCompat.Builder(this, channelId)
            .setSmallIcon(android.R.drawable.ic_secure)
            .setContentTitle("Chrome Ad Shield attivo")
            .setContentText("Filtro DNS locale per pubblicità e redirect")
            .setContentIntent(pi)
            .setOngoing(true)
            .build()
    }

    override fun onDestroy() {
        running.set(false)
        try { vpnInterface?.close() } catch (_: Exception) {}
        vpnInterface = null
        super.onDestroy()
    }
}
