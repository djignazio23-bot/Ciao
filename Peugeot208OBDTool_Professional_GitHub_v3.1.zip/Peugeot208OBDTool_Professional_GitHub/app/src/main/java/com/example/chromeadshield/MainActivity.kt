package com.example.chromeadshield

import android.Manifest
import android.content.Intent
import android.content.pm.PackageManager
import android.net.VpnService
import android.os.Build
import android.os.Bundle
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat
import com.example.chromeadshield.databinding.ActivityMainBinding

class MainActivity : AppCompatActivity() {
    private lateinit var binding: ActivityMainBinding
    private val prefs by lazy { getSharedPreferences("shield", MODE_PRIVATE) }

    private val vpnPermissionLauncher = registerForActivityResult(
        ActivityResultContracts.StartActivityForResult()
    ) {
        if (it.resultCode == RESULT_OK) startShield() else binding.switchShield.isChecked = false
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)

        val defaults = listOf(
            "doubleclick.net",
            "googlesyndication.com",
            "adnxs.com",
            "popads.net",
            "popcash.net",
            "propellerads.com",
            "onclicka.com",
            "adsterra.com"
        ).joinToString("\n")

        binding.editDomains.setText(prefs.getString("domains", defaults))
        binding.switchShield.isChecked = prefs.getBoolean("enabled", false)

        if (Build.VERSION.SDK_INT >= 33 && ContextCompat.checkSelfPermission(this, Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(arrayOf(Manifest.permission.POST_NOTIFICATIONS), 10)
        }

        binding.buttonSave.setOnClickListener {
            prefs.edit().putString("domains", binding.editDomains.text.toString()).apply()
            if (binding.switchShield.isChecked) {
                stopService(Intent(this, AdBlockVpnService::class.java))
                startShield()
            }
        }

        binding.switchShield.setOnCheckedChangeListener { _, enabled ->
            prefs.edit().putBoolean("enabled", enabled).apply()
            if (enabled) requestVpnAndStart() else stopService(Intent(this, AdBlockVpnService::class.java))
        }
    }

    private fun requestVpnAndStart() {
        val prepare = VpnService.prepare(this)
        if (prepare != null) vpnPermissionLauncher.launch(prepare) else startShield()
    }

    private fun startShield() {
        val i = Intent(this, AdBlockVpnService::class.java)
        ContextCompat.startForegroundService(this, i)
    }
}
