package com.example.chromeadshield

import android.Manifest
import android.content.Intent
import android.content.pm.PackageManager
import android.net.VpnService
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat
import com.example.chromeadshield.databinding.ActivityMainBinding

class MainActivity : AppCompatActivity() {
    private lateinit var binding: ActivityMainBinding
    private val prefs by lazy { getSharedPreferences("shield", MODE_PRIVATE) }

    private val vpnPermissionLauncher = registerForActivityResult(
        ActivityResultContracts.StartActivityForResult()
    ) {
        if (it.resultCode == RESULT_OK) startShield() else binding.switchShield.isChecked = false
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)

        val defaults = listOf(
            "doubleclick.net",
            "googlesyndication.com",
            "adnxs.com",
            "popads.net",
            "popcash.net",
            "propellerads.com",
            "onclicka.com",
            "adsterra.com",
            "aj267.com"
        ).joinToString("\n")

        val currentDomains = prefs.getString("domains", defaults) ?: defaults
        val normalized = currentDomains.lineSequence().map { it.trim().lowercase() }.toSet()
        val migratedDomains = if ("aj267.com" in normalized) currentDomains else currentDomains.trimEnd() + "\naj267.com"
        prefs.edit().putString("domains", migratedDomains).apply()

        binding.editDomains.setText(migratedDomains)
        binding.editProtected.setText(prefs.getString("protected_patterns", "streamingcommunity"))
        binding.editTrusted.setText(prefs.getString("trusted_domains", ""))
        binding.switchShield.isChecked = prefs.getBoolean("enabled", false)
        binding.switchAggressive.isChecked = prefs.getBoolean("aggressive", true)

        if (Build.VERSION.SDK_INT >= 33 && ContextCompat.checkSelfPermission(this, Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(arrayOf(Manifest.permission.POST_NOTIFICATIONS), 10)
        }

        binding.buttonAccessibility.setOnClickListener {
            startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS))
        }

        binding.buttonSave.setOnClickListener {
            saveAll()
            if (binding.switchShield.isChecked) {
                stopService(Intent(this, AdBlockVpnService::class.java))
                startShield()
            }
        }

        binding.switchAggressive.setOnCheckedChangeListener { _, enabled ->
            prefs.edit().putBoolean("aggressive", enabled).apply()
        }

        binding.switchShield.setOnCheckedChangeListener { _, enabled ->
            prefs.edit().putBoolean("enabled", enabled).apply()
            if (enabled) requestVpnAndStart() else stopService(Intent(this, AdBlockVpnService::class.java))
        }
    }

    private fun saveAll() {
        prefs.edit()
            .putString("domains", binding.editDomains.text.toString())
            .putString("protected_patterns", binding.editProtected.text.toString())
            .putString("trusted_domains", binding.editTrusted.text.toString())
            .putBoolean("aggressive", binding.switchAggressive.isChecked)
            .apply()
    }

    override fun onPause() {
        super.onPause()
        if (::binding.isInitialized) saveAll()
    }

    private fun requestVpnAndStart() {
        val prepare = VpnService.prepare(this)
        if (prepare != null) vpnPermissionLauncher.launch(prepare) else startShield()
    }

    private fun startShield() {
        val i = Intent(this, AdBlockVpnService::class.java)
        ContextCompat.startForegroundService(this, i)
    }
}
