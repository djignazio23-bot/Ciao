package com.peugeot.obdtool;

import java.util.Locale;

public final class EcuProfile {
    public final String vin;
    public final String protocol;
    public final String calibrationId;
    public final String cvn;
    public final String ecuName;
    public final String family;
    public final boolean exactFamilyMatch;
    public final String identificationSource;

    private EcuProfile(String vin, String protocol, String calibrationId, String cvn, String ecuName,
                       String family, boolean exactFamilyMatch, String identificationSource) {
        this.vin=vin; this.protocol=protocol; this.calibrationId=calibrationId; this.cvn=cvn; this.ecuName=ecuName;
        this.family=family; this.exactFamilyMatch=exactFamilyMatch; this.identificationSource=identificationSource;
    }

    public static EcuProfile detect(String vin, String protocol, String calibrationId, String cvn, String ecuName){
        String all=((calibrationId==null?"":calibrationId)+" "+(ecuName==null?"":ecuName)).toUpperCase(Locale.ROOT);
        Detection d=detectFamily(all);
        return new EcuProfile(vin,protocol,calibrationId,cvn,ecuName,d.family,d.exact,"Mode 09 OBD-II");
    }

    private static Detection detectFamily(String all){
        String family="ECU motore OBD-II rilevata";
        boolean exact=false;
        if(all.contains("MG1CS032")){ family="Bosch MG1CS032"; exact=true; }
        else if(all.contains("MG1CS")){ family="Bosch MG1CS (variante da identificare)"; }
        else if(all.contains("MED17")){ family="Bosch MED17 (variante da identificare)"; }
        else if(all.contains("BOSCH")){ family="Bosch (famiglia non determinata dagli identificativi letti)"; }
        else if(all.contains("CONTINENTAL")||all.contains("SIEMENS")||all.contains("SID")){ family="Continental/Siemens (famiglia da identificare)"; }
        return new Detection(family,exact);
    }

    public String summary(){
        StringBuilder s=new StringBuilder();
        s.append("Profilo veicolo: Peugeot 208 II 1.2 PureTech 100\n");
        s.append("ECU: ").append(family).append(exactFamilyMatch?" (match esatto)":" (auto-detect)").append("\n");
        s.append("Protocollo: ").append(empty(protocol)?"N/D":protocol).append("\n");
        s.append("Calibration ID: ").append(empty(calibrationId)?"N/D":calibrationId).append("\n");
        s.append("CVN: ").append(empty(cvn)?"N/D":cvn).append("\n");
        s.append("ECU name: ").append(empty(ecuName)?"N/D":ecuName).append("\n");
        s.append("Fonte ID: ").append(identificationSource);
        return s.toString();
    }

    public String testPolicy(){
        if(exactFamilyMatch) return "AUTO PROFILE: famiglia ECU riconosciuta da Mode 09 • test OBD adattati • identificazione UDS estesa rimossa";
        return "AUTO PROFILE: info ECU standard Mode 09 • test OBD adattivi • nessuna identificazione UDS estesa";
    }

    private static boolean empty(String s){ return s==null||s.trim().isEmpty(); }
    private static final class Detection{ final String family; final boolean exact; Detection(String f,boolean e){family=f;exact=e;} }
}
