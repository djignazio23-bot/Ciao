package com.peugeot.obdtool;

import android.content.Context;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;

public class CsvLogger {
    private File file;

    public File start(Context c, String prefix) throws IOException {
        File dir = new File(c.getExternalFilesDir(null), "logs");
        if (!dir.exists() && !dir.mkdirs()) throw new IOException("Impossibile creare cartella log");
        String ts = new SimpleDateFormat("yyyyMMdd_HHmmss", Locale.ROOT).format(new Date());
        file = new File(dir, prefix + "_" + ts + ".csv");
        try (FileWriter w = new FileWriter(file)) {
            w.write("timestamp_ms,rpm,speed_kmh,coolant_c,map_kpa,baro_kpa,boost_kpa,throttle_pct,engine_load_pct,stft_pct,ltft_pct,timing_deg,iat_c,maf_gps,fuel_pressure_kpa,rail_pressure_kpa,commanded_lambda,actual_lambda,actual_lambda_age_ms,voltage_v,c1_misfire_current,c2_misfire_current,c3_misfire_current,c1_misfire_ewma,c2_misfire_ewma,c3_misfire_ewma,c1_misfire_delta,c2_misfire_delta,c3_misfire_delta,cylinder_sample_new,misfire_total_current,misfire_spread_current,cylinder_sample_age_ms,misfire_monitor_state,idle_rpm_stddev,idle_rpm_range,engine_phase\n");
        }
        return file;
    }

    public synchronized void append(long ts, double rpm, int speed, int coolant, int map, int baro,
                                    double boost, double throttle, double load, double stft, double ltft,
                                    double timing, int iat, double maf, double fuelPressure, double railPressure,
                                    double commandedLambda, double actualLambda, long actualLambdaAgeMs, double voltage,
                                    int c1Current, int c2Current, int c3Current, int c1Ewma, int c2Ewma, int c3Ewma,
                                    int c1Delta, int c2Delta, int c3Delta, int cylinderSampleNew,
                                    int misfireTotal, int misfireSpread, long cylinderSampleAgeMs, int misfireMonitorState,
                                    double idleRpmStdDev, double idleRpmRange, String enginePhase) throws IOException {
        if (file == null) return;
        String phase=(enginePhase==null?"N_D":enginePhase.replace(',', '_').replace(' ', '_'));
        try (FileWriter w = new FileWriter(file, true)) {
            w.write(String.format(Locale.US,
                    "%d,%.1f,%d,%d,%d,%d,%.2f,%.2f,%.2f,%.2f,%.2f,%.2f,%d,%.3f,%.1f,%.1f,%.4f,%.4f,%d,%.2f,%d,%d,%d,%d,%d,%d,%d,%d,%d,%d,%d,%d,%d,%d,%.2f,%.2f,%s\n",
                    ts, rpm, speed, coolant, map, baro, boost, throttle, load, stft, ltft,
                    timing, iat, maf, fuelPressure, railPressure, commandedLambda, actualLambda, actualLambdaAgeMs, voltage,
                    c1Current, c2Current, c3Current, c1Ewma, c2Ewma, c3Ewma, c1Delta, c2Delta, c3Delta, cylinderSampleNew,
                    misfireTotal, misfireSpread, cylinderSampleAgeMs, misfireMonitorState, idleRpmStdDev, idleRpmRange, phase));
        }
    }

    public File getFile() { return file; }
}
