package com.peugeot.obdtool;

import java.util.LinkedHashSet;
import java.util.List;
import java.util.Locale;
import java.util.Set;

/** Read-only DTC interpretation helper. Never sends commands to the vehicle. */
public final class DtcExpert {
    private DtcExpert() {}

    public static String buildReport(List<String> confirmed, List<String> pending, List<String> permanent,
                                     String readiness, String previousCsv, long previousTs) {
        StringBuilder r = new StringBuilder();
        r.append("208 OBD PRO • DTC EXPERT\n");
        r.append("=========================\n");
        r.append("Readiness/MIL: ").append(readiness == null ? "N/D" : readiness).append("\n");
        r.append("Confermati: ").append(confirmed.size()).append("  •  Pending: ").append(pending.size())
                .append("  •  Permanenti: ").append(permanent.size()).append("\n\n");

        Set<String> previous = parseCsv(previousCsv);
        if (previousTs > 0) {
            r.append("Confronto con scansione precedente: ");
            if (previous.isEmpty()) r.append("nessun codice memorizzato nella scansione precedente\n\n");
            else r.append(previous.size()).append(" codice/i precedenti disponibili per confronto\n\n");
        }

        appendSection(r, "DTC CONFERMATI", confirmed, previous, "CONFERMATO");
        appendSection(r, "DTC PENDING", pending, previous, "PENDING");
        appendSection(r, "DTC PERMANENTI", permanent, previous, "PERMANENTE");

        if (confirmed.isEmpty() && pending.isEmpty() && permanent.isEmpty()) {
            r.append("✓ Nessun DTC OBD-II rilevato nelle tre memorie standard.\n");
            r.append("Nota: questo non esclude anomalie PSA proprietarie non esposte dai Mode 03/07/0A.\n");
        } else {
            r.append("\nLETTURA PROFESSIONALE\n");
            r.append("• CONFERMATO = guasto memorizzato dalla ECU.\n");
            r.append("• PENDING = monitor ha visto una condizione anomala ma non sempre ha ancora confermato il guasto.\n");
            r.append("• PERMANENTE = codice emission-related che non sparisce semplicemente con Clear DTC; la ECU lo rimuove dopo monitor superati.\n");
            r.append("• Prima di cancellare: salvare freeze frame, condizioni del motore e Mode $06.\n");
        }
        return r.toString();
    }

    private static void appendSection(StringBuilder r, String title, List<String> codes, Set<String> previous, String state) {
        if (codes.isEmpty()) return;
        r.append(title).append("\n");
        r.append("-------------------------\n");
        for (String code : codes) {
            String c = code == null ? "" : code.trim().toUpperCase(Locale.ROOT);
            if (c.isEmpty()) continue;
            r.append(c).append("  [").append(state).append("]");
            if (!previous.isEmpty()) r.append(previous.contains(c) ? "  • RICORRENTE" : "  • NUOVO");
            r.append("\n");
            r.append("Priorità: ").append(priority(c)).append("\n");
            r.append("Area: ").append(area(c)).append("\n");
            r.append("Significato: ").append(description(c)).append("\n");
            r.append("Controlli suggeriti: ").append(checks(c)).append("\n\n");
        }
    }

    public static String priority(String c) {
        if (c == null) return "N/D";
        c = c.toUpperCase(Locale.ROOT);
        if (c.matches("P03(00|01|02|03)")) return "ALTA";
        if (c.equals("P050B") || c.equals("P0299") || c.equals("P0234") || c.equals("P0087") || c.equals("P0088")) return "ALTA";
        if (c.startsWith("P001") || c.startsWith("P033") || c.startsWith("P034") || c.startsWith("P035")) return "ALTA";
        if (c.startsWith("U")) return "MEDIA (rete/comunicazione; alta se associata a sintomi o mancata comunicazione ECU)";
        if (c.startsWith("P042") || c.startsWith("P017") || c.startsWith("P010") || c.startsWith("P011")) return "MEDIA";
        return "DA VALUTARE CON FREEZE FRAME";
    }

    public static String area(String c) {
        if (c == null || c.length() < 2) return "N/D";
        c = c.toUpperCase(Locale.ROOT);
        if (c.equals("P050B")) return "accensione / strategia avviamento a freddo";
        if (c.startsWith("P03")) return "misfire / accensione / combustione";
        if (c.startsWith("P017")) return "miscela / fuel trim";
        if (c.equals("P0299") || c.equals("P0234") || c.startsWith("P02")) return "sovralimentazione / alimentazione / iniezione";
        if (c.startsWith("P008")) return "pressione carburante / rail";
        if (c.startsWith("P010") || c.startsWith("P011")) return "misura aria / MAP-MAF / temperature";
        if (c.startsWith("P001") || c.startsWith("P033") || c.startsWith("P034")) return "fasatura / camme / albero motore";
        if (c.startsWith("P042")) return "catalizzatore / emissioni";
        if (c.startsWith("P056")) return "alimentazione elettrica / tensione ECU";
        if (c.startsWith("U")) return "rete CAN / comunicazione moduli";
        if (c.startsWith("B")) return "body / carrozzeria";
        if (c.startsWith("C")) return "chassis / telaio";
        return c.startsWith("P") ? "powertrain / motore-trasmissione" : "sistema veicolo";
    }

    public static String description(String c) {
        if (c == null) return "N/D";
        c = c.toUpperCase(Locale.ROOT);
        switch (c) {
            case "P050B": return "Prestazione anticipo accensione durante l'avviamento a freddo (Cold Start Ignition Timing Performance).";
            case "P0300": return "Mancate accensioni casuali/multiple rilevate.";
            case "P0301": return "Mancata accensione rilevata cilindro 1.";
            case "P0302": return "Mancata accensione rilevata cilindro 2.";
            case "P0303": return "Mancata accensione rilevata cilindro 3.";
            case "P0171": return "Miscela troppo magra, bank 1.";
            case "P0172": return "Miscela troppo ricca, bank 1.";
            case "P0299": return "Sovralimentazione insufficiente / underboost.";
            case "P0234": return "Sovralimentazione eccessiva / overboost.";
            case "P0087": return "Pressione rail/carburante troppo bassa.";
            case "P0088": return "Pressione rail/carburante troppo alta.";
            case "P0420": return "Efficienza catalizzatore sotto soglia, bank 1.";
            case "P0011": return "Fasatura albero a camme troppo anticipata / performance.";
            case "P0012": return "Fasatura albero a camme troppo ritardata / performance.";
            case "P0016": return "Correlazione albero motore / albero a camme fuori tolleranza.";
            case "P0017": return "Correlazione albero motore / albero a camme fuori tolleranza.";
            case "P0562": return "Tensione sistema bassa.";
            case "P0563": return "Tensione sistema alta.";
            case "U1F1A": return "Codice rete/manufacturer-specific. Il significato esatto non è definito dallo standard OBD-II generico: richiede decodifica PSA/DiagBox per questa ECU.";
            default:
                if (isManufacturerSpecific(c)) return "Codice manufacturer-specific: la descrizione esatta va confermata con database PSA specifico della ECU.";
                return "Codice OBD-II rilevato. La descrizione dettagliata dipende dal sottosistema e dal contesto del freeze frame.";
        }
    }

    public static String checks(String c) {
        if (c == null) return "freeze frame + live data";
        c = c.toUpperCase(Locale.ROOT);
        if (c.equals("P050B")) return "freeze frame a freddo; ECT/IAT plausibili; anticipo; Mode $06 misfire C1-C2-C3; candele/bobine; cam/crank correlation; eventuale VVT e calibrazione ECU.";
        if (c.matches("P03(00|01|02|03)")) return "Mode $06 per cilindro; candela; bobina; iniettore; compressione; fuel trim/lambda; pressione rail.";
        if (c.equals("P0299") || c.equals("P0234")) return "MAP/BARO; boost reale vs richiesto se disponibile; manicotti/intercooler; wastegate/attuatore; elettrovalvola; perdite aspirazione/scarico.";
        if (c.startsWith("P017")) return "STFT/LTFT al minimo e sotto carico; lambda reale; MAP/MAF; pressione carburante; aspirazioni false; iniettori.";
        if (c.startsWith("P008")) return "pressione rail richiesta/reale se disponibile; pompa alta pressione; alimentazione bassa pressione; sensore rail; cablaggio.";
        if (c.startsWith("P001") || c.startsWith("P033") || c.startsWith("P034")) return "segnali cam/crank; fasatura meccanica; sensori; VVT; olio corretto/pressione olio; cablaggio.";
        if (c.startsWith("P042")) return "lambda pre/post catalizzatore; misfire; fuel trim; perdite scarico; temperatura e readiness.";
        if (c.startsWith("P056")) return "tensione a quadro acceso, durante avviamento e in carica; morsetti, massa, batteria, alternatore.";
        if (c.startsWith("U")) return "stato batteria; masse; connettori; rete CAN; moduli non raggiungibili; distinguere codice storico da ricorrente. Per U1xxx serve decodifica PSA.";
        return "freeze frame; stato confermato/pending/permanente; live data coerenti con il sottosistema; verificare se il codice ritorna dopo un ciclo guida completo.";
    }

    public static boolean isManufacturerSpecific(String c) {
        if (c == null || c.length() < 2) return false;
        char type = Character.toUpperCase(c.charAt(0));
        char second = c.charAt(1);
        if ((type=='P' || type=='B' || type=='C' || type=='U') && second=='1') return true;
        return false;
    }

    public static String toCsv(Set<String> codes) { return String.join(",", codes); }

    public static Set<String> combine(List<String> a, List<String> b, List<String> c) {
        Set<String> out = new LinkedHashSet<>();
        if (a != null) out.addAll(a); if (b != null) out.addAll(b); if (c != null) out.addAll(c);
        return out;
    }

    private static Set<String> parseCsv(String s) {
        Set<String> out = new LinkedHashSet<>();
        if (s == null || s.trim().isEmpty()) return out;
        for (String x : s.split(",")) if (!x.trim().isEmpty()) out.add(x.trim().toUpperCase(Locale.ROOT));
        return out;
    }
}
