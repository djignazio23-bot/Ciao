# Build v3.1 on the existing GitHub workflow

Upload `Peugeot208OBDTool_Professional_GitHub_v3.1.zip` to the repository root.

If your current workflow unzips a versioned ZIP, set:

```bash
unzip -o Peugeot208OBDTool_Professional_GitHub_v3.1.zip -d project
```

Then keep the same Gradle build directory used for previous versions.
