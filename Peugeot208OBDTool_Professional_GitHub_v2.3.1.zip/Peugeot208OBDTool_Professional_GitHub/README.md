# Peugeot 208 OBD Tool Professional — v2.0

Android diagnostic app for Bluetooth ELM327 adapters, designed around a Peugeot 208 workflow.

## Professional features
- Bluetooth SPP connection to paired ELM327 adapters.
- Connection status, adapter identification, detected OBD protocol and adapter voltage.
- Live dashboard: RPM, speed, coolant temperature, MAP, throttle, battery/adapter voltage, STFT/LTFT.
- Built-in live RPM sparkline without third-party chart libraries.
- CSV logging for cold-start diagnosis in the app external files directory.
- Vehicle info / VIN request.
- DTC scan and clear with explicit confirmation.
- Dedicated Advanced page with safe ECU soft reset workflow.
- Reset Safety Gate requires verified 0 km/h, engine off and >= 11.8 V before sending a reset request.
- Manual OBD console with automatic blocks for common firmware-programming/write/security command families.
- Professional session log.

## ECU reset scope
The reset feature is a diagnostic soft reset request to the engine ECU. It does **not** emulate a physical power disconnect and therefore does not intentionally power-cycle the radio/infotainment. Support depends on the actual ECU, gateway and ELM327 adapter.

The application intentionally does not provide automated firmware flashing, immobilizer programming, airbag/SRS coding or write operations to safety-critical modules.

## Build
1. Open the project in Android Studio.
2. Allow Gradle to sync.
3. Pair the ELM327 in Android Bluetooth settings.
4. Build > Build App Bundle(s) / APK(s) > Build APK(s).
5. Install the generated debug APK for local testing.

Target SDK: 35. Minimum Android: 8.0 (API 26).

## GitHub Actions — APK automatico
Questa edizione include `.github/workflows/build-apk.yml` per compilare automaticamente un APK debug installabile. Consulta `BUILD_GITHUB.md` per la procedura passo-passo.


## v2.3 AI Diagnostic Mode
- Registrazione telemetria OBD in CSV
- Indicatori locali preliminari per tensione, fuel trim, MAP e temperatura
- Condivisione diretta del CSV verso ChatGPT tramite Android Share Sheet
- Nessun dato viene inviato automaticamente: la condivisione è esplicita e controllata dall'utente.
