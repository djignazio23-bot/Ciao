# Peugeot 208 Bosch MG1CS032 SAFE v2

App Android separata, progettata per il profilo della Peugeot 208 II 2022
1.2 PureTech 100 dell'utente.

## Profilo OBD reale usato come guard
- VIN: VR3UPHNEKN5913068
- Calibration ID: 9695724580
- CVN: A86E9F62
- ECU Name: ECM-EngineControl
- CAN responder motore: 7E8
- Protocollo: ISO 15765-4 CAN 11 bit / 500 kbit

## Riferimenti Bosch compatibili
Fonti ricambio/veicolo per 208 II 1.2 PureTech 100/HNE riportano:
- Bosch MG1CS032
- Bosch 0261S105H6
- PSA/OEM 9851331280

Questi riferimenti sono mostrati come compatibilità esterna. L'app NON afferma che
siano stati letti direttamente dalla ECU finché non esiste una lettura fisica che lo provi.

## Funzioni
1. VERIFICA BOSCH
   - forza ATSP6
   - legge VIN, Calibration ID, CVN, ECU name
   - prova Engine Serial standard (Mode 09 PID 0D)
   - legge EROTAN/type approval standard (Mode 09 PID 0F)
   - verifica responder 7E8
   - legge DTC stored/pending/permanent senza cancellarli

2. SNAPSHOT MOTORE
   Si abilita solo dopo aver verificato il VIN atteso e 7E8.
   Legge parametri OBD standard:
   - engine load
   - coolant temperature
   - STFT / LTFT Bank 1
   - MAP
   - RPM
   - vehicle speed
   - ignition timing
   - intake air temperature
   - MAF
   - throttle
   - direct-injection rail pressure
   - fuel level
   - control module voltage
   - commanded equivalence ratio
   - ambient temperature
   - engine fuel rate

## Sicurezza
Assenti:
- ATSP0
- Mode 04
- Mode 08
- UDS 0x10 DiagnosticSessionControl
- UDS 0x11 ECUReset
- UDS 0x27 SecurityAccess
- UDS 0x2E WriteDataByIdentifier
- UDS 0x31 RoutineControl
- flash/download 0x34/0x36/0x37
- input di comandi arbitrari

Questa v2 è diagnostica e read-only. Il reset degli autoadattativi non è implementato.
