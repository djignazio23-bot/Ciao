package com.peugeot208.boschsafe

import android.Manifest
import android.app.Activity
import android.bluetooth.BluetoothAdapter
import android.bluetooth.BluetoothDevice
import android.bluetooth.BluetoothSocket
import android.content.ContentValues
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Typeface
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.Environment
import android.provider.MediaStore
import android.text.method.ScrollingMovementMethod
import android.view.Gravity
import android.view.View
import android.widget.*
import java.io.InputStream
import java.io.OutputStream
import java.nio.charset.StandardCharsets
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.util.UUID
import java.util.concurrent.Executors

class MainActivity : Activity() {

    companion object {
        private const val REQ_BT = 9001
        private val SPP_UUID: UUID =
            UUID.fromString("00001101-0000-1000-8000-00805F9B34FB")

        // Profilo reale già letto dalla vettura dell'utente.
        private const val EXPECTED_VIN = "VR3UPHNEKN5913068"
        private const val EXPECTED_CAL_ID = "9695724580"
        private const val EXPECTED_CVN = "A86E9F62"
        private const val EXPECTED_ECU_NAME = "ECM-EngineControl"
        private const val EXPECTED_RESPONDER = "7E8"

        // Riferimenti Bosch compatibili trovati per 208 II 1.2 PureTech 100/HNE.
        // Sono riferimenti di compatibilità, NON vengono spacciati per valori letti dalla ECU.
        private const val BOSCH_FAMILY_REFERENCE = "MG1CS032"
        private const val BOSCH_PART_REFERENCE = "0261S105H6"
        private const val PSA_PART_REFERENCE = "9851331280"

        // Allowlist rigida. Nessun comando di reset, attuazione, scrittura o flash.
        private val SAFE_COMMANDS = setOf(
            "ATI", "ATE0", "ATL0", "ATS0", "ATH0", "ATH1", "ATCAF1",
            "ATSP6", "ATDPN", "ATDP", "ATRV", "ATSH7DF",

            // Mode 01 - sola lettura.
            "0100", "0101", "0104", "0105", "0106", "0107",
            "010B", "010C", "010D", "010E", "010F", "0110", "0111",
            "0120", "0123", "012F", "0140", "0142", "0144", "0146",
            "015E", "0160",

            // DTC: solo lettura.
            "03", "07", "0A",

            // Mode 09 - informazioni veicolo/ECU.
            "0900", "0902", "0904", "0906", "0908", "090A", "090D", "090F",

            "ATPC"
        )

        private val LIVE_PIDS = linkedMapOf(
            "0104" to "Carico calcolato",
            "0105" to "Temperatura liquido",
            "0106" to "STFT Bank 1",
            "0107" to "LTFT Bank 1",
            "010B" to "MAP",
            "010C" to "RPM",
            "010D" to "Velocita",
            "010E" to "Anticipo accensione",
            "010F" to "Temperatura aria aspirata",
            "0110" to "MAF",
            "0111" to "Farfalla",
            "0123" to "Pressione rail GDI",
            "012F" to "Livello carburante",
            "0142" to "Tensione modulo",
            "0144" to "Lambda comandata",
            "0146" to "Temperatura ambiente",
            "015E" to "Portata carburante"
        )
    }

    private val worker = Executors.newSingleThreadExecutor()

    private var adapter: BluetoothAdapter? = null
    private var socket: BluetoothSocket? = null
    private var input: InputStream? = null
    private var output: OutputStream? = null
    private var selectedDevice: BluetoothDevice? = null

    private lateinit var deviceSpinner: Spinner
    private lateinit var refreshButton: Button
    private lateinit var connectButton: Button
    private lateinit var identifyButton: Button
    private lateinit var snapshotButton: Button
    private lateinit var emergencyButton: Button
    private lateinit var shareButton: Button
    private lateinit var statusText: TextView
    private lateinit var logText: TextView
    private lateinit var progress: ProgressBar

    private val deviceList = mutableListOf<BluetoothDevice>()
    private val rawResponses = linkedMapOf<String, String>()
    private val logLines = mutableListOf<String>()

    private var reportText: String = ""
    private var reportUri: Uri? = null

    private var vehicleGuardPassed = false
    private var lastVin = ""
    private var lastCalId = ""
    private var lastCvn = ""
    private var lastEcuName = ""

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        adapter = BluetoothAdapter.getDefaultAdapter()
        buildUi()

        if (adapter == null) {
            setStatus("Bluetooth non disponibile su questo dispositivo.", true)
            disableActions()
            return
        }

        requestBluetoothPermissionIfNeeded()
    }

    private fun buildUi() {
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(26, 24, 26, 24)
        }

        val title = TextView(this).apply {
            text = "Peugeot 208 BOSCH MG1CS032 SAFE"
            textSize = 22f
            setTypeface(typeface, Typeface.BOLD)
            gravity = Gravity.CENTER
        }
        root.addView(title)

        val subtitle = TextView(this).apply {
            text = "208 II 2022 • 1.2 PureTech 100\nv2 • PROFILO BOSCH • SOLO LETTURA"
            textSize = 15f
            gravity = Gravity.CENTER
            setPadding(0, 10, 0, 18)
        }
        root.addView(subtitle)

        statusText = TextView(this).apply {
            text = "Stato: pronto"
            textSize = 16f
            setPadding(12, 10, 12, 10)
        }
        root.addView(statusText)

        val safety = TextView(this).apply {
            text = "Profilo dedicato alla tua 208. Verifica VIN/Calibration/CVN/7E8 e legge solo OBD standard. Reset, cancellazione DTC, attuazioni, SecurityAccess e flash sono assenti."
            textSize = 14f
            setPadding(12, 8, 12, 16)
        }
        root.addView(safety)

        val row1 = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
        }

        deviceSpinner = Spinner(this)
        row1.addView(deviceSpinner, LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f))

        refreshButton = Button(this).apply { text = "Aggiorna" }
        row1.addView(refreshButton)
        root.addView(row1)

        val row2 = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER
        }

        connectButton = Button(this).apply { text = "Connetti ELM327" }
        identifyButton = Button(this).apply {
            text = "VERIFICA BOSCH"
            isEnabled = false
        }
        row2.addView(connectButton, LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f))
        row2.addView(identifyButton, LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f))
        root.addView(row2)

        snapshotButton = Button(this).apply {
            text = "SNAPSHOT MOTORE"
            isEnabled = false
        }
        root.addView(snapshotButton)

        val row3 = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER
        }

        emergencyButton = Button(this).apply {
            text = "DISCONNETTI"
            isEnabled = false
        }
        shareButton = Button(this).apply {
            text = "Condividi report"
            isEnabled = false
        }
        row3.addView(emergencyButton, LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f))
        row3.addView(shareButton, LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f))
        root.addView(row3)

        progress = ProgressBar(this).apply {
            isIndeterminate = false
            max = 100
            progress = 0
            visibility = View.GONE
        }
        root.addView(progress)

        logText = TextView(this).apply {
            textSize = 13f
            typeface = Typeface.MONOSPACE
            setPadding(10, 12, 10, 12)
            movementMethod = ScrollingMovementMethod()
            text = "Istruzioni:\n1) Associa l'ELM327.\n2) Quadro acceso.\n3) Connetti.\n4) Premi VERIFICA BOSCH.\n5) Se il VIN corrisponde alla tua 208, si abilita SNAPSHOT MOTORE.\n"
        }

        val scroll = ScrollView(this)
        scroll.addView(logText)
        root.addView(scroll, LinearLayout.LayoutParams(
            LinearLayout.LayoutParams.MATCH_PARENT, 0, 1f
        ))

        setContentView(root)

        refreshButton.setOnClickListener { loadBondedDevices() }
        connectButton.setOnClickListener { connectSelectedDevice() }
        identifyButton.setOnClickListener { runBoschVerify() }\n        snapshotButton.setOnClickListener { runLiveSnapshot() }
        emergencyButton.setOnClickListener { disconnectSafe("Disconnessione richiesta dall'utente.") }
        shareButton.setOnClickListener { shareReport() }

        deviceSpinner.onItemSelectedListener = object : android.widget.AdapterView.OnItemSelectedListener {
            override fun onItemSelected(parent: android.widget.AdapterView<*>?, view: View?, position: Int, id: Long) {
                selectedDevice = deviceList.getOrNull(position)
            }
            override fun onNothingSelected(parent: android.widget.AdapterView<*>?) {
                selectedDevice = null
            }
        }
    }

    private fun requestBluetoothPermissionIfNeeded() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S &&
            checkSelfPermission(Manifest.permission.BLUETOOTH_CONNECT) != PackageManager.PERMISSION_GRANTED
        ) {
            requestPermissions(arrayOf(Manifest.permission.BLUETOOTH_CONNECT), REQ_BT)
        } else {
            loadBondedDevices()
        }
    }

    override fun onRequestPermissionsResult(
        requestCode: Int,
        permissions: Array<out String>,
        grantResults: IntArray
    ) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        if (requestCode == REQ_BT) {
            if (grantResults.isNotEmpty() && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                loadBondedDevices()
            } else {
                setStatus("Permesso Bluetooth negato.", true)
                disableActions()
            }
        }
    }

    private fun hasBtPermission(): Boolean {
        return Build.VERSION.SDK_INT < Build.VERSION_CODES.S ||
            checkSelfPermission(Manifest.permission.BLUETOOTH_CONNECT) == PackageManager.PERMISSION_GRANTED
    }

    private fun loadBondedDevices() {
        if (!hasBtPermission()) {
            requestBluetoothPermissionIfNeeded()
            return
        }

        try {
            val bonded = adapter?.bondedDevices?.toList()
                ?.sortedBy { safeDeviceName(it) }
                ?: emptyList()

            deviceList.clear()
            deviceList.addAll(bonded)

            val names = bonded.map {
                "${safeDeviceName(it)}  •  ${it.address}"
            }

            deviceSpinner.adapter = ArrayAdapter(
                this,
                android.R.layout.simple_spinner_dropdown_item,
                if (names.isEmpty()) listOf("Nessun dispositivo associato") else names
            )

            selectedDevice = bonded.firstOrNull()

            if (bonded.isEmpty()) {
                setStatus("Associa prima l'ELM327 nelle impostazioni Bluetooth.", true)
            } else {
                setStatus("Seleziona il tuo ELM327 e premi Connetti.", false)
            }
        } catch (e: SecurityException) {
            setStatus("Permesso Bluetooth mancante.", true)
        }
    }

    private fun safeDeviceName(d: BluetoothDevice): String {
        return try {
            d.name ?: "Bluetooth device"
        } catch (_: SecurityException) {
            "Bluetooth device"
        }
    }

    private fun connectSelectedDevice() {
        val device = selectedDevice ?: run {
            setStatus("Nessun ELM327 selezionato.", true)
            return
        }

        if (!hasBtPermission()) {
            requestBluetoothPermissionIfNeeded()
            return
        }

        setBusy(true)
        setStatus("Connessione a ${safeDeviceName(device)}…", false)
        appendLog("Connessione Bluetooth SPP…")

        worker.execute {
            try {
                closeSocketOnly()

                var s: BluetoothSocket? = null
                try {
                    s = device.createRfcommSocketToServiceRecord(SPP_UUID)
                    s.connect()
                } catch (e: Exception) {
                    try { s?.close() } catch (_: Exception) {}
                    s = device.createInsecureRfcommSocketToServiceRecord(SPP_UUID)
                    s.connect()
                }

                socket = s
                input = s.inputStream
                output = s.outputStream

                val ati = sendSafeCommand("ATI", 2500)
                if (!looksLikeElm(ati)) {
                    throw IllegalStateException("Il dispositivo risponde, ma non sembra un ELM/STN OBD.")
                }

                runOnUiThread {
                    emergencyButton.isEnabled = true
                    identifyButton.isEnabled = true
                    setStatus("ELM327 collegato. Premi VERIFICA BOSCH.", false)
                    appendLog("ELM: ${oneLine(ati)}")
                    setBusy(false)
                }
            } catch (e: Exception) {
                closeSocketOnly()
                runOnUiThread {
                    setBusy(false)
                    setStatus("Connessione fallita: ${e.message}", true)
                    appendLog("ERRORE connessione: ${e.message}")
                }
            }
        }
    }

    private fun prepareBoschSession(result: MutableMap<String, String>) {
        fun req(cmd: String, timeout: Long = 3500L): String {
            val r = sendSafeCommand(cmd, timeout)
            result[cmd] = r
            rawResponses[cmd] = r
            runOnUiThread { appendLog("$cmd → ${shortReply(r)}") }
            return r
        }

        req("ATE0")
        req("ATL0")
        req("ATS0")
        req("ATH0")
        req("ATCAF1")

        val sp6 = req("ATSP6")
        if (!sp6.contains("OK", ignoreCase = true)) {
            throw SafeStop("ATSP6 non accettato. Nessun fallback.")
        }

        val dpn = req("ATDPN")
            .replace("\\s".toRegex(), "")
            .replace(">", "")
        if (!Regex("(?i)^A?6$").containsMatchIn(dpn)) {
            throw SafeStop("Protocollo diverso da ISO 15765-4 CAN 11/500: $dpn")
        }

        req("ATDP")
        req("ATRV")

        val probe = req("0100", 5000L)
        val compact = probe.replace("[^0-9A-Fa-f]".toRegex(), "").uppercase()
        if (!compact.contains("4100") || containsBadObdReply(probe)) {
            throw SafeStop("Nessuna risposta OBD motore valida.")
        }
    }

    private fun runBoschVerify() {
        if (socket?.isConnected != true) {
            setStatus("ELM327 non collegato.", true)
            return
        }

        rawResponses.clear()
        logLines.clear()
        reportText = ""
        reportUri = null
        vehicleGuardPassed = false
        snapshotButton.isEnabled = false
        shareButton.isEnabled = false

        identifyButton.isEnabled = false
        connectButton.isEnabled = false
        refreshButton.isEnabled = false
        progress.visibility = View.VISIBLE
        progress.isIndeterminate = true

        appendLog("=== BOSCH MG1CS032 SAFE PROFILE v2 ===")
        appendLog("Nessuna scrittura/reset/attuazione.")
        appendLog("Verifica veicolo con dati OBD reali.")

        worker.execute {
            try {
                val result = linkedMapOf<String, String>()
                prepareBoschSession(result)

                fun optional(cmd: String, timeout: Long = 5500L): String {
                    val r = sendOptionalSafeRead(cmd, timeout)
                    result[cmd] = r
                    rawResponses[cmd] = r
                    runOnUiThread { appendLog("$cmd → ${shortReply(r)}") }
                    return r
                }

                optional("0900")
                optional("0902", 6500L)
                optional("0904", 6500L)
                optional("0906", 6500L)
                optional("090A", 6500L)
                optional("090D", 6500L)
                optional("090F", 6500L)
                optional("03")
                optional("07")
                optional("0A")

                val vin = parseMode09Ascii(result["0902"].orEmpty(), 0x02)
                val calId = parseMode09Ascii(result["0904"].orEmpty(), 0x04)
                val cvn = parseMode09Hex(result["0906"].orEmpty(), 0x06)
                val ecuName = parseMode09Ascii(result["090A"].orEmpty(), 0x0A)
                val engineSerial = parseMode09Ascii(result["090D"].orEmpty(), 0x0D)
                val erotan = parseMode09Ascii(result["090F"].orEmpty(), 0x0F)

                // Conferma fisica del responder OBD motore.
                optional("ATH1")
                optional("ATSH7DF")
                val headerProbe = optional("0100", 5000L)
                result["0100_WITH_HEADERS"] = headerProbe
                val responders = parseObdResponderIds(headerProbe)

                try { sendSafeCommand("ATH0", 1500L) } catch (_: Exception) {}

                val vinMatch = vin == EXPECTED_VIN
                val calMatch = calId == EXPECTED_CAL_ID
                val cvnMatch = cvn == EXPECTED_CVN
                val ecuNameMatch = ecuName == EXPECTED_ECU_NAME
                val responderMatch = responders.contains(EXPECTED_RESPONDER)

                // Il live snapshot è permesso solo sulla vettura attesa e col responder motore atteso.
                vehicleGuardPassed = vinMatch && responderMatch
                lastVin = vin
                lastCalId = calId
                lastCvn = cvn
                lastEcuName = ecuName

                val stored = parseDtcResponse(result["03"].orEmpty(), 0x43)
                val pending = parseDtcResponse(result["07"].orEmpty(), 0x47)
                val permanent = parseDtcResponse(result["0A"].orEmpty(), 0x4A)

                reportText = buildBoschProfileReport(
                    result = result,
                    vin = vin,
                    calId = calId,
                    cvn = cvn,
                    ecuName = ecuName,
                    engineSerial = engineSerial,
                    erotan = erotan,
                    responders = responders,
                    vinMatch = vinMatch,
                    calMatch = calMatch,
                    cvnMatch = cvnMatch,
                    ecuNameMatch = ecuNameMatch,
                    responderMatch = responderMatch,
                    stored = stored,
                    pending = pending,
                    permanent = permanent
                )

                reportUri = saveNamedReport(reportText, "PEUGEOT_BOSCH_PROFILE")
                try { sendSafeCommand("ATPC", 1200L) } catch (_: Exception) {}

                runOnUiThread {
                    progress.visibility = View.GONE
                    progress.isIndeterminate = false
                    identifyButton.isEnabled = true
                    connectButton.isEnabled = true
                    refreshButton.isEnabled = true
                    snapshotButton.isEnabled = vehicleGuardPassed
                    shareButton.isEnabled = reportUri != null

                    appendLog("")
                    appendLog("VIN: ${vin.ifBlank { "non disponibile" }}")
                    appendLog("Calibration ID: ${calId.ifBlank { "non disponibile" }}")
                    appendLog("CVN: ${cvn.ifBlank { "non disponibile" }}")
                    appendLog("ECU Name: ${ecuName.ifBlank { "non disponibile" }}")
                    appendLog("Responder: ${responders.joinToString(", ").ifBlank { "nessuno" }}")

                    if (vehicleGuardPassed) {
                        val calibrationNote =
                            if (calMatch && cvnMatch && ecuNameMatch) "baseline OBD coincidente"
                            else "vettura coincidente, ma baseline ECU/calibrazione cambiata"
                        setStatus("Profilo vettura verificato: $calibrationNote.", false)
                        appendLog("SNAPSHOT MOTORE abilitato.")
                    } else {
                        setStatus("Profilo vettura NON verificato. Snapshot bloccato.", true)
                    }
                }
            } catch (e: Exception) {
                safeProtocolStop(e.message ?: "Errore verifica Bosch.")
            }
        }
    }

    private fun runLiveSnapshot() {
        if (!vehicleGuardPassed) {
            setStatus("Esegui prima VERIFICA BOSCH sulla vettura attesa.", true)
            return
        }
        if (socket?.isConnected != true) {
            setStatus("ELM327 non collegato.", true)
            return
        }

        rawResponses.clear()
        logLines.clear()
        reportText = ""
        reportUri = null
        shareButton.isEnabled = false
        snapshotButton.isEnabled = false
        identifyButton.isEnabled = false
        progress.visibility = View.VISIBLE
        progress.isIndeterminate = true

        appendLog("=== BOSCH SAFE LIVE SNAPSHOT ===")
        appendLog("Solo Mode 01 / DTC read. Nessuna attuazione.")

        worker.execute {
            try {
                val result = linkedMapOf<String, String>()
                prepareBoschSession(result)

                fun opt(cmd: String, timeout: Long = 3500L): String {
                    val r = sendOptionalSafeRead(cmd, timeout)
                    result[cmd] = r
                    runOnUiThread { appendLog("$cmd → ${shortReply(r)}") }
                    return r
                }

                // Verifica rapida VIN prima di leggere dati live.
                val vinRaw = opt("0902", 6500L)
                val vin = parseMode09Ascii(vinRaw, 0x02)
                if (vin != EXPECTED_VIN) {
                    throw SafeStop("VIN diverso dal profilo previsto. Snapshot annullato.")
                }

                opt("0101")
                opt("0120")
                opt("0140")
                opt("0160")

                val values = linkedMapOf<String, String>()
                for ((cmd, label) in LIVE_PIDS) {
                    val raw = opt(cmd)
                    values[label] = decodeLivePid(cmd, raw)
                }

                val storedRaw = opt("03")
                val pendingRaw = opt("07")
                val permanentRaw = opt("0A")
                val stored = parseDtcResponse(storedRaw, 0x43)
                val pending = parseDtcResponse(pendingRaw, 0x47)
                val permanent = parseDtcResponse(permanentRaw, 0x4A)

                reportText = buildLiveSnapshotReport(
                    vin = vin,
                    values = values,
                    stored = stored,
                    pending = pending,
                    permanent = permanent,
                    result = result
                )
                reportUri = saveNamedReport(reportText, "PEUGEOT_BOSCH_LIVE")

                try { sendSafeCommand("ATPC", 1200L) } catch (_: Exception) {}

                runOnUiThread {
                    progress.visibility = View.GONE
                    progress.isIndeterminate = false
                    identifyButton.isEnabled = true
                    snapshotButton.isEnabled = true
                    shareButton.isEnabled = reportUri != null
                    setStatus("Snapshot Bosch completato.", false)
                    appendLog("")
                    for ((label, value) in values) {
                        appendLog("$label: $value")
                    }
                    appendLog("DTC stored: ${stored.ifEmpty { listOf("nessuno") }.joinToString(", ")}")
                }
            } catch (e: Exception) {
                safeProtocolStop(e.message ?: "Errore snapshot.")
            }
        }
    }

    private fun safeProtocolStop(message: String) {
        try {
            sendSafeCommand("ATPC", 1200)
        } catch (_: Exception) {}
        closeSocketOnly()

        runOnUiThread {
            progress.visibility = View.GONE
            setStatus("STOP SICURO: $message", true)
            appendLog("STOP SICURO: $message")
            appendLog("ELM disconnesso. Nessun fallback o comando attivo eseguito.")
            appendLog("Se l'auto si comporta in modo anomalo: scollega fisicamente l'ELM, spegni il quadro e lascia l'auto a riposo alcuni minuti.")
            identifyButton.isEnabled = false
            emergencyButton.isEnabled = false
            connectButton.isEnabled = true
            refreshButton.isEnabled = true
        }
    }

    @Synchronized
    private fun sendSafeCommand(command: String, timeoutMs: Long): String {
        val cmd = command.trim().uppercase(Locale.ROOT)

        if (!SAFE_COMMANDS.contains(cmd)) {
            throw SecurityException("Comando '$cmd' rifiutato dalla allowlist SAFE.")
        }

        val out = output ?: throw IllegalStateException("Output Bluetooth non disponibile.")
        val inp = input ?: throw IllegalStateException("Input Bluetooth non disponibile.")

        while (inp.available() > 0) {
            inp.read()
        }

        out.write("$cmd\r".toByteArray(StandardCharsets.US_ASCII))
        out.flush()

        val start = System.currentTimeMillis()
        val buffer = ByteArray(512)
        val text = StringBuilder()

        while (System.currentTimeMillis() - start < timeoutMs) {
            val available = inp.available()
            if (available > 0) {
                val n = inp.read(buffer, 0, minOf(buffer.size, available))
                if (n > 0) {
                    text.append(String(buffer, 0, n, StandardCharsets.US_ASCII))
                    if (text.contains(">")) break
                }
            } else {
                Thread.sleep(40)
            }
        }

        val reply = text.toString().replace(">", "").trim()
        if (reply.isBlank()) {
            throw SafeStop("Timeout sul comando $cmd.")
        }
        return reply
    }

    private fun sendOptionalSafeRead(command: String, timeoutMs: Long): String {
        return try {
            sendSafeCommand(command, timeoutMs)
        } catch (_: SafeStop) {
            "NO RESPONSE"
        }
    }

    private fun looksLikeElm(reply: String): Boolean {
        val u = reply.uppercase()
        return u.contains("ELM") || u.contains("STN") || u.contains("OBD") || Regex("V\\d+\\.\\d+").containsMatchIn(u)
    }

    private fun containsBadObdReply(reply: String): Boolean {
        val u = reply.uppercase()
        return listOf(
            "NO DATA", "UNABLE TO CONNECT", "BUS ERROR",
            "CAN ERROR", "STOPPED", "BUS INIT"
        ).any { u.contains(it) }
    }

    private fun lineHexBytes(line: String): List<Int> {
        val trimmed = line.trim()
        if (trimmed.isBlank()) return emptyList()

        // Rimuove l'indice ELM multiframe "0:", "1:", ...
        val body = if (trimmed.matches(Regex("(?i)^[0-9A-F]:.*$"))) {
            trimmed.substringAfter(':')
        } else {
            trimmed
        }

        // Accetta sia "49 04 01 ..." sia "490401..."
        val compact = body.replace(Regex("(?i)[^0-9A-F]"), "")
        if (compact.length < 2 || compact.length % 2 != 0) return emptyList()

        return compact.chunked(2).mapNotNull {
            it.toIntOrNull(16)
        }
    }

    private fun indexedElmFrames(raw: String): Map<Int, List<Int>> {
        val frames = linkedMapOf<Int, List<Int>>()
        for (line in raw.split(Regex("[\\r\\n]+"))) {
            val m = Regex("(?i)^\\s*([0-9A-F]):").find(line) ?: continue
            val index = m.groupValues[1].toInt(16)
            val bytes = lineHexBytes(line)
            if (bytes.isNotEmpty()) frames[index] = bytes
        }
        return frames.toSortedMap()
    }

    private fun parseMode09Ascii(raw: String, pid: Int): String {
        return parseMode09Payload(raw, pid)
            .filter { it in 32..126 }
            .map { it.toChar() }
            .joinToString("")
            .trim()
            .replace("\u0000", "")
    }

    private fun parseMode09Hex(raw: String, pid: Int): String {
        return parseMode09Payload(raw, pid)
            .joinToString("") { "%02X".format(it) }
    }

    private fun parseMode09Payload(raw: String, pid: Int): List<Int> {
        val indexed = indexedElmFrames(raw)

        if (indexed.isNotEmpty()) {
            val firstEntry = indexed.entries.firstOrNull { (_, bytes) ->
                bytes.size >= 3 && bytes[0] == 0x49 && bytes[1] == pid
            }

            if (firstEntry != null) {
                val out = mutableListOf<Int>()
                out += firstEntry.value.drop(3)
                for ((idx, bytes) in indexed) {
                    if (idx > firstEntry.key) out += bytes
                }
                return out
            }
        }

        // Risposta singola, ad es. 490601A86E9F62
        for (line in raw.split(Regex("[\\r\\n]+"))) {
            val bytes = lineHexBytes(line)
            for (i in 0..maxOf(-1, bytes.size - 3)) {
                if (i >= 0 && bytes[i] == 0x49 && bytes[i + 1] == pid) {
                    return bytes.drop(i + 3)
                }
            }
        }

        return emptyList()
    }

    private fun parseDtcResponse(raw: String, responseService: Int): List<String> {
        val all = raw.split(Regex("[\\r\\n]+")).flatMap { lineHexBytes(it) }
        val idx = all.indexOf(responseService)
        if (idx < 0) return emptyList()

        val result = mutableListOf<String>()
        var i = idx + 1
        while (i + 1 < all.size) {
            val a = all[i]
            val b = all[i + 1]
            i += 2
            if (a == 0 && b == 0) continue

            val prefix = listOf("P", "C", "B", "U")[(a shr 6) and 0x03]
            val d2 = (a shr 4) and 0x03
            val d3 = a and 0x0F
            val d4 = (b shr 4) and 0x0F
            val d5 = b and 0x0F
            result += "$prefix${d2.toString(16).uppercase()}${d3.toString(16).uppercase()}${d4.toString(16).uppercase()}${d5.toString(16).uppercase()}"
        }
        return result.distinct()
    }

    private fun parseObdResponderIds(raw: String): Set<String> {
        val ids = linkedSetOf<String>()

        for (line in raw.split(Regex("[\\r\\n]+"))) {
            val t = line.trim().uppercase()
            val spaced = Regex("^([0-9A-F]{3})\\s+").find(t)
            val compact = Regex("^([0-9A-F]{3})([0-9A-F]{4,})$").find(t)

            val id = when {
                spaced != null -> spaced.groupValues[1]
                compact != null -> compact.groupValues[1]
                else -> null
            } ?: continue

            val noSpace = t.replace(Regex("[^0-9A-F]"), "")
            if (id.matches(Regex("7E[8-F]")) && noSpace.contains("4100")) {
                ids += id
            }
        }

        return ids
    }

    private fun findMode01Payload(raw: String, pid: Int): List<Int> {
        val target = 0x40 + 0x01
        for (line in raw.split(Regex("[\\r\\n]+"))) {
            val bytes = lineHexBytes(line)
            if (bytes.size < 2) continue
            for (i in 0 until bytes.size - 1) {
                if (bytes[i] == target && bytes[i + 1] == pid) {
                    return bytes.drop(i + 2)
                }
            }
        }
        return emptyList()
    }

    private fun decodeLivePid(cmd: String, raw: String): String {
        val u = raw.uppercase()
        if (u.contains("NO DATA") || u.contains("NO RESPONSE")) return "non supportato"
        val pid = cmd.substring(2, 4).toIntOrNull(16) ?: return "non decodificato"
        val p = findMode01Payload(raw, pid)
        if (p.isEmpty()) return "non decodificato"

        fun a() = p.getOrNull(0) ?: 0
        fun b() = p.getOrNull(1) ?: 0
        fun word() = (a() shl 8) + b()

        return when (cmd) {
            "0104" -> "%.1f %%".format(Locale.US, a() * 100.0 / 255.0)
            "0105" -> "${a() - 40} °C"
            "0106", "0107" -> "%.1f %%".format(Locale.US, (a() - 128) * 100.0 / 128.0)
            "010B" -> "${a()} kPa"
            "010C" -> "%.0f rpm".format(Locale.US, word() / 4.0)
            "010D" -> "${a()} km/h"
            "010E" -> "%.1f °".format(Locale.US, a() / 2.0 - 64.0)
            "010F" -> "${a() - 40} °C"
            "0110" -> "%.2f g/s".format(Locale.US, word() / 100.0)
            "0111" -> "%.1f %%".format(Locale.US, a() * 100.0 / 255.0)
            "0123" -> "%.0f kPa".format(Locale.US, word() * 10.0)
            "012F" -> "%.1f %%".format(Locale.US, a() * 100.0 / 255.0)
            "0142" -> "%.3f V".format(Locale.US, word() / 1000.0)
            "0144" -> "%.3f".format(Locale.US, word() / 32768.0)
            "0146" -> "${a() - 40} °C"
            "015E" -> "%.2f L/h".format(Locale.US, word() / 20.0)
            else -> p.joinToString(" ") { "%02X".format(it) }
        }
    }

    private fun buildBoschProfileReport(
        result: Map<String, String>,
        vin: String,
        calId: String,
        cvn: String,
        ecuName: String,
        engineSerial: String,
        erotan: String,
        responders: Set<String>,
        vinMatch: Boolean,
        calMatch: Boolean,
        cvnMatch: Boolean,
        ecuNameMatch: Boolean,
        responderMatch: Boolean,
        stored: List<String>,
        pending: List<String>,
        permanent: List<String>
    ): String {
        val sdf = SimpleDateFormat("yyyy-MM-dd HH:mm:ss", Locale.ITALY)
        return buildString {
            appendLine("PEUGEOT 208 BOSCH MG1CS032 SAFE PROFILE v2")
            appendLine("==========================================")
            appendLine("Data: ${sdf.format(Date())}")
            appendLine("Modalita: SOLO LETTURA")
            appendLine("Protocollo obbligatorio: ISO 15765-4 CAN 11/500 (ATSP6)")
            appendLine()
            appendLine("DATI LETTI DALLA VETTURA")
            appendLine("------------------------")
            appendLine("VIN: ${vin.ifBlank { "non disponibile" }}")
            appendLine("Calibration ID: ${calId.ifBlank { "non disponibile" }}")
            appendLine("CVN: ${cvn.ifBlank { "non disponibile" }}")
            appendLine("ECU Name: ${ecuName.ifBlank { "non disponibile" }}")
            appendLine("Engine Serial (Mode 09/0D): ${engineSerial.ifBlank { "non disponibile" }}")
            appendLine("EROTAN / type approval (Mode 09/0F): ${erotan.ifBlank { "non disponibile" }}")
            appendLine("Responder CAN: ${responders.joinToString(", ").ifBlank { "nessuno" }}")
            appendLine()
            appendLine("CONFRONTO PROFILO NOTO")
            appendLine("----------------------")
            appendLine("VIN atteso: $EXPECTED_VIN -> ${if (vinMatch) "MATCH" else "NO MATCH"}")
            appendLine("Calibration attesa: $EXPECTED_CAL_ID -> ${if (calMatch) "MATCH" else "DIFFERENTE"}")
            appendLine("CVN atteso: $EXPECTED_CVN -> ${if (cvnMatch) "MATCH" else "DIFFERENTE"}")
            appendLine("ECU Name atteso: $EXPECTED_ECU_NAME -> ${if (ecuNameMatch) "MATCH" else "DIFFERENTE"}")
            appendLine("Responder atteso: $EXPECTED_RESPONDER -> ${if (responderMatch) "MATCH" else "NO MATCH"}")
            appendLine()
            appendLine("RIFERIMENTO BOSCH COMPATIBILE (NON LETTO DIRETTAMENTE)")
            appendLine("-----------------------------------------------------")
            appendLine("Famiglia candidata: $BOSCH_FAMILY_REFERENCE")
            appendLine("Bosch PN candidato: $BOSCH_PART_REFERENCE")
            appendLine("PSA/OEM candidato: $PSA_PART_REFERENCE")
            appendLine("Nota: questi tre riferimenti sono dati di compatibilita esterni, non prova fisica della ECU montata.")
            appendLine()
            appendLine("DTC")
            appendLine("---")
            appendLine("Stored: ${stored.ifEmpty { listOf("nessuno") }.joinToString(", ")}")
            appendLine("Pending: ${pending.ifEmpty { listOf("nessuno") }.joinToString(", ")}")
            appendLine("Permanent: ${permanent.ifEmpty { listOf("nessuno") }.joinToString(", ")}")
            appendLine()
            appendLine("OPERAZIONI ATTIVE: NESSUNA")
            appendLine("Mode 04: ASSENTE")
            appendLine("UDS SecurityAccess: ASSENTE")
            appendLine("UDS ECUReset: ASSENTE")
            appendLine("RoutineControl: ASSENTE")
            appendLine("Scrittura/codifica/flash: ASSENTI")
            appendLine()
            appendLine("RAW RESPONSES")
            appendLine("-------------")
            for ((cmd, reply) in result) {
                appendLine()
                appendLine("[$cmd]")
                appendLine(reply)
            }
        }
    }

    private fun buildLiveSnapshotReport(
        vin: String,
        values: Map<String, String>,
        stored: List<String>,
        pending: List<String>,
        permanent: List<String>,
        result: Map<String, String>
    ): String {
        val sdf = SimpleDateFormat("yyyy-MM-dd HH:mm:ss", Locale.ITALY)
        return buildString {
            appendLine("PEUGEOT 208 BOSCH SAFE LIVE SNAPSHOT v2")
            appendLine("=======================================")
            appendLine("Data: ${sdf.format(Date())}")
            appendLine("VIN verificato: $vin")
            appendLine("Profilo famiglia: $BOSCH_FAMILY_REFERENCE (candidato compatibile)")
            appendLine()
            appendLine("PARAMETRI MOTORE")
            appendLine("----------------")
            for ((label, value) in values) appendLine("$label: $value")
            appendLine()
            appendLine("DTC")
            appendLine("---")
            appendLine("Stored: ${stored.ifEmpty { listOf("nessuno") }.joinToString(", ")}")
            appendLine("Pending: ${pending.ifEmpty { listOf("nessuno") }.joinToString(", ")}")
            appendLine("Permanent: ${permanent.ifEmpty { listOf("nessuno") }.joinToString(", ")}")
            appendLine()
            appendLine("Nessun reset/cancellazione/attuazione eseguita.")
            appendLine()
            appendLine("RAW RESPONSES")
            appendLine("-------------")
            for ((cmd, reply) in result) {
                appendLine()
                appendLine("[$cmd]")
                appendLine(reply)
            }
        }
    }

    private fun saveNamedReport(text: String, prefix: String): Uri? {
        return try {
            val stamp = SimpleDateFormat("yyyyMMdd_HHmmss", Locale.US).format(Date())
            val name = "${prefix}_$stamp.txt"

            val values = ContentValues().apply {
                put(MediaStore.Downloads.DISPLAY_NAME, name)
                put(MediaStore.Downloads.MIME_TYPE, "text/plain")
                put(MediaStore.Downloads.RELATIVE_PATH, Environment.DIRECTORY_DOWNLOADS + "/PeugeotBoschSafe")
                put(MediaStore.Downloads.IS_PENDING, 1)
            }

            val uri = contentResolver.insert(MediaStore.Downloads.EXTERNAL_CONTENT_URI, values)
                ?: return null

            contentResolver.openOutputStream(uri)?.use {
                it.write(text.toByteArray(StandardCharsets.UTF_8))
            }

            values.clear()
            values.put(MediaStore.Downloads.IS_PENDING, 0)
            contentResolver.update(uri, values, null, null)
            uri
        } catch (e: Exception) {
            runOnUiThread { appendLog("Impossibile salvare report: ${e.message}") }
            null
        }
    }

    private fun shareReport() {
        val uri = reportUri
        if (uri == null) {
            setStatus("Nessun report disponibile.", true)
            return
        }

        val intent = Intent(Intent.ACTION_SEND).apply {
            type = "text/plain"
            putExtra(Intent.EXTRA_STREAM, uri)
            putExtra(Intent.EXTRA_TEXT, reportText)
            addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
        }
        startActivity(Intent.createChooser(intent, "Condividi report Peugeot Bosch SAFE v2"))
    }

    private fun disconnectSafe(reason: String) {
        worker.execute {
            try {
                if (socket?.isConnected == true) {
                    try { sendSafeCommand("ATPC", 1200) } catch (_: Exception) {}
                }
            } finally {
                closeSocketOnly()
                runOnUiThread {
                    identifyButton.isEnabled = false
                    snapshotButton.isEnabled = false
                    emergencyButton.isEnabled = false
                    connectButton.isEnabled = true
                    refreshButton.isEnabled = true
                    progress.visibility = View.GONE
                    setStatus("Disconnesso.", false)
                    appendLog(reason)
                }
            }
        }
    }

    private fun closeSocketOnly() {
        try { input?.close() } catch (_: Exception) {}
        try { output?.close() } catch (_: Exception) {}
        try { socket?.close() } catch (_: Exception) {}
        input = null
        output = null
        socket = null
    }

    override fun onDestroy() {
        closeSocketOnly()
        worker.shutdownNow()
        super.onDestroy()
    }

    private fun setBusy(busy: Boolean) {
        refreshButton.isEnabled = !busy
        connectButton.isEnabled = !busy
        deviceSpinner.isEnabled = !busy
        if (busy) {
            progress.visibility = View.VISIBLE
            progress.isIndeterminate = true
        } else {
            progress.visibility = View.GONE
            progress.isIndeterminate = false
        }
    }

    private fun setStatus(message: String, error: Boolean) {
        statusText.text = "Stato: $message"
        statusText.setTextColor(if (error) 0xFFB00020.toInt() else 0xFF1B5E20.toInt())
    }

    private fun appendLog(message: String) {
        val stamp = SimpleDateFormat("HH:mm:ss", Locale.US).format(Date())
        logLines += "$stamp  $message"

        val rendered = logLines.takeLast(250).joinToString("\n")
        logText.text = rendered
        logText.post {
            val layout = logText.layout
            if (layout != null) {
                val scroll = layout.getLineTop(logText.lineCount) - logText.height
                if (scroll > 0) logText.scrollTo(0, scroll)
            }
        }
    }

    private fun shortReply(reply: String): String {
        val one = oneLine(reply)
        return if (one.length > 90) one.take(87) + "..." else one
    }

    private fun oneLine(reply: String): String {
        return reply.replace(Regex("[\\r\\n]+"), " ").trim()
    }

    private fun disableActions() {
        refreshButton.isEnabled = false
        connectButton.isEnabled = false
        identifyButton.isEnabled = false
        snapshotButton.isEnabled = false
        emergencyButton.isEnabled = false
    }

    private class SafeStop(message: String) : Exception(message)
}
