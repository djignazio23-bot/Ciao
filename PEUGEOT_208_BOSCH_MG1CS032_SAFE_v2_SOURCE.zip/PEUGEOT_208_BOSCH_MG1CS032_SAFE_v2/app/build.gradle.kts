plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}

android {
    namespace = "com.peugeot208.boschsafe"
    compileSdk = 35

    defaultConfig {
        applicationId = "com.peugeot208.boschsafe"
        minSdk = 29
        targetSdk = 35
        versionCode = 3
        versionName = "2.0-bosch-safe"

        testInstrumentationRunner = "android.app.InstrumentationTestRunner"
    }

    buildTypes {
        release {
            isMinifyEnabled = false
        }
    }

    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }

    kotlinOptions {
        jvmTarget = "17"
    }
}
