#!/usr/bin/env bash
set -euo pipefail

HERE="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
REPO="${1:-$PWD}"

if [ ! -d "$REPO/.git" ]; then
  echo "ERRORE: esegui questo script dalla cartella principale della repository Git." >&2
  echo "Esempio: bash /tmp/chrome-shield/INSTALL_IN_REPO.sh" >&2
  exit 1
fi

mkdir -p "$REPO/.github/workflows"
cp -f "$HERE/payload/ChromeAdShield-project.zip" "$REPO/ChromeAdShield-project.zip"
cp -f "$HERE/payload/.github/workflows/build-chrome-ad-shield.yml" \
  "$REPO/.github/workflows/build-chrome-ad-shield.yml"

cd "$REPO"
git add ChromeAdShield-project.zip .github/workflows/build-chrome-ad-shield.yml

if git diff --cached --quiet; then
  echo "I file Chrome Ad Shield sono gia aggiornati. Nessun commit necessario."
else
  git commit -m "Add Chrome Ad Shield Android build"
  git push
fi

echo
echo "OK: progetto e workflow installati nella repository."
echo "Apri GitHub -> Actions -> Build Chrome Ad Shield APK."
echo "Al termine, scarica l'artifact 'ChromeAdShield-APK'."
