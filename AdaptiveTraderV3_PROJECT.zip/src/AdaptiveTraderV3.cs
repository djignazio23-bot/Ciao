using System;
using System.Linq;
using cAlgo.API;
using cAlgo.API.Indicators;

namespace cAlgo.Robots;

[Robot(TimeZone = TimeZones.UTC, AccessRights = AccessRights.None)]
public class AdaptiveTraderV3 : Robot
{
    [Parameter("Risk %", DefaultValue = 0.50, MinValue = 0.10, MaxValue = 1.00)] public double RiskPct { get; set; }
    [Parameter("Daily Loss %", DefaultValue = 2.0, MinValue = 0.5, MaxValue = 4.0)] public double DailyLossPct { get; set; }
    [Parameter("Daily Profit Lock %", DefaultValue = 2.5, MinValue = 0.5, MaxValue = 5.0)] public double DailyProfitPct { get; set; }
    [Parameter("Min RR", DefaultValue = 2.0, MinValue = 1.5, MaxValue = 4.0)] public double MinRR { get; set; }
    [Parameter("Max Trades/Day", DefaultValue = 6, MinValue = 1, MaxValue = 12)] public int MaxTrades { get; set; }
    [Parameter("Max Spread (pips)", DefaultValue = 1.8, MinValue = 0.2, MaxValue = 5.0)] public double MaxSpread { get; set; }
    [Parameter("Fast EMA", DefaultValue = 20)] public int FastPeriod { get; set; }
    [Parameter("Slow EMA", DefaultValue = 50)] public int SlowPeriod { get; set; }
    [Parameter("ATR", DefaultValue = 14)] public int AtrPeriod { get; set; }
    [Parameter("RSI", DefaultValue = 14)] public int RsiPeriod { get; set; }

    private const string Label = "AdaptiveTraderV3";
    private Bars _h1 = null!, _m15 = null!, _m5 = null!;
    private ExponentialMovingAverage _h1Fast = null!, _h1Slow = null!, _m15Fast = null!, _m15Slow = null!;
    private AverageTrueRange _atr = null!;
    private RelativeStrengthIndex _rsi = null!;
    private DateTime _day;
    private double _dayStartBalance;
    private int _tradesToday;
    private DateTime _lastM5Bar;

    protected override void OnStart()
    {
        _h1 = MarketData.GetBars(TimeFrame.Hour, SymbolName);
        _m15 = MarketData.GetBars(TimeFrame.Minute15, SymbolName);
        _m5 = MarketData.GetBars(TimeFrame.Minute5, SymbolName);
        _h1Fast = Indicators.ExponentialMovingAverage(_h1.ClosePrices, FastPeriod);
        _h1Slow = Indicators.ExponentialMovingAverage(_h1.ClosePrices, SlowPeriod);
        _m15Fast = Indicators.ExponentialMovingAverage(_m15.ClosePrices, FastPeriod);
        _m15Slow = Indicators.ExponentialMovingAverage(_m15.ClosePrices, SlowPeriod);
        _atr = Indicators.AverageTrueRange(_m15, AtrPeriod, MovingAverageType.Exponential);
        _rsi = Indicators.RelativeStrengthIndex(_m15.ClosePrices, RsiPeriod);
        ResetDay();
        Timer.Start(5);
        Print("AdaptiveTraderV3 DEMO-first started on {0}", SymbolName);
    }

    protected override void OnTimer()
    {
        if (Server.Time.Date != _day.Date) ResetDay();
        if (_m5.Count < 5 || _m15.Count < SlowPeriod + 5 || _h1.Count < SlowPeriod + 5) return;
        var closedM5 = _m5.OpenTimes.Last(1);
        if (closedM5 == _lastM5Bar) return;
        _lastM5Bar = closedM5;
        ManageOpenPosition();
        EvaluateEntry();
    }

    private void ResetDay()
    {
        _day = Server.Time.Date;
        _dayStartBalance = Account.Balance;
        _tradesToday = 0;
    }

    private void EvaluateEntry()
    {
        if (Positions.Find(Label, SymbolName) != null) return;
        if (_tradesToday >= MaxTrades) return;
        var pnl = Account.Equity - _dayStartBalance;
        if (pnl <= -_dayStartBalance * DailyLossPct / 100.0) return;
        if (pnl >= _dayStartBalance * DailyProfitPct / 100.0) return;
        var spreadPips = (Symbol.Ask - Symbol.Bid) / Symbol.PipSize;
        if (spreadPips > MaxSpread) return;

        var atrPips = _atr.Result.Last(1) / Symbol.PipSize;
        if (atrPips < 3 || atrPips > 80) return;

        bool upH1 = _h1Fast.Result.Last(1) > _h1Slow.Result.Last(1) && _h1Fast.Result.Last(1) > _h1Fast.Result.Last(3);
        bool dnH1 = _h1Fast.Result.Last(1) < _h1Slow.Result.Last(1) && _h1Fast.Result.Last(1) < _h1Fast.Result.Last(3);
        bool upM15 = _m15Fast.Result.Last(1) > _m15Slow.Result.Last(1);
        bool dnM15 = _m15Fast.Result.Last(1) < _m15Slow.Result.Last(1);
        var rsi = _rsi.Result.Last(1);
        var lastClose = _m5.ClosePrices.Last(1);
        var prevHigh = _m5.HighPrices.Maximum(6);
        var prevLow = _m5.LowPrices.Minimum(6);

        TradeType? side = null;
        int score = 0;
        if (upH1 && upM15) { score += 2; if (rsi > 50 && rsi < 70) score++; if (lastClose >= prevHigh - 0.15 * _atr.Result.Last(1)) score++; side = TradeType.Buy; }
        if (dnH1 && dnM15) { score += 2; if (rsi < 50 && rsi > 30) score++; if (lastClose <= prevLow + 0.15 * _atr.Result.Last(1)) score++; side = TradeType.Sell; }
        if (side == null || score < 3) return;

        var stopPips = Math.Max(atrPips * 1.25, spreadPips * 4.0);
        var takePips = stopPips * MinRR;
        var riskMoney = Math.Min(Account.Balance * RiskPct / 100.0, 1.0); // €200 demo: cap near €1
        var volume = Symbol.VolumeForFixedRisk(riskMoney, stopPips, RoundingMode.Down);
        volume = Symbol.NormalizeVolumeInUnits(volume, RoundingMode.Down);
        if (volume < Symbol.VolumeInUnitsMin) return;

        var result = ExecuteMarketOrder(side.Value, SymbolName, volume, Label, stopPips, takePips);
        if (result.IsSuccessful) _tradesToday++;
    }

    private void ManageOpenPosition()
    {
        var p = Positions.Find(Label, SymbolName);
        if (p == null || !p.StopLoss.HasValue) return;
        var initialRisk = Math.Abs(p.EntryPrice - p.StopLoss.Value);
        if (initialRisk <= 0) return;
        var favorable = p.TradeType == TradeType.Buy ? Symbol.Bid - p.EntryPrice : p.EntryPrice - Symbol.Ask;
        if (favorable < initialRisk) return;
        // At +1R, protect approximately break-even once; never widen risk.
        bool needsBe = p.TradeType == TradeType.Buy ? p.StopLoss.Value < p.EntryPrice : p.StopLoss.Value > p.EntryPrice;
        if (needsBe) ModifyPosition(p, p.EntryPrice, p.TakeProfit, ProtectionType.Absolute);
    }
}
