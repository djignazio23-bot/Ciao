# MultiSymbolReactiveEmaRsiAtrBot

Repository pronto per compilare il cBot cTrader con GitHub Actions e ottenere un file `.algo`.

## Come ottenere il file .algo

1. Crea un nuovo repository GitHub vuoto.
2. Carica **tutti** i file e le cartelle di questo pacchetto, inclusa `.github/workflows/build-algo.yml`.
3. Assicurati che il branch principale si chiami `main`.
4. Apri la scheda **Actions** del repository.
5. Apri **Build cTrader ALGO**.
6. Premi **Run workflow** > **Run workflow**.
7. Attendi il segno verde della build.
8. Apri l'esecuzione terminata.
9. In **Artifacts**, scarica `MultiSymbolReactiveEmaRsiAtrBot-ALGO`.
10. Dentro lo ZIP scaricato da GitHub troverai il file `.algo`.

La build parte anche automaticamente a ogni push sul branch `main` quando modifichi il codice C#, il progetto o il workflow.

## File principali

- `MultiSymbolReactiveEmaRsiAtrBot.cs`: codice del cBot.
- `MultiSymbolReactiveEmaRsiAtrBot.csproj`: progetto .NET con `cTrader.Automate`.
- `.github/workflows/build-algo.yml`: workflow GitHub Actions.

## Nota

Il workflow compila realmente il cBot. Se il codice contiene un errore dell'API cTrader, la Action diventerà rossa e il log indicherà riga ed errore da correggere.
