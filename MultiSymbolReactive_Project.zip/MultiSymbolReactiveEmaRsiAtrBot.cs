using System;
using System.Collections.Generic;
using System.Linq;
using cAlgo.API;
using cAlgo.API.Indicators;
using cAlgo.API.Internals;

namespace cAlgo.Robots
{
    [Robot(TimeZone = TimeZones.UTC, AccessRights = AccessRights.None)]
    public class MultiSymbolReactiveEmaRsiAtrBot : Robot
    {
        [Parameter("Symbols", DefaultValue = "EURUSD,GBPUSD,USDJPY,EURGBP,AUDUSD", Group = "Markets")]
        public string SymbolsCsv { get; set; }

        [Parameter("Entry Timeframe", DefaultValue = "Minute1", Group = "Markets")]
        public TimeFrame EntryTimeFrame { get; set; }

        [Parameter("Trend Timeframe", DefaultValue = "Minute15", Group = "Markets")]
        public TimeFrame TrendTimeFrame { get; set; }

        [Parameter("Realtime Scan ms", DefaultValue = 1000, MinValue = 250, MaxValue = 5000, Step = 250, Group = "Markets")]
        public int RealtimeScanMilliseconds { get; set; }

        [Parameter("Fast EMA", DefaultValue = 8, MinValue = 2, Group = "Strategy")]
        public int FastEmaPeriod { get; set; }

        [Parameter("Slow EMA", DefaultValue = 21, MinValue = 5, Group = "Strategy")]
        public int SlowEmaPeriod { get; set; }

        [Parameter("RSI", DefaultValue = 9, MinValue = 2, Group = "Strategy")]
        public int RsiPeriod { get; set; }

        [Parameter("ATR", DefaultValue = 10, MinValue = 2, Group = "Strategy")]
        public int AtrPeriod { get; set; }

        [Parameter("RSI Buy Min", DefaultValue = 48, MinValue = 0, MaxValue = 100, Group = "Strategy")]
        public double RsiBuyMin { get; set; }

        [Parameter("RSI Buy Max", DefaultValue = 76, MinValue = 0, MaxValue = 100, Group = "Strategy")]
        public double RsiBuyMax { get; set; }

        [Parameter("RSI Sell Min", DefaultValue = 24, MinValue = 0, MaxValue = 100, Group = "Strategy")]
        public double RsiSellMin { get; set; }

        [Parameter("RSI Sell Max", DefaultValue = 52, MinValue = 0, MaxValue = 100, Group = "Strategy")]
        public double RsiSellMax { get; set; }

        [Parameter("Breakout Lookback", DefaultValue = 6, MinValue = 3, MaxValue = 50, Group = "Strategy")]
        public int BreakoutLookback { get; set; }

        [Parameter("Min Entry Score", DefaultValue = 13, MinValue = 1, MaxValue = 100, Group = "Strategy")]
        public double ManualMinEntryScore { get; set; }

        [Parameter("Cooldown Seconds", DefaultValue = 8, MinValue = 0, MaxValue = 300, Group = "Strategy")]
        public int CooldownSeconds { get; set; }

        [Parameter("Max Spread / ATR", DefaultValue = 0.28, MinValue = 0.02, MaxValue = 1.0, Step = 0.01, Group = "Strategy")]
        public double MaxSpreadAtrRatio { get; set; }

        [Parameter("Stop Loss x ATR", DefaultValue = 1.0, MinValue = 0.2, MaxValue = 5.0, Group = "Position")]
        public double AtrStopLossMultiplier { get; set; }

        [Parameter("Take Profit x ATR", DefaultValue = 1.35, MinValue = 0.2, MaxValue = 10.0, Group = "Position")]
        public double AtrTakeProfitMultiplier { get; set; }

        [Parameter("Min Stop Pips", DefaultValue = 5.0, MinValue = 1.0, MaxValue = 50.0, Group = "Position")]
        public double MinStopPips { get; set; }

        [Parameter("Max Stop Pips", DefaultValue = 18.0, MinValue = 2.0, MaxValue = 100.0, Group = "Position")]
        public double MaxStopPips { get; set; }

        [Parameter("Use Break Even", DefaultValue = true, Group = "Position")]
        public bool UseBreakEven { get; set; }

        [Parameter("Break Even x ATR", DefaultValue = 0.65, MinValue = 0.1, MaxValue = 5.0, Group = "Position")]
        public double BreakEvenAtrMultiplier { get; set; }

        [Parameter("Use Trailing", DefaultValue = true, Group = "Position")]
        public bool UseTrailingStop { get; set; }

        [Parameter("Trailing Start x ATR", DefaultValue = 0.85, MinValue = 0.1, MaxValue = 5.0, Group = "Position")]
        public double TrailingStartAtrMultiplier { get; set; }

        [Parameter("Trailing Distance x ATR", DefaultValue = 0.50, MinValue = 0.1, MaxValue = 5.0, Group = "Position")]
        public double TrailingDistanceAtrMultiplier { get; set; }

        [Parameter("Risk per Trade %", DefaultValue = 0.35, MinValue = 0.05, MaxValue = 5.0, Step = 0.05, Group = "Risk")]
        public double RiskPercentPerTrade { get; set; }

        [Parameter("Demo Min-Lot Risk Cap %", DefaultValue = 0.80, MinValue = 0.10, MaxValue = 3.0, Step = 0.05, Group = "Risk")]
        public double DemoMinLotRiskCapPct { get; set; }

        [Parameter("Max Daily Loss %", DefaultValue = 4.0, MinValue = 0.5, MaxValue = 50, Group = "Risk")]
        public double MaxDailyLossPercent { get; set; }

        [Parameter("Min Margin Level %", DefaultValue = 250, MinValue = 100, MaxValue = 2000, Group = "Risk")]
        public double MinMarginLevelPercent { get; set; }

        [Parameter("Max Margin / Free %", DefaultValue = 35, MinValue = 5, MaxValue = 90, Group = "Risk")]
        public double MaxMarginUsePct { get; set; }

        [Parameter("Max Open Positions", DefaultValue = 3, MinValue = 1, MaxValue = 20, Group = "Risk")]
        public int MaxOpenPositions { get; set; }

        [Parameter("Max Positions / Symbol", DefaultValue = 1, MinValue = 1, MaxValue = 5, Group = "Risk")]
        public int MaxPositionsPerSymbol { get; set; }

        [Parameter("Enable Rotation", DefaultValue = true, Group = "Rotation")]
        public bool EnableRotation { get; set; }

        [Parameter("Min Score Advantage %", DefaultValue = 25, MinValue = 1, MaxValue = 200, Group = "Rotation")]
        public double MinScoreAdvantagePercent { get; set; }

        [Parameter("Rotate Only >= Breakeven", DefaultValue = true, Group = "Rotation")]
        public bool OnlyCloseAtOrAboveBreakeven { get; set; }

        [Parameter("Min Pips to Rotate", DefaultValue = 0, Group = "Rotation")]
        public double MinProfitPipsToRotate { get; set; }

        [Parameter("Auto Adapt Budget", DefaultValue = true, Group = "Budget")]
        public bool EnableBudgetAdaptation { get; set; }

        [Parameter("Tier 1 Max Equity", DefaultValue = 500, MinValue = 1, Group = "Budget")]
        public double Tier1MaxEquity { get; set; }

        [Parameter("Tier 2 Max Equity", DefaultValue = 2000, MinValue = 1, Group = "Budget")]
        public double Tier2MaxEquity { get; set; }

        [Parameter("Tier 3 Max Equity", DefaultValue = 10000, MinValue = 1, Group = "Budget")]
        public double Tier3MaxEquity { get; set; }

        [Parameter("12H Adaptive", DefaultValue = true, Group = "12H")]
        public bool EnableTwelveHourAdaptive { get; set; }

        [Parameter("12H Window Hours", DefaultValue = 12, MinValue = 1, MaxValue = 24, Group = "12H")]
        public int ProfitWindowHours { get; set; }

        [Parameter("12H Profit Goal", DefaultValue = 0.50, MinValue = 0.01, MaxValue = 100, Step = 0.10, Group = "12H")]
        public double TwelveHourProfitGoal { get; set; }

        [Parameter("Aggressive Score Reduction", DefaultValue = 3.0, MinValue = 0, MaxValue = 20, Step = 0.5, Group = "12H")]
        public double AggressiveScoreReduction { get; set; }

        [Parameter("Aggressive Cooldown Sec", DefaultValue = 2, MinValue = 0, MaxValue = 60, Group = "12H")]
        public int AggressiveCooldownSeconds { get; set; }

        [Parameter("Aggressive Spread / ATR", DefaultValue = 0.35, MinValue = 0.02, MaxValue = 1.0, Step = 0.01, Group = "12H")]
        public double AggressiveMaxSpreadAtrRatio { get; set; }

        [Parameter("Heartbeat Minutes", DefaultValue = 3, MinValue = 1, MaxValue = 60, Group = "Status")]
        public int HeartbeatMinutes { get; set; }

        [Parameter("Verbose Logs", DefaultValue = false, Group = "Status")]
        public bool VerboseLogs { get; set; }

        [Parameter("Label", DefaultValue = "MultiSymReactive")]
        public string BotLabel { get; set; }

        private class BudgetTier
        {
            public string Name;
            public int ActiveSymbolCount;
            public int MaxOpenPositions;
            public double RiskPercentPerTrade;
            public double MinEntryScore;
            public double RotationAdvantagePct;
        }

        private class SymbolContext
        {
            public string Name;
            public Symbol Symbol;
            public Bars EntryBars;
            public Bars TrendBars;
            public ExponentialMovingAverage FastEma;
            public ExponentialMovingAverage SlowEma;
            public RelativeStrengthIndex Rsi;
            public AverageTrueRange Atr;
            public ExponentialMovingAverage TrendFastEma;
            public ExponentialMovingAverage TrendSlowEma;
            public DateTime LastRealtimeScan = DateTime.MinValue;
            public DateTime LastEntryTime = DateTime.MinValue;
        }

        private class Candidate
        {
            public SymbolContext Ctx;
            public TradeType TradeType;
            public string Setup;
            public double Score;
            public double Atr;
        }

        private readonly Dictionary<string, SymbolContext> _contexts = new Dictionary<string, SymbolContext>(StringComparer.OrdinalIgnoreCase);
        private readonly List<string> _symbolOrder = new List<string>();
        private HashSet<string> _activeSymbols = new HashSet<string>(StringComparer.OrdinalIgnoreCase);

        private double _effRiskPercentPerTrade;
        private int _effMaxOpenPositions;
        private double _effMinEntryScore;
        private double _effRotationAdvantagePct;

        private DateTime _currentTradingDay;
        private double _dailyStartEquity;
        private bool _dailyLossLimitHit;

        private DateTime _profitWindowStart;
        private double _profitWindowStartEquity;
        private bool _aggressiveMode;
        private DateTime _nextHeartbeat;

        private long _scanCount;
        private long _candidateCount;
        private long _orderCount;
        private long _riskBlockCount;
        private long _spreadBlockCount;

        protected override void OnStart()
        {
            LoadSymbols();

            _currentTradingDay = Server.Time.Date;
            _dailyStartEquity = ReconstructTodayStartEquity();
            _dailyLossLimitHit = false;

            _profitWindowStart = Server.Time;
            _profitWindowStartEquity = Account.Equity;
            _aggressiveMode = false;

            RecomputeBudgetAdaptation();
            Positions.Closed += OnPositionClosed;

            _nextHeartbeat = Server.Time.AddMinutes(HeartbeatMinutes);
            Timer.Start(1);

            Print("BOT AVVIATO CORRETTAMENTE");
            Print("Simboli caricati: {0} | Entry TF: {1} | Trend TF: {2}", _contexts.Count, EntryTimeFrame, TrendTimeFrame);
            Print("12H: {0} | Risk effettivo: {1:F2}% | MinScore: {2:F1}",
                EnableTwelveHourAdaptive ? "ON" : "OFF", _effRiskPercentPerTrade, CurrentMinEntryScore());
        }

        private void LoadSymbols()
        {
            IEnumerable<string> names = string.IsNullOrWhiteSpace(SymbolsCsv)
                ? Symbols.ToList()
                : SymbolsCsv.Split(',').Select(x => x.Trim()).Where(x => x.Length > 0).Distinct(StringComparer.OrdinalIgnoreCase);

            foreach (string name in names)
            {
                try
                {
                    Symbol symbol = Symbols.GetSymbol(name);
                    if (symbol == null)
                    {
                        Print("SKIP {0}: simbolo non disponibile", name);
                        continue;
                    }

                    Bars entryBars = MarketData.GetBars(EntryTimeFrame, name);
                    Bars trendBars = MarketData.GetBars(TrendTimeFrame, name);

                    var ctx = new SymbolContext
                    {
                        Name = name,
                        Symbol = symbol,
                        EntryBars = entryBars,
                        TrendBars = trendBars,
                        FastEma = Indicators.ExponentialMovingAverage(entryBars.ClosePrices, FastEmaPeriod),
                        SlowEma = Indicators.ExponentialMovingAverage(entryBars.ClosePrices, SlowEmaPeriod),
                        Rsi = Indicators.RelativeStrengthIndex(entryBars.ClosePrices, RsiPeriod),
                        Atr = Indicators.AverageTrueRange(entryBars, AtrPeriod, MovingAverageType.Exponential),
                        TrendFastEma = Indicators.ExponentialMovingAverage(trendBars.ClosePrices, FastEmaPeriod),
                        TrendSlowEma = Indicators.ExponentialMovingAverage(trendBars.ClosePrices, SlowEmaPeriod)
                    };

                    ctx.EntryBars.BarOpened += args => OnEntryBarOpened(ctx);
                    ctx.Symbol.Tick += args => OnSymbolTick(ctx);

                    _contexts[name] = ctx;
                    _symbolOrder.Add(name);
                }
                catch (Exception ex)
                {
                    Print("SKIP {0}: {1}", name, ex.Message);
                }
            }
        }

        private BudgetTier CurrentTier(double equity)
        {
            if (equity <= Tier1MaxEquity)
                return new BudgetTier { Name = "Piccolo", ActiveSymbolCount = 5, MaxOpenPositions = 2, RiskPercentPerTrade = 0.35, MinEntryScore = 13, RotationAdvantagePct = 30 };

            if (equity <= Tier2MaxEquity)
                return new BudgetTier { Name = "Medio", ActiveSymbolCount = 8, MaxOpenPositions = 4, RiskPercentPerTrade = 0.45, MinEntryScore = 12, RotationAdvantagePct = 25 };

            if (equity <= Tier3MaxEquity)
                return new BudgetTier { Name = "Grande", ActiveSymbolCount = 12, MaxOpenPositions = 6, RiskPercentPerTrade = 0.55, MinEntryScore = 11, RotationAdvantagePct = 20 };

            return new BudgetTier { Name = "Molto grande", ActiveSymbolCount = int.MaxValue, MaxOpenPositions = 8, RiskPercentPerTrade = 0.60, MinEntryScore = 10, RotationAdvantagePct = 20 };
        }

        private void RecomputeBudgetAdaptation()
        {
            if (!EnableBudgetAdaptation)
            {
                _effRiskPercentPerTrade = RiskPercentPerTrade;
                _effMaxOpenPositions = MaxOpenPositions;
                _effMinEntryScore = ManualMinEntryScore;
                _effRotationAdvantagePct = MinScoreAdvantagePercent;
                _activeSymbols = new HashSet<string>(_symbolOrder, StringComparer.OrdinalIgnoreCase);
                return;
            }

            BudgetTier tier = CurrentTier(Account.Equity);
            _effRiskPercentPerTrade = tier.RiskPercentPerTrade;
            _effMaxOpenPositions = Math.Min(MaxOpenPositions, tier.MaxOpenPositions);
            _effMinEntryScore = tier.MinEntryScore;
            _effRotationAdvantagePct = tier.RotationAdvantagePct;

            int count = Math.Min(tier.ActiveSymbolCount, _symbolOrder.Count);
            _activeSymbols = new HashSet<string>(_symbolOrder.Take(count), StringComparer.OrdinalIgnoreCase);

            Print("Budget={0} | Equity={1:F2} | Attivi={2}/{3} | MaxPos={4} | Risk={5:F2}% | MinScore={6:F1}",
                tier.Name, Account.Equity, _activeSymbols.Count, _symbolOrder.Count, _effMaxOpenPositions, _effRiskPercentPerTrade, _effMinEntryScore);
        }

        private void OnSymbolTick(SymbolContext ctx)
        {
            ResetDailyCounterIfNewDay();
            CheckDailyLossLimit();
            ManageOpenPositions(ctx);

            if (_dailyLossLimitHit || !_activeSymbols.Contains(ctx.Name))
                return;

            if ((Server.Time - ctx.LastRealtimeScan).TotalMilliseconds < RealtimeScanMilliseconds)
                return;

            ctx.LastRealtimeScan = Server.Time;
            _scanCount++;
            TryProcessCandidate(ctx, true);
        }

        private void OnEntryBarOpened(SymbolContext ctx)
        {
            ResetDailyCounterIfNewDay();
            CheckDailyLossLimit();

            if (_dailyLossLimitHit || !_activeSymbols.Contains(ctx.Name))
                return;

            TryProcessCandidate(ctx, false);
        }

        private void TryProcessCandidate(SymbolContext ctx, bool live)
        {
            if (!PassesAccountLevelChecks())
                return;

            if (Positions.FindAll(BotLabel, ctx.Name).Length >= MaxPositionsPerSymbol)
                return;

            if ((Server.Time - ctx.LastEntryTime).TotalSeconds < CurrentCooldownSeconds())
                return;

            Candidate candidate = BuildCandidate(ctx, live);
            if (candidate == null)
                return;

            _candidateCount++;

            if (candidate.Score < CurrentMinEntryScore())
            {
                if (VerboseLogs)
                    Print("{0} {1}: score {2:F1} < {3:F1}", ctx.Name, candidate.Setup, candidate.Score, CurrentMinEntryScore());
                return;
            }

            if (Positions.FindAll(BotLabel).Length < _effMaxOpenPositions)
            {
                ExecuteTrade(candidate);
                return;
            }

            if (EnableRotation)
                TryRotateIntoCandidate(candidate);
        }

        private Candidate BuildCandidate(SymbolContext ctx, bool live)
        {
            int count = ctx.EntryBars.ClosePrices.Count;
            int current = live ? count - 1 : count - 2;
            int previous = current - 1;

            if (previous < SlowEmaPeriod + 3 || ctx.TrendBars.ClosePrices.Count < SlowEmaPeriod + 3)
                return null;

            double atr = ctx.Atr.Result[current];
            if (atr <= 0 || double.IsNaN(atr) || double.IsInfinity(atr))
                return null;

            double spread = ctx.Symbol.Ask - ctx.Symbol.Bid;
            double spreadAtr = spread / atr;

            if (spreadAtr <= 0 || spreadAtr > CurrentMaxSpreadAtrRatio())
            {
                _spreadBlockCount++;
                return null;
            }

            double fast = ctx.FastEma.Result[current];
            double slow = ctx.SlowEma.Result[current];
            double fastPrev = ctx.FastEma.Result[previous];
            double slowPrev = ctx.SlowEma.Result[previous];
            double rsi = ctx.Rsi.Result[current];

            int trendIndex = ctx.TrendBars.ClosePrices.Count - 2;
            double trendFast = ctx.TrendFastEma.Result[trendIndex];
            double trendSlow = ctx.TrendSlowEma.Result[trendIndex];
            bool trendUp = trendFast > trendSlow;
            bool trendDown = trendFast < trendSlow;

            Bar bar = ctx.EntryBars[current];
            double range = Math.Max(0, bar.High - bar.Low);
            double momentum = Math.Min(range / atr, 2.0);
            double separation = Math.Abs(fast - slow) / atr;

            var candidates = new List<Candidate>();

            bool crossUp = fastPrev <= slowPrev && fast > slow;
            bool crossDown = fastPrev >= slowPrev && fast < slow;

            if (crossUp && trendUp && rsi >= RsiBuyMin && rsi <= RsiBuyMax)
                candidates.Add(NewCandidate(ctx, TradeType.Buy, "CROSS", 16 + Math.Min(separation * 15, 8) + momentum * 2.5 - spreadAtr * 10, atr));

            if (crossDown && trendDown && rsi >= RsiSellMin && rsi <= RsiSellMax)
                candidates.Add(NewCandidate(ctx, TradeType.Sell, "CROSS", 16 + Math.Min(separation * 15, 8) + momentum * 2.5 - spreadAtr * 10, atr));

            if (fast > slow && trendUp && bar.Close >= fast && rsi >= Math.Max(RsiBuyMin, 50) && rsi <= RsiBuyMax)
                candidates.Add(NewCandidate(ctx, TradeType.Buy, "TREND", 13 + Math.Min(separation * 12, 8) + Math.Min((rsi - 50) * 0.20, 4) + momentum * 2 - spreadAtr * 9, atr));

            if (fast < slow && trendDown && bar.Close <= fast && rsi <= Math.Min(RsiSellMax, 50) && rsi >= RsiSellMin)
                candidates.Add(NewCandidate(ctx, TradeType.Sell, "TREND", 13 + Math.Min(separation * 12, 8) + Math.Min((50 - rsi) * 0.20, 4) + momentum * 2 - spreadAtr * 9, atr));

            bool bullishPullback = fast > slow && trendUp && bar.Low <= fast && bar.Close >= fast && bar.Close >= bar.Open;
            bool bearishPullback = fast < slow && trendDown && bar.High >= fast && bar.Close <= fast && bar.Close <= bar.Open;

            if (bullishPullback && rsi >= 45 && rsi <= 70)
                candidates.Add(NewCandidate(ctx, TradeType.Buy, "PULLBACK", 15 + Math.Min(separation * 10, 7) + momentum * 2 - spreadAtr * 9, atr));

            if (bearishPullback && rsi <= 55 && rsi >= 30)
                candidates.Add(NewCandidate(ctx, TradeType.Sell, "PULLBACK", 15 + Math.Min(separation * 10, 7) + momentum * 2 - spreadAtr * 9, atr));

            double previousHigh = double.MinValue;
            double previousLow = double.MaxValue;
            int from = Math.Max(0, current - BreakoutLookback);

            for (int i = from; i < current; i++)
            {
                previousHigh = Math.Max(previousHigh, ctx.EntryBars.HighPrices[i]);
                previousLow = Math.Min(previousLow, ctx.EntryBars.LowPrices[i]);
            }

            if (bar.Close > previousHigh && fast > slow && trendUp && rsi < 78)
            {
                double strength = Math.Min((bar.Close - previousHigh) / atr * 10, 6);
                candidates.Add(NewCandidate(ctx, TradeType.Buy, "BREAKOUT", 17 + strength + Math.Min(separation * 10, 6) - spreadAtr * 8, atr));
            }

            if (bar.Close < previousLow && fast < slow && trendDown && rsi > 22)
            {
                double strength = Math.Min((previousLow - bar.Close) / atr * 10, 6);
                candidates.Add(NewCandidate(ctx, TradeType.Sell, "BREAKOUT", 17 + strength + Math.Min(separation * 10, 6) - spreadAtr * 8, atr));
            }

            return candidates.Count == 0 ? null : candidates.OrderByDescending(x => x.Score).First();
        }

        private Candidate NewCandidate(SymbolContext ctx, TradeType type, string setup, double score, double atr)
        {
            return new Candidate { Ctx = ctx, TradeType = type, Setup = setup, Score = score, Atr = atr };
        }

        private void ExecuteTrade(Candidate candidate)
        {
            SymbolContext ctx = candidate.Ctx;
            Symbol symbol = ctx.Symbol;

            double rawStopPips = candidate.Atr * AtrStopLossMultiplier / symbol.PipSize;
            double stopPips = Math.Max(MinStopPips, Math.Min(rawStopPips, MaxStopPips));
            double rawTpPips = candidate.Atr * AtrTakeProfitMultiplier / symbol.PipSize;
            double takeProfitPips = Math.Max(rawTpPips, stopPips * 1.15);
            double spreadPips = (symbol.Ask - symbol.Bid) / symbol.PipSize;

            if (spreadPips <= 0 || takeProfitPips <= spreadPips * 1.5)
            {
                _spreadBlockCount++;
                return;
            }

            double volume = symbol.VolumeForProportionalRisk(
                ProportionalAmountType.Equity,
                _effRiskPercentPerTrade,
                stopPips,
                RoundingMode.Down);

            bool usingBrokerMinimum = false;

            if (volume < symbol.VolumeInUnitsMin)
            {
                double minVolume = symbol.NormalizeVolumeInUnits(symbol.VolumeInUnitsMin, RoundingMode.Up);
                double minRiskAmount = symbol.AmountRisked(minVolume, stopPips);
                double minRiskPct = Account.Equity > 0 ? minRiskAmount / Account.Equity * 100.0 : 100.0;

                if (!Account.IsLive && minRiskPct <= DemoMinLotRiskCapPct)
                {
                    volume = minVolume;
                    usingBrokerMinimum = true;
                }
                else
                {
                    _riskBlockCount++;
                    if (VerboseLogs)
                        Print("{0}: lotto minimo rischierebbe {1:F2}% -> SKIP", ctx.Name, minRiskPct);
                    return;
                }
            }

            volume = symbol.NormalizeVolumeInUnits(volume, RoundingMode.Down);
            if (volume <= 0)
            {
                _riskBlockCount++;
                return;
            }

            double actualRiskAmount = symbol.AmountRisked(volume, stopPips);
            double actualRiskPct = Account.Equity > 0 ? actualRiskAmount / Account.Equity * 100.0 : 100.0;
            double allowedRiskPct = usingBrokerMinimum && !Account.IsLive
                ? DemoMinLotRiskCapPct
                : _effRiskPercentPerTrade * 1.20;

            if (actualRiskPct > allowedRiskPct)
            {
                _riskBlockCount++;
                return;
            }

            double estimatedMargin = symbol.GetEstimatedMargin(candidate.TradeType, volume);
            double maxMarginAllowed = Account.FreeMargin * MaxMarginUsePct / 100.0;

            if (estimatedMargin <= 0 || estimatedMargin > Account.FreeMargin || estimatedMargin > maxMarginAllowed)
            {
                _riskBlockCount++;
                return;
            }

            TradeResult result = ExecuteMarketOrder(
                candidate.TradeType,
                ctx.Name,
                volume,
                BotLabel,
                stopPips,
                takeProfitPips,
                candidate.Setup);

            if (!result.IsSuccessful)
            {
                Print("{0} {1}: ordine fallito - {2}", ctx.Name, candidate.Setup, result.Error);
                return;
            }

            ctx.LastEntryTime = Server.Time;
            _orderCount++;

            Print("OPEN {0} {1} | {2} | score={3:F1} | vol={4} | SL={5:F1}p | TP={6:F1}p | risk={7:F2}%",
                ctx.Name, candidate.TradeType, candidate.Setup, candidate.Score, volume, stopPips, takeProfitPips, actualRiskPct);
        }

        private void ManageOpenPositions(SymbolContext ctx)
        {
            Position[] positions = Positions.FindAll(BotLabel, ctx.Name);
            if (positions.Length == 0)
                return;

            double atr = ctx.Atr.Result.LastValue;
            if (atr <= 0)
                return;

            foreach (Position position in positions)
            {
                double profitDistance = position.TradeType == TradeType.Buy
                    ? ctx.Symbol.Bid - position.EntryPrice
                    : position.EntryPrice - ctx.Symbol.Ask;

                if (UseBreakEven && profitDistance >= atr * BreakEvenAtrMultiplier)
                {
                    double breakEvenPrice = position.EntryPrice;
                    bool improve = position.StopLoss == null ||
                        (position.TradeType == TradeType.Buy && breakEvenPrice > position.StopLoss.Value) ||
                        (position.TradeType == TradeType.Sell && breakEvenPrice < position.StopLoss.Value);

                    if (improve)
                        ModifyPosition(position, breakEvenPrice, position.TakeProfit);
                }

                if (!UseTrailingStop || profitDistance < atr * TrailingStartAtrMultiplier)
                    continue;

                double trailingDistance = atr * TrailingDistanceAtrMultiplier;
                double newStop = position.TradeType == TradeType.Buy
                    ? ctx.Symbol.Bid - trailingDistance
                    : ctx.Symbol.Ask + trailingDistance;

                bool trailingImproves = position.StopLoss == null ||
                    (position.TradeType == TradeType.Buy && newStop > position.StopLoss.Value) ||
                    (position.TradeType == TradeType.Sell && newStop < position.StopLoss.Value);

                if (trailingImproves)
                    ModifyPosition(position, newStop, position.TakeProfit);
            }
        }

        private void TryRotateIntoCandidate(Candidate candidate)
        {
            Position[] openPositions = Positions.FindAll(BotLabel);
            if (openPositions.Length == 0)
                return;

            int candidateSymbolCount = Positions.FindAll(BotLabel, candidate.Ctx.Name).Length;
            bool symbolIsFull = candidateSymbolCount >= MaxPositionsPerSymbol;

            Position weakest = null;
            double weakestScore = double.MaxValue;

            foreach (Position position in openPositions)
            {
                if (symbolIsFull && !string.Equals(position.SymbolName, candidate.Ctx.Name, StringComparison.OrdinalIgnoreCase))
                    continue;

                if (!IsEligibleForRotationClose(position))
                    continue;

                SymbolContext posCtx;
                if (!_contexts.TryGetValue(position.SymbolName, out posCtx))
                    continue;

                double score = ScoreForExistingPosition(posCtx, position);
                if (score < weakestScore)
                {
                    weakestScore = score;
                    weakest = position;
                }
            }

            if (weakest == null)
                return;

            double advantage = weakestScore <= 0
                ? double.MaxValue
                : (candidate.Score - weakestScore) / weakestScore * 100.0;

            if (advantage < _effRotationAdvantagePct)
                return;

            TradeResult closeResult = ClosePosition(weakest);
            if (!closeResult.IsSuccessful)
            {
                Print("ROTATION FAILED: {0}", closeResult.Error);
                return;
            }

            Print("ROTATE {0} -> {1} {2} | oldScore={3:F1} newScore={4:F1}",
                weakest.SymbolName, candidate.Ctx.Name, candidate.TradeType, weakestScore, candidate.Score);

            ExecuteTrade(candidate);
        }

        private bool IsEligibleForRotationClose(Position position)
        {
            if (!OnlyCloseAtOrAboveBreakeven)
                return true;

            return position.Pips >= MinProfitPipsToRotate;
        }

        private double ScoreForExistingPosition(SymbolContext ctx, Position position)
        {
            int current = ctx.EntryBars.ClosePrices.Count - 1;
            if (current < SlowEmaPeriod + 2 || ctx.TrendBars.ClosePrices.Count < SlowEmaPeriod + 2)
                return 0;

            double atr = ctx.Atr.Result[current];
            if (atr <= 0)
                return 0;

            double fast = ctx.FastEma.Result[current];
            double slow = ctx.SlowEma.Result[current];
            double rsi = ctx.Rsi.Result[current];

            int trendIndex = ctx.TrendBars.ClosePrices.Count - 2;
            double trendFast = ctx.TrendFastEma.Result[trendIndex];
            double trendSlow = ctx.TrendSlowEma.Result[trendIndex];

            bool directionStillValid = position.TradeType == TradeType.Buy
                ? fast > slow && trendFast > trendSlow
                : fast < slow && trendFast < trendSlow;

            if (!directionStillValid)
                return 0;

            double separation = Math.Abs(fast - slow) / atr;
            double rsiDirectional = position.TradeType == TradeType.Buy
                ? Math.Max(0, rsi - 50)
                : Math.Max(0, 50 - rsi);

            return 10 + Math.Min(separation * 12, 8) + Math.Min(rsiDirectional * 0.20, 4);
        }

        private bool PassesAccountLevelChecks()
        {
            CheckDailyLossLimit();
            if (_dailyLossLimitHit)
                return false;

            if (Account.MarginLevel.HasValue && Positions.Count > 0 && Account.MarginLevel.Value < MinMarginLevelPercent)
            {
                if (VerboseLogs)
                    Print("Margin level {0:F1}% < {1:F1}%", Account.MarginLevel.Value, MinMarginLevelPercent);
                return false;
            }

            return true;
        }

        private double ReconstructTodayStartEquity()
        {
            try
            {
                double realizedToday = History.FindAll(BotLabel)
                    .Where(x => x.ClosingTime.Date == Server.Time.Date)
                    .Sum(x => x.NetProfit);

                return Math.Max(0.01, Account.Balance - realizedToday);
            }
            catch
            {
                return Math.Max(0.01, Account.Equity);
            }
        }

        private void ResetDailyCounterIfNewDay()
        {
            if (Server.Time.Date == _currentTradingDay)
                return;

            _currentTradingDay = Server.Time.Date;
            _dailyStartEquity = ReconstructTodayStartEquity();
            _dailyLossLimitHit = false;
            RecomputeBudgetAdaptation();

            Print("NUOVO GIORNO | Equity riferimento={0:F2}", _dailyStartEquity);
        }

        private void CheckDailyLossLimit()
        {
            if (_dailyStartEquity <= 0)
                return;

            double lossPercent = (_dailyStartEquity - Account.Equity) / _dailyStartEquity * 100.0;

            if (lossPercent >= MaxDailyLossPercent && !_dailyLossLimitHit)
            {
                _dailyLossLimitHit = true;
                Print("DAILY STOP | perdita={0:F2}% | nessun nuovo ingresso fino a domani", lossPercent);
            }
        }

        private double ProfitWindowPnl()
        {
            return Account.Equity - _profitWindowStartEquity;
        }

        private double CurrentMinEntryScore()
        {
            return _aggressiveMode
                ? Math.Max(8, _effMinEntryScore - AggressiveScoreReduction)
                : _effMinEntryScore;
        }

        private int CurrentCooldownSeconds()
        {
            return _aggressiveMode ? AggressiveCooldownSeconds : CooldownSeconds;
        }

        private double CurrentMaxSpreadAtrRatio()
        {
            return _aggressiveMode
                ? Math.Max(MaxSpreadAtrRatio, AggressiveMaxSpreadAtrRatio)
                : MaxSpreadAtrRatio;
        }

        private void UpdateTwelveHourMode()
        {
            if (!EnableTwelveHourAdaptive)
                return;

            double elapsed = (Server.Time - _profitWindowStart).TotalHours;

            if (_aggressiveMode && ProfitWindowPnl() >= TwelveHourProfitGoal)
            {
                _aggressiveMode = false;
                Print("AGGRESSIVE MODE OFF | 12hPnL={0:F2}", ProfitWindowPnl());
            }

            if (elapsed < ProfitWindowHours)
                return;

            double pnl = ProfitWindowPnl();
            Print("12H WINDOW | pnl={0:F2} | target={1:F2}", pnl, TwelveHourProfitGoal);

            _aggressiveMode = pnl <= 0;
            if (_aggressiveMode)
                Print("AGGRESSIVE MODE ON | frequenza e filtri più permissivi; rischio per trade invariato");

            _profitWindowStart = Server.Time;
            _profitWindowStartEquity = Account.Equity;
        }

        protected override void OnTimer()
        {
            ResetDailyCounterIfNewDay();
            CheckDailyLossLimit();
            UpdateTwelveHourMode();

            if (Server.Time < _nextHeartbeat)
                return;

            _nextHeartbeat = Server.Time.AddMinutes(HeartbeatMinutes);

            Print("BOT OPERATIVO | Eq={0:F2} | Day={1} | 12hPnL={2:F2} | Mode={3} | Pos={4}/{5} | Scans={6} | Candidates={7} | Orders={8} | RiskBlock={9} | SpreadBlock={10}",
                Account.Equity,
                _dailyLossLimitHit ? "STOP" : "OK",
                ProfitWindowPnl(),
                _aggressiveMode ? "AGGRESSIVE" : "NORMAL",
                Positions.FindAll(BotLabel).Length,
                _effMaxOpenPositions,
                _scanCount,
                _candidateCount,
                _orderCount,
                _riskBlockCount,
                _spreadBlockCount);
        }

        private void OnPositionClosed(PositionClosedEventArgs args)
        {
            Position position = args.Position;
            if (position.Label != BotLabel)
                return;

            Print("CLOSE {0} {1} | Net={2:F2} | Pips={3:F1} | Reason={4}",
                position.SymbolName, position.TradeType, position.NetProfit, position.Pips, args.Reason);
        }

        protected override void OnTick()
        {
            ResetDailyCounterIfNewDay();
            CheckDailyLossLimit();
        }

        protected override void OnException(Exception exception)
        {
            Print("BOT EXCEPTION | {0} | {1}", exception.GetType().Name, exception.Message);
        }

        protected override void OnStop()
        {
            Print("MultiSymbolReactiveEmaRsiAtrBot fermato");
        }
    }
}
