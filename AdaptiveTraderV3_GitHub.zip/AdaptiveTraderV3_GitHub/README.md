# AdaptiveTraderV3 — cTrader demo-first

Native cTrader cBot project intended for DEMO forward testing first. It is not a profit guarantee.

## Build from Android using GitHub Actions
1. Create a GitHub repository and upload the CONTENTS of this folder.
2. Open Actions > Build AdaptiveTraderV3 > Run workflow.
3. When green, open the run > Artifacts > AdaptiveTraderV3-algo and download it.
4. Extract the downloaded GitHub artifact ZIP. Inside is the compiled `.algo`.
5. Open the `.algo` with cTrader Mobile and install it.
6. Start it ONLY on the Pepperstone demo account first.

## Suggested €200 demo parameters
Risk %=0.50; Daily Loss %=2.0; Daily Profit Lock %=2.5; Min RR=2.0; Max Trades/Day=6.
Risk is additionally capped near 1 unit of account currency per trade in code.

## Important
Run one instance per symbol initially (EURUSD, GBPUSD, USDJPY). Do not use a real-money account until forward testing demonstrates positive expectancy after costs and acceptable drawdown.
