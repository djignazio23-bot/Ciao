# Peugeot 208 Bosch MG1CS032 Post-Distribuzione v4.1 ECU SAFE

Build focused on conservative, read-only diagnostics for the user's Peugeot 208 profile.

## ECU SAFE changes
- Fixed protocol only: ISO 15765-4 CAN 11-bit/500 kbit (`ATSP6`).
- No protocol autodetection.
- Physical OBD addressing only: `7E0 -> 7E8`; analysis does not use functional `7DF` broadcast.
- PSA engine diagnostics only on `6A8 -> 688`.
- UDS limited to `0x22 ReadDataByIdentifier`.
- No reset, write, actuation, flash, SecurityAccess or RoutineControl.
- 550 ms minimum inter-command interval; 850 ms cooldown when switching headers.
- Zero automatic retry after timeout or CAN/ELM transport error.
- Circuit breaker on transport failure, repeated negative/no-response replies, and NRC `0x78`.
- Maximum 48 commands per operation.
- PSA/VVT reads limited to low engine speed when RPM is available.
- Immediate DISCONNECT kill switch; backgrounding the app closes Bluetooth.
- Adaptation reset remains disabled.

## Important
No diagnostic software can guarantee zero risk if an ELM clone, wiring, battery, gateway or ECU is faulty. This build is designed to minimize traffic and avoid all state-changing services.
