plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}

android {
    namespace = "com.peugeot208.boschservice"
    compileSdk = 35

    defaultConfig {
        applicationId = "com.peugeot208.boschservice"
        minSdk = 29
        targetSdk = 35
        versionCode = 5
        versionName = "4.0-mg1-timing-readonly"

        testInstrumentationRunner = "android.app.InstrumentationTestRunner"
    }

    buildTypes {
        release {
            isMinifyEnabled = false
        }
    }

    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }

    kotlinOptions {
        jvmTarget = "17"
    }
}
