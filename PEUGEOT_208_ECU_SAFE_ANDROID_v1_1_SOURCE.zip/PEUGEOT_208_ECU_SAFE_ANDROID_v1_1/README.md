# Peugeot 208 ECU SAFE EXTENDED ID v1.1

App Android per Peugeot 208 II 2022 1.2 PureTech 100 con ELM327 Bluetooth Classic.

## Perché questa versione
Il report v1 ha confermato:
- ISO 15765-4 CAN 11/500 (`ATSP6`)
- risposta OBD motore valida (`4100...`)
- Calibration ID presente nei RAW: `9695724580`
- CVN presente nei RAW: `A86E9F62`
- ECU Name presente nei RAW: `ECM-EngineControl`

La v1 non li mostrava correttamente perché alcune risposte ELM erano compatte/multiframe
(`0:490401...`). Il parser v1.1 gestisce quel formato.

## SAFE EXTENDED ID
La app:
1. forza `ATSP6`;
2. esegue OBD standard in sola lettura;
3. attiva gli header solo per verificare il responder CAN;
4. prosegue con UDS soltanto se rileva `7E8`;
5. invia letture fisiche a `7E0`;
6. usa esclusivamente `0x22 ReadDataByIdentifier`;
7. salva un report condivisibile.

## DID UDS fissi
- F187
- F18A
- F18C
- F190
- F191
- F192
- F194
- F195

Non esiste scansione di range DID.

## NON IMPLEMENTATO
- ATSP0
- KWP/ISO9141 fallback
- DiagnosticSessionControl 0x10
- ECUReset 0x11
- SecurityAccess 0x27
- WriteDataByIdentifier 0x2E
- RoutineControl 0x31
- download/flash 0x34/0x36/0x37
- cancellazione DTC Mode 04
- reset autoadattativi
- codifica/telecoding

Il reset autoadattativi resta bloccato finché la ECU non viene identificata
in modo affidabile dal report v1.1.
