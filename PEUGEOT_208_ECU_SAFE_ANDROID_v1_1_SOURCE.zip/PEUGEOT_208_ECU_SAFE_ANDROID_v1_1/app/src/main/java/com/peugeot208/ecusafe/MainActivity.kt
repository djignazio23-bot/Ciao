package com.peugeot208.ecusafe

import android.Manifest
import android.app.Activity
import android.bluetooth.BluetoothAdapter
import android.bluetooth.BluetoothDevice
import android.bluetooth.BluetoothSocket
import android.content.ContentValues
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Typeface
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.Environment
import android.provider.MediaStore
import android.text.method.ScrollingMovementMethod
import android.view.Gravity
import android.view.View
import android.widget.*
import java.io.InputStream
import java.io.OutputStream
import java.nio.charset.StandardCharsets
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.util.UUID
import java.util.concurrent.Executors

class MainActivity : Activity() {

    companion object {
        private const val REQ_BT = 9001
        private val SPP_UUID: UUID =
            UUID.fromString("00001101-0000-1000-8000-00805F9B34FB")

        // Allowlist rigida: l'app rifiuta qualsiasi comando non presente qui.
        private val SAFE_COMMANDS = setOf(
            // Configurazione ELM: non sono comandi di scrittura ECU.
            "ATI", "ATE0", "ATL0", "ATS0", "ATH0", "ATH1", "ATCAF1",
            "ATSP6", "ATDPN", "ATDP", "ATRV", "ATSH7DF", "ATSH7E0",

            // OBD-II standard: sola lettura.
            "0100", "0900", "0902", "0904", "0906", "090A", "03",

            // UDS ReadDataByIdentifier (0x22): lista chiusa, sola lettura.
            "22F187", "22F18A", "22F18C", "22F190",
            "22F191", "22F192", "22F194", "22F195",

            "ATPC"
        )

        private val SAFE_UDS_DIDS = linkedMapOf(
            "22F187" to "Vehicle manufacturer spare part number",
            "22F18A" to "System supplier identifier",
            "22F18C" to "ECU serial number",
            "22F190" to "VIN (UDS)",
            "22F191" to "Vehicle manufacturer ECU hardware number",
            "22F192" to "System supplier ECU hardware number",
            "22F194" to "System supplier ECU software number",
            "22F195" to "System supplier ECU software version"
        )
    }

    private val worker = Executors.newSingleThreadExecutor()

    private var adapter: BluetoothAdapter? = null
    private var socket: BluetoothSocket? = null
    private var input: InputStream? = null
    private var output: OutputStream? = null
    private var selectedDevice: BluetoothDevice? = null

    private lateinit var deviceSpinner: Spinner
    private lateinit var refreshButton: Button
    private lateinit var connectButton: Button
    private lateinit var identifyButton: Button
    private lateinit var emergencyButton: Button
    private lateinit var shareButton: Button
    private lateinit var statusText: TextView
    private lateinit var logText: TextView
    private lateinit var progress: ProgressBar

    private val deviceList = mutableListOf<BluetoothDevice>()
    private val rawResponses = linkedMapOf<String, String>()
    private val logLines = mutableListOf<String>()

    private var reportText: String = ""
    private var reportUri: Uri? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        adapter = BluetoothAdapter.getDefaultAdapter()
        buildUi()

        if (adapter == null) {
            setStatus("Bluetooth non disponibile su questo dispositivo.", true)
            disableActions()
            return
        }

        requestBluetoothPermissionIfNeeded()
    }

    private fun buildUi() {
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(26, 24, 26, 24)
        }

        val title = TextView(this).apply {
            text = "Peugeot 208 ECU SAFE EXTENDED ID"
            textSize = 22f
            setTypeface(typeface, Typeface.BOLD)
            gravity = Gravity.CENTER
        }
        root.addView(title)

        val subtitle = TextView(this).apply {
            text = "208 II 2022 • 1.2 PureTech 100\nv1.1 • SOLO LETTURA • CAN fisso ATSP6"
            textSize = 15f
            gravity = Gravity.CENTER
            setPadding(0, 10, 0, 18)
        }
        root.addView(subtitle)

        statusText = TextView(this).apply {
            text = "Stato: pronto"
            textSize = 16f
            setPadding(12, 10, 12, 10)
        }
        root.addView(statusText)

        val safety = TextView(this).apply {
            text = "Sicurezza: nessun reset/scrittura. Nessun ATSP0 o fallback. UDS solo ReadDataByIdentifier (0x22) verso ECU motore 7E0, e solo dopo conferma responder 7E8."
            textSize = 14f
            setPadding(12, 8, 12, 16)
        }
        root.addView(safety)

        val row1 = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
        }

        deviceSpinner = Spinner(this)
        row1.addView(deviceSpinner, LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f))

        refreshButton = Button(this).apply { text = "Aggiorna" }
        row1.addView(refreshButton)
        root.addView(row1)

        val row2 = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER
        }

        connectButton = Button(this).apply { text = "Connetti ELM327" }
        identifyButton = Button(this).apply {
            text = "SAFE EXTENDED ID"
            isEnabled = false
        }
        row2.addView(connectButton, LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f))
        row2.addView(identifyButton, LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f))
        root.addView(row2)

        val row3 = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER
        }

        emergencyButton = Button(this).apply {
            text = "DISCONNETTI"
            isEnabled = false
        }
        shareButton = Button(this).apply {
            text = "Condividi report"
            isEnabled = false
        }
        row3.addView(emergencyButton, LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f))
        row3.addView(shareButton, LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f))
        root.addView(row3)

        progress = ProgressBar(this).apply {
            isIndeterminate = false
            max = 100
            progress = 0
            visibility = View.GONE
        }
        root.addView(progress)

        logText = TextView(this).apply {
            textSize = 13f
            typeface = Typeface.MONOSPACE
            setPadding(10, 12, 10, 12)
            movementMethod = ScrollingMovementMethod()
            text = "Istruzioni:\n1) Associa l'ELM327 dalle impostazioni Bluetooth.\n2) Collega l'ELM alla presa OBD.\n3) Quadro acceso, motore spento.\n4) Connetti e premi SAFE EXTENDED ID.\n5) Condividi il report finale.\n"
        }

        val scroll = ScrollView(this)
        scroll.addView(logText)
        root.addView(scroll, LinearLayout.LayoutParams(
            LinearLayout.LayoutParams.MATCH_PARENT, 0, 1f
        ))

        setContentView(root)

        refreshButton.setOnClickListener { loadBondedDevices() }
        connectButton.setOnClickListener { connectSelectedDevice() }
        identifyButton.setOnClickListener { runSafeIdentify() }
        emergencyButton.setOnClickListener { disconnectSafe("Disconnessione richiesta dall'utente.") }
        shareButton.setOnClickListener { shareReport() }

        deviceSpinner.onItemSelectedListener = object : android.widget.AdapterView.OnItemSelectedListener {
            override fun onItemSelected(parent: android.widget.AdapterView<*>?, view: View?, position: Int, id: Long) {
                selectedDevice = deviceList.getOrNull(position)
            }
            override fun onNothingSelected(parent: android.widget.AdapterView<*>?) {
                selectedDevice = null
            }
        }
    }

    private fun requestBluetoothPermissionIfNeeded() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S &&
            checkSelfPermission(Manifest.permission.BLUETOOTH_CONNECT) != PackageManager.PERMISSION_GRANTED
        ) {
            requestPermissions(arrayOf(Manifest.permission.BLUETOOTH_CONNECT), REQ_BT)
        } else {
            loadBondedDevices()
        }
    }

    override fun onRequestPermissionsResult(
        requestCode: Int,
        permissions: Array<out String>,
        grantResults: IntArray
    ) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        if (requestCode == REQ_BT) {
            if (grantResults.isNotEmpty() && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                loadBondedDevices()
            } else {
                setStatus("Permesso Bluetooth negato.", true)
                disableActions()
            }
        }
    }

    private fun hasBtPermission(): Boolean {
        return Build.VERSION.SDK_INT < Build.VERSION_CODES.S ||
            checkSelfPermission(Manifest.permission.BLUETOOTH_CONNECT) == PackageManager.PERMISSION_GRANTED
    }

    private fun loadBondedDevices() {
        if (!hasBtPermission()) {
            requestBluetoothPermissionIfNeeded()
            return
        }

        try {
            val bonded = adapter?.bondedDevices?.toList()
                ?.sortedBy { safeDeviceName(it) }
                ?: emptyList()

            deviceList.clear()
            deviceList.addAll(bonded)

            val names = bonded.map {
                "${safeDeviceName(it)}  •  ${it.address}"
            }

            deviceSpinner.adapter = ArrayAdapter(
                this,
                android.R.layout.simple_spinner_dropdown_item,
                if (names.isEmpty()) listOf("Nessun dispositivo associato") else names
            )

            selectedDevice = bonded.firstOrNull()

            if (bonded.isEmpty()) {
                setStatus("Associa prima l'ELM327 nelle impostazioni Bluetooth.", true)
            } else {
                setStatus("Seleziona il tuo ELM327 e premi Connetti.", false)
            }
        } catch (e: SecurityException) {
            setStatus("Permesso Bluetooth mancante.", true)
        }
    }

    private fun safeDeviceName(d: BluetoothDevice): String {
        return try {
            d.name ?: "Bluetooth device"
        } catch (_: SecurityException) {
            "Bluetooth device"
        }
    }

    private fun connectSelectedDevice() {
        val device = selectedDevice ?: run {
            setStatus("Nessun ELM327 selezionato.", true)
            return
        }

        if (!hasBtPermission()) {
            requestBluetoothPermissionIfNeeded()
            return
        }

        setBusy(true)
        setStatus("Connessione a ${safeDeviceName(device)}…", false)
        appendLog("Connessione Bluetooth SPP…")

        worker.execute {
            try {
                closeSocketOnly()

                var s: BluetoothSocket? = null
                try {
                    s = device.createRfcommSocketToServiceRecord(SPP_UUID)
                    s.connect()
                } catch (e: Exception) {
                    try { s?.close() } catch (_: Exception) {}
                    s = device.createInsecureRfcommSocketToServiceRecord(SPP_UUID)
                    s.connect()
                }

                socket = s
                input = s.inputStream
                output = s.outputStream

                val ati = sendSafeCommand("ATI", 2500)
                if (!looksLikeElm(ati)) {
                    throw IllegalStateException("Il dispositivo risponde, ma non sembra un ELM/STN OBD.")
                }

                runOnUiThread {
                    emergencyButton.isEnabled = true
                    identifyButton.isEnabled = true
                    setStatus("ELM327 collegato. Pronto per SAFE EXTENDED ID.", false)
                    appendLog("ELM: ${oneLine(ati)}")
                    setBusy(false)
                }
            } catch (e: Exception) {
                closeSocketOnly()
                runOnUiThread {
                    setBusy(false)
                    setStatus("Connessione fallita: ${e.message}", true)
                    appendLog("ERRORE connessione: ${e.message}")
                }
            }
        }
    }

    private fun runSafeIdentify() {
        if (socket?.isConnected != true) {
            setStatus("ELM327 non collegato.", true)
            return
        }

        rawResponses.clear()
        logLines.clear()
        reportText = ""
        reportUri = null
        shareButton.isEnabled = false

        identifyButton.isEnabled = false
        connectButton.isEnabled = false
        refreshButton.isEnabled = false
        progress.visibility = View.VISIBLE
        progress.progress = 0

        appendLog("=== SAFE EXTENDED ID v1.1 ===")
        appendLog("SOLO LETTURA. Protocollo fisso ATSP6.")
        appendLog("UDS limitato a 0x22 ReadDataByIdentifier.")

        worker.execute {
            try {
                val result = linkedMapOf<String, String>()

                fun doRequired(cmd: String, pct: Int, timeout: Long = 3500L): String {
                    runOnUiThread {
                        progress.progress = pct
                        setStatus("SAFE ID: $cmd", false)
                    }
                    val r = sendSafeCommand(cmd, timeout)
                    result[cmd] = r
                    rawResponses[cmd] = r
                    runOnUiThread { appendLog("$cmd → ${shortReply(r)}") }
                    return r
                }

                // ---------------- ELM + CAN fisso ----------------
                doRequired("ATE0", 4)
                doRequired("ATL0", 7)
                doRequired("ATS0", 10)
                doRequired("ATH0", 13)
                doRequired("ATCAF1", 16)

                val sp6 = doRequired("ATSP6", 20)
                if (!sp6.contains("OK", ignoreCase = true)) {
                    throw SafeStop("L'ELM non ha accettato ATSP6. Nessun fallback.")
                }

                val dpn = doRequired("ATDPN", 23)
                    .replace("\\s".toRegex(), "")
                    .replace(">", "")
                if (!Regex("(?i)^A?6$").containsMatchIn(dpn)) {
                    throw SafeStop("ATDPN non conferma protocollo 6: $dpn")
                }

                doRequired("ATDP", 26)
                doRequired("ATRV", 29)

                // ---------------- OBD standard ----------------
                val r0100 = doRequired("0100", 34, 5000L)
                val compact0100 = r0100.replace("[^0-9A-Fa-f]".toRegex(), "").uppercase()
                if (!compact0100.contains("4100") || containsBadObdReply(r0100)) {
                    throw SafeStop("0100 non ha ricevuto una risposta OBD valida. Stop senza altri protocolli.")
                }

                doRequired("0900", 38, 5000L)
                doRequired("0902", 42, 6000L)
                doRequired("0904", 46, 6000L)
                doRequired("0906", 50, 6000L)
                doRequired("090A", 54, 6000L)
                doRequired("03", 58, 5000L)

                // Parser corretto per risposte ELM compatte/multiframe.
                val vin = parseMode09Ascii(result["0902"].orEmpty(), 0x02)
                val calId = parseMode09Ascii(result["0904"].orEmpty(), 0x04)
                val cvn = parseMode09Hex(result["0906"].orEmpty(), 0x06)
                val ecuName = parseMode09Ascii(result["090A"].orEmpty(), 0x0A)
                val dtcs = parseMode03Dtcs(result["03"].orEmpty())

                // ---------------- Conferma responder ECU motore ----------------
                doRequired("ATH1", 61)
                doRequired("ATSH7DF", 63)

                val headerProbe = doRequired("0100", 66, 5000L)
                result["0100_WITH_HEADERS"] = headerProbe

                val responders = parseObdResponderIds(headerProbe)
                val engineConfirmed = responders.contains("7E8")

                runOnUiThread {
                    appendLog("Responder CAN: ${if (responders.isEmpty()) "non rilevato" else responders.joinToString(", ")}")
                }

                val udsDecoded = linkedMapOf<String, String>()
                var udsStatus: String

                if (!engineConfirmed) {
                    udsStatus = "SALTATO: responder ECU motore 7E8 non confermato"
                    runOnUiThread {
                        appendLog("UDS saltato: 7E8 non confermato. Nessun indirizzo viene indovinato.")
                    }
                } else {
                    // Header display OFF; richiesta fisica solo verso ECU motore standard 7E0.
                    doRequired("ATH0", 68)
                    doRequired("ATSH7E0", 70)

                    var pct = 72
                    for ((cmd, description) in SAFE_UDS_DIDS) {
                        runOnUiThread {
                            progress.progress = pct
                            setStatus("UDS READ: ${cmd.removePrefix("22")}", false)
                        }

                        val reply = sendOptionalSafeRead(cmd, 5500L)
                        result[cmd] = reply
                        rawResponses[cmd] = reply

                        val did = cmd.removePrefix("22")
                        val decoded = decodeUdsDid(reply, did)
                        udsDecoded[did] = decoded

                        runOnUiThread {
                            appendLog("$cmd [$description] → ${shortReply(reply)}")
                            if (decoded.isNotBlank()) appendLog("  ↳ $decoded")
                        }
                        pct = minOf(96, pct + 3)
                    }

                    udsStatus = "ESEGUITO: 7E8 confermato, richieste 0x22 inviate a 7E0"
                }

                // Ripristina header funzionale dell'adattatore prima della chiusura.
                try { sendSafeCommand("ATSH7DF", 1500L) } catch (_: Exception) {}
                try { sendSafeCommand("ATH0", 1500L) } catch (_: Exception) {}

                val classificationText = buildString {
                    append(ecuName).append(' ')
                    append(calId).append(' ')
                    for ((_, v) in udsDecoded) append(v).append(' ')
                    for ((_, v) in result) append(v).append(' ')
                }
                val family = classifyEcu(classificationText)

                reportText = buildExtendedReport(
                    result = result,
                    vin = vin,
                    calId = calId,
                    cvn = cvn,
                    ecuName = ecuName,
                    family = family,
                    dtcs = dtcs,
                    responders = responders,
                    udsStatus = udsStatus,
                    udsDecoded = udsDecoded
                )

                reportUri = saveReportToDownloads(reportText)

                try { sendSafeCommand("ATPC", 1500L) } catch (_: Exception) {}

                runOnUiThread {
                    progress.progress = 100
                    setStatus("SAFE EXTENDED ID completata.", false)
                    appendLog("")
                    appendLog("VIN OBD: ${vin.ifBlank { "non disponibile" }}")
                    appendLog("Calibration ID: ${calId.ifBlank { "non disponibile" }}")
                    appendLog("CVN: ${cvn.ifBlank { "non disponibile" }}")
                    appendLog("ECU Name: ${ecuName.ifBlank { "non disponibile" }}")
                    appendLog("Famiglia candidata: $family")
                    appendLog("UDS: $udsStatus")
                    appendLog("")
                    appendLog("Report salvato in Download/PeugeotECUSafe.")
                    appendLog("RESET AUTODATTIVI: ancora BLOCCATO.")

                    shareButton.isEnabled = reportUri != null
                    identifyButton.isEnabled = true
                    connectButton.isEnabled = true
                    refreshButton.isEnabled = true
                    progress.visibility = View.GONE
                }

            } catch (e: SafeStop) {
                safeProtocolStop(e.message ?: "Stop sicuro.")
            } catch (e: Exception) {
                safeProtocolStop("Errore: ${e.message}")
            }
        }
    }

    private fun safeProtocolStop(message: String) {
        try {
            sendSafeCommand("ATPC", 1200)
        } catch (_: Exception) {}
        closeSocketOnly()

        runOnUiThread {
            progress.visibility = View.GONE
            setStatus("STOP SICURO: $message", true)
            appendLog("STOP SICURO: $message")
            appendLog("ELM disconnesso. Nessun fallback di protocollo eseguito.")
            appendLog("Se l'auto si comporta in modo anomalo: scollega fisicamente l'ELM, spegni il quadro e lascia l'auto a riposo alcuni minuti.")
            identifyButton.isEnabled = false
            emergencyButton.isEnabled = false
            connectButton.isEnabled = true
            refreshButton.isEnabled = true
        }
    }

    @Synchronized
    private fun sendSafeCommand(command: String, timeoutMs: Long): String {
        val cmd = command.trim().uppercase(Locale.ROOT)

        if (!SAFE_COMMANDS.contains(cmd)) {
            throw SecurityException("Comando '$cmd' rifiutato dalla allowlist SAFE.")
        }

        val out = output ?: throw IllegalStateException("Output Bluetooth non disponibile.")
        val inp = input ?: throw IllegalStateException("Input Bluetooth non disponibile.")

        while (inp.available() > 0) {
            inp.read()
        }

        out.write("$cmd\r".toByteArray(StandardCharsets.US_ASCII))
        out.flush()

        val start = System.currentTimeMillis()
        val buffer = ByteArray(512)
        val text = StringBuilder()

        while (System.currentTimeMillis() - start < timeoutMs) {
            val available = inp.available()
            if (available > 0) {
                val n = inp.read(buffer, 0, minOf(buffer.size, available))
                if (n > 0) {
                    text.append(String(buffer, 0, n, StandardCharsets.US_ASCII))
                    if (text.contains(">")) break
                }
            } else {
                Thread.sleep(40)
            }
        }

        val reply = text.toString().replace(">", "").trim()
        if (reply.isBlank()) {
            throw SafeStop("Timeout sul comando $cmd.")
        }
        return reply
    }

    private fun sendOptionalSafeRead(command: String, timeoutMs: Long): String {
        return try {
            sendSafeCommand(command, timeoutMs)
        } catch (_: SafeStop) {
            "NO RESPONSE"
        }
    }

    private fun looksLikeElm(reply: String): Boolean {
        val u = reply.uppercase()
        return u.contains("ELM") || u.contains("STN") || u.contains("OBD") || Regex("V\\d+\\.\\d+").containsMatchIn(u)
    }

    private fun containsBadObdReply(reply: String): Boolean {
        val u = reply.uppercase()
        return listOf(
            "NO DATA", "UNABLE TO CONNECT", "BUS ERROR",
            "CAN ERROR", "STOPPED", "BUS INIT"
        ).any { u.contains(it) }
    }

    private fun lineHexBytes(line: String): List<Int> {
        val trimmed = line.trim()
        if (trimmed.isBlank()) return emptyList()

        // Rimuove l'indice ELM multiframe "0:", "1:", ...
        val body = if (trimmed.matches(Regex("(?i)^[0-9A-F]:.*$"))) {
            trimmed.substringAfter(':')
        } else {
            trimmed
        }

        // Accetta sia "49 04 01 ..." sia "490401..."
        val compact = body.replace(Regex("(?i)[^0-9A-F]"), "")
        if (compact.length < 2 || compact.length % 2 != 0) return emptyList()

        return compact.chunked(2).mapNotNull {
            it.toIntOrNull(16)
        }
    }

    private fun indexedElmFrames(raw: String): Map<Int, List<Int>> {
        val frames = linkedMapOf<Int, List<Int>>()
        for (line in raw.split(Regex("[\\r\\n]+"))) {
            val m = Regex("(?i)^\\s*([0-9A-F]):").find(line) ?: continue
            val index = m.groupValues[1].toInt(16)
            val bytes = lineHexBytes(line)
            if (bytes.isNotEmpty()) frames[index] = bytes
        }
        return frames.toSortedMap()
    }

    private fun parseMode09Ascii(raw: String, pid: Int): String {
        return parseMode09Payload(raw, pid)
            .filter { it in 32..126 }
            .map { it.toChar() }
            .joinToString("")
            .trim()
            .replace("\u0000", "")
    }

    private fun parseMode09Hex(raw: String, pid: Int): String {
        return parseMode09Payload(raw, pid)
            .joinToString("") { "%02X".format(it) }
    }

    private fun parseMode09Payload(raw: String, pid: Int): List<Int> {
        val indexed = indexedElmFrames(raw)

        if (indexed.isNotEmpty()) {
            val firstEntry = indexed.entries.firstOrNull { (_, bytes) ->
                bytes.size >= 3 && bytes[0] == 0x49 && bytes[1] == pid
            }

            if (firstEntry != null) {
                val out = mutableListOf<Int>()
                out += firstEntry.value.drop(3)
                for ((idx, bytes) in indexed) {
                    if (idx > firstEntry.key) out += bytes
                }
                return out
            }
        }

        // Risposta singola, ad es. 490601A86E9F62
        for (line in raw.split(Regex("[\\r\\n]+"))) {
            val bytes = lineHexBytes(line)
            for (i in 0..maxOf(-1, bytes.size - 3)) {
                if (i >= 0 && bytes[i] == 0x49 && bytes[i + 1] == pid) {
                    return bytes.drop(i + 3)
                }
            }
        }

        return emptyList()
    }

    private fun parseMode03Dtcs(raw: String): List<String> {
        val all = raw.split(Regex("[\\r\\n]+")).flatMap { lineHexBytes(it) }
        val idx = all.indexOf(0x43)
        if (idx < 0) return emptyList()

        val result = mutableListOf<String>()
        var i = idx + 1

        while (i + 1 < all.size) {
            val a = all[i]
            val b = all[i + 1]
            i += 2

            if (a == 0 && b == 0) continue

            val prefix = listOf("P", "C", "B", "U")[(a shr 6) and 0x03]
            val d2 = (a shr 4) and 0x03
            val d3 = a and 0x0F
            val d4 = (b shr 4) and 0x0F
            val d5 = b and 0x0F
            result += "$prefix${d2.toString(16).uppercase()}${d3.toString(16).uppercase()}${d4.toString(16).uppercase()}${d5.toString(16).uppercase()}"
        }

        return result.distinct()
    }

    private fun parseObdResponderIds(raw: String): Set<String> {
        val ids = linkedSetOf<String>()

        for (line in raw.split(Regex("[\\r\\n]+"))) {
            val t = line.trim().uppercase()
            val spaced = Regex("^([0-9A-F]{3})\\s+").find(t)
            val compact = Regex("^([0-9A-F]{3})([0-9A-F]{4,})$").find(t)

            val id = when {
                spaced != null -> spaced.groupValues[1]
                compact != null -> compact.groupValues[1]
                else -> null
            } ?: continue

            val noSpace = t.replace(Regex("[^0-9A-F]"), "")
            if (id.matches(Regex("7E[8-F]")) && noSpace.contains("4100")) {
                ids += id
            }
        }

        return ids
    }

    private fun parseUdsDidPayload(raw: String, didHex: String): List<Int> {
        if (!didHex.matches(Regex("(?i)^[0-9A-F]{4}$"))) return emptyList()

        val hi = didHex.substring(0, 2).toInt(16)
        val lo = didHex.substring(2, 4).toInt(16)
        val indexed = indexedElmFrames(raw)

        if (indexed.isNotEmpty()) {
            val firstEntry = indexed.entries.firstOrNull { (_, bytes) ->
                bytes.size >= 3 &&
                    bytes[0] == 0x62 &&
                    bytes[1] == hi &&
                    bytes[2] == lo
            }

            if (firstEntry != null) {
                val out = mutableListOf<Int>()
                out += firstEntry.value.drop(3)
                for ((idx, bytes) in indexed) {
                    if (idx > firstEntry.key) out += bytes
                }
                return out
            }
        }

        for (line in raw.split(Regex("[\\r\\n]+"))) {
            val bytes = lineHexBytes(line)
            if (bytes.size < 3) continue
            for (i in 0..bytes.size - 3) {
                if (bytes[i] == 0x62 && bytes[i + 1] == hi && bytes[i + 2] == lo) {
                    return bytes.drop(i + 3)
                }
            }
        }

        return emptyList()
    }

    private fun decodeUdsDid(raw: String, didHex: String): String {
        val upper = raw.uppercase()
        if (upper.contains("NO DATA") || upper.contains("NO RESPONSE")) {
            return "non supportato / nessuna risposta"
        }

        val compact = upper.replace(Regex("[^0-9A-F]"), "")
        if (compact.contains("7F22")) {
            val nrc = compact.substringAfter("7F22").take(2)
            return "risposta negativa UDS NRC=$nrc (nessun accesso aggiuntivo tentato)"
        }

        val payload = parseUdsDidPayload(raw, didHex)
        if (payload.isEmpty()) return "risposta non decodificata"

        val meaningful = payload.dropLastWhile { it == 0x00 || it == 0xFF }
        val hex = meaningful.joinToString("") { "%02X".format(it) }
        val ascii = meaningful
            .filter { it in 32..126 }
            .map { it.toChar() }
            .joinToString("")
            .trim()

        return when {
            ascii.isNotBlank() -> "ASCII=\"$ascii\" HEX=$hex"
            hex.isNotBlank() -> "HEX=$hex"
            else -> "payload vuoto"
        }
    }

    private fun classifyEcu(text: String): String {
        val u = text.uppercase()
        return when {
            u.contains("MG1CS032") -> "Bosch MG1CS032 (candidato)"
            u.contains("MG1") -> "Bosch MG1 family (candidato)"
            u.contains("VD56") -> "Valeo VD56 (candidato)"
            u.contains("VD46") -> "Valeo VD46 family (candidato)"
            else -> "NON IDENTIFICATA CON CERTEZZA"
        }
    }

    private fun buildExtendedReport(
        result: Map<String, String>,
        vin: String,
        calId: String,
        cvn: String,
        ecuName: String,
        family: String,
        dtcs: List<String>,
        responders: Set<String>,
        udsStatus: String,
        udsDecoded: Map<String, String>
    ): String {
        val sdf = SimpleDateFormat("yyyy-MM-dd HH:mm:ss", Locale.ITALY)
        return buildString {
            appendLine("PEUGEOT 208 II 2022 1.2 PURETECH 100")
            appendLine("ECU SAFE EXTENDED IDENTIFY ANDROID v1.1")
            appendLine("==============================================")
            appendLine("Data: ${sdf.format(Date())}")
            appendLine("Modalita: SOLO LETTURA")
            appendLine("Protocollo: ISO 15765-4 CAN 11/500 (ATSP6)")
            appendLine("Fallback protocollo: DISABILITATO")
            appendLine("Sessione UDS estesa: NON USATA")
            appendLine("SecurityAccess: NON USATO")
            appendLine("Servizio UDS consentito: solo 0x22 ReadDataByIdentifier")
            appendLine()
            appendLine("OBD STANDARD")
            appendLine("------------")
            appendLine("VIN: ${vin.ifBlank { "non disponibile" }}")
            appendLine("Calibration ID: ${calId.ifBlank { "non disponibile" }}")
            appendLine("CVN: ${cvn.ifBlank { "non disponibile" }}")
            appendLine("ECU Name: ${ecuName.ifBlank { "non disponibile" }}")
            appendLine("DTC Mode 03: ${if (dtcs.isEmpty()) "nessuno/nessuno decodificato" else dtcs.joinToString(", ")}")
            appendLine()
            appendLine("CAN / UDS")
            appendLine("---------")
            appendLine("Responder OBD rilevati: ${if (responders.isEmpty()) "nessuno" else responders.joinToString(", ")}")
            appendLine("Stato UDS: $udsStatus")
            appendLine()
            for ((did, decoded) in udsDecoded) {
                val cmd = "22$did"
                val label = SAFE_UDS_DIDS[cmd] ?: "DID"
                appendLine("$did - $label")
                appendLine("  $decoded")
            }
            appendLine()
            appendLine("ECU candidate: $family")
            appendLine()
            appendLine("RESET AUTODATTIVI: BLOCCATO")
            appendLine("Nessuna scrittura, codifica, reset o SecurityAccess eseguiti.")
            appendLine()
            appendLine("RAW RESPONSES")
            appendLine("-------------")
            for ((cmd, reply) in result) {
                appendLine()
                appendLine("[$cmd]")
                appendLine(reply)
            }
        }
    }

    private fun saveReportToDownloads(text: String): Uri? {
        return try {
            val stamp = SimpleDateFormat("yyyyMMdd_HHmmss", Locale.US).format(Date())
            val name = "PEUGEOT_ECU_SAFE_EXTENDED_REPORT_$stamp.txt"

            val values = ContentValues().apply {
                put(MediaStore.Downloads.DISPLAY_NAME, name)
                put(MediaStore.Downloads.MIME_TYPE, "text/plain")
                put(MediaStore.Downloads.RELATIVE_PATH, Environment.DIRECTORY_DOWNLOADS + "/PeugeotECUSafe")
                put(MediaStore.Downloads.IS_PENDING, 1)
            }

            val uri = contentResolver.insert(MediaStore.Downloads.EXTERNAL_CONTENT_URI, values)
                ?: return null

            contentResolver.openOutputStream(uri)?.use {
                it.write(text.toByteArray(StandardCharsets.UTF_8))
            }

            values.clear()
            values.put(MediaStore.Downloads.IS_PENDING, 0)
            contentResolver.update(uri, values, null, null)
            uri
        } catch (e: Exception) {
            runOnUiThread {
                appendLog("Impossibile salvare report: ${e.message}")
            }
            null
        }
    }

    private fun shareReport() {
        val uri = reportUri
        if (uri == null) {
            setStatus("Nessun report disponibile.", true)
            return
        }

        val intent = Intent(Intent.ACTION_SEND).apply {
            type = "text/plain"
            putExtra(Intent.EXTRA_STREAM, uri)
            putExtra(Intent.EXTRA_TEXT, reportText)
            addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
        }
        startActivity(Intent.createChooser(intent, "Condividi report ECU SAFE v1.1"))
    }

    private fun disconnectSafe(reason: String) {
        worker.execute {
            try {
                if (socket?.isConnected == true) {
                    try { sendSafeCommand("ATPC", 1200) } catch (_: Exception) {}
                }
            } finally {
                closeSocketOnly()
                runOnUiThread {
                    identifyButton.isEnabled = false
                    emergencyButton.isEnabled = false
                    connectButton.isEnabled = true
                    refreshButton.isEnabled = true
                    progress.visibility = View.GONE
                    setStatus("Disconnesso.", false)
                    appendLog(reason)
                }
            }
        }
    }

    private fun closeSocketOnly() {
        try { input?.close() } catch (_: Exception) {}
        try { output?.close() } catch (_: Exception) {}
        try { socket?.close() } catch (_: Exception) {}
        input = null
        output = null
        socket = null
    }

    override fun onDestroy() {
        closeSocketOnly()
        worker.shutdownNow()
        super.onDestroy()
    }

    private fun setBusy(busy: Boolean) {
        refreshButton.isEnabled = !busy
        connectButton.isEnabled = !busy
        deviceSpinner.isEnabled = !busy
        if (busy) {
            progress.visibility = View.VISIBLE
            progress.isIndeterminate = true
        } else {
            progress.visibility = View.GONE
            progress.isIndeterminate = false
        }
    }

    private fun setStatus(message: String, error: Boolean) {
        statusText.text = "Stato: $message"
        statusText.setTextColor(if (error) 0xFFB00020.toInt() else 0xFF1B5E20.toInt())
    }

    private fun appendLog(message: String) {
        val stamp = SimpleDateFormat("HH:mm:ss", Locale.US).format(Date())
        logLines += "$stamp  $message"

        val rendered = logLines.takeLast(250).joinToString("\n")
        logText.text = rendered
        logText.post {
            val layout = logText.layout
            if (layout != null) {
                val scroll = layout.getLineTop(logText.lineCount) - logText.height
                if (scroll > 0) logText.scrollTo(0, scroll)
            }
        }
    }

    private fun shortReply(reply: String): String {
        val one = oneLine(reply)
        return if (one.length > 90) one.take(87) + "..." else one
    }

    private fun oneLine(reply: String): String {
        return reply.replace(Regex("[\\r\\n]+"), " ").trim()
    }

    private fun disableActions() {
        refreshButton.isEnabled = false
        connectButton.isEnabled = false
        identifyButton.isEnabled = false
        emergencyButton.isEnabled = false
    }

    private class SafeStop(message: String) : Exception(message)
}
