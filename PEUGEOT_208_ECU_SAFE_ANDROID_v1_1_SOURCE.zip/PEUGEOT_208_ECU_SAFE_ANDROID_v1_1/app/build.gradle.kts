plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}

android {
    namespace = "com.peugeot208.ecusafe"
    compileSdk = 35

    defaultConfig {
        applicationId = "com.peugeot208.ecusafe"
        minSdk = 29
        targetSdk = 35
        versionCode = 2
        versionName = "1.1-safe-extended"

        testInstrumentationRunner = "android.app.InstrumentationTestRunner"
    }

    buildTypes {
        release {
            isMinifyEnabled = false
        }
    }

    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }

    kotlinOptions {
        jvmTarget = "17"
    }
}
