# 208 OBD PRO v2.9

Peugeot 208 II 1.2 PureTech 100 diagnostic companion for Bluetooth Classic ELM327.

## v2.9 Deep Engine Diagnostics
- ECU Auto Profile + read-only UDS Extended Identification.
- Structured SAE J1979 Mode $06 misfire scan for the 3-cylinder EB2 engine:
  - OBDMID A2 = cylinder 1
  - OBDMID A3 = cylinder 2
  - OBDMID A4 = cylinder 3
  - TID 0C = current/last driving-cycle misfire counts
  - TID 0B = EWMA misfire counts over the last 10 driving cycles
- Standard wideband equivalence-ratio (actual lambda) lookup when the ECU advertises a compatible PID.
- Confirmed, pending and permanent OBD-II DTC separation in the emissions/readiness report.
- Existing live data, CSV AI Diagnostic Mode, turbo/fuel/temperature/charging tests and Safe ECU Restart retained.

## Safety
Default use is read-only. Extended ECU identification uses UDS service 0x22 only. Mode $06 and Mode $01 diagnostics are read-only. Proprietary PSA writes, coding, flashing, immobilizer and safety-module programming remain blocked.
