package com.peugeot.obdtool;

import android.content.Context;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;

public class CsvLogger {
    private File file;

    public File start(Context c, String prefix) throws IOException {
        File dir = new File(c.getExternalFilesDir(null), "logs");
        if (!dir.exists() && !dir.mkdirs()) throw new IOException("Impossibile creare cartella log");
        String ts = new SimpleDateFormat("yyyyMMdd_HHmmss", Locale.ROOT).format(new Date());
        file = new File(dir, prefix + "_" + ts + ".csv");
        try (FileWriter w = new FileWriter(file)) {
            w.write("timestamp_ms,rpm,speed_kmh,coolant_c,map_kpa,baro_kpa,boost_kpa,throttle_pct,engine_load_pct,stft_pct,ltft_pct,timing_deg,iat_c,maf_gps,fuel_pressure_kpa,rail_pressure_kpa,commanded_lambda,voltage_v\n");
        }
        return file;
    }

    public synchronized void append(long ts, double rpm, int speed, int coolant, int map, int baro,
                                    double boost, double throttle, double load, double stft, double ltft,
                                    double timing, int iat, double maf, double fuelPressure, double railPressure,
                                    double lambda, double voltage) throws IOException {
        if (file == null) return;
        try (FileWriter w = new FileWriter(file, true)) {
            w.write(String.format(Locale.US,
                    "%d,%.1f,%d,%d,%d,%d,%.2f,%.2f,%.2f,%.2f,%.2f,%.2f,%d,%.3f,%.1f,%.1f,%.4f,%.2f\n",
                    ts, rpm, speed, coolant, map, baro, boost, throttle, load, stft, ltft,
                    timing, iat, maf, fuelPressure, railPressure, lambda, voltage));
        }
    }

    public File getFile() { return file; }
}
