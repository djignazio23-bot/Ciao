package com.peugeot.obdtool;

import android.Manifest;
import android.app.AlertDialog;
import android.bluetooth.BluetoothAdapter;
import android.bluetooth.BluetoothDevice;
import android.bluetooth.BluetoothManager;
import android.content.pm.PackageManager;
import android.content.Context;
import android.content.Intent;
import androidx.core.content.FileProvider;
import android.provider.Settings;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;

import com.peugeot.obdtool.databinding.ActivityMainBinding;

import java.io.File;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;
import java.util.Set;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

public class MainActivity extends AppCompatActivity {
    private static final int REQ_BT=50;
    private ActivityMainBinding b;
    private BluetoothAdapter bt;
    private final List<BluetoothDevice> devices=new ArrayList<>();
    private final Elm327Client elm=new Elm327Client();
    private final ExecutorService io=Executors.newSingleThreadExecutor();
    private final Handler handler=new Handler(Looper.getMainLooper());
    private final CsvLogger logger=new CsvLogger();
    private volatile boolean live=false, logging=false;
    private volatile EcuProfile currentProfile=null;
    private volatile EcuExtendedIdentity currentExtendedIdentity=null;
    private final Runnable liveTask=new Runnable(){@Override public void run(){if(!live)return; pollLive(); handler.postDelayed(this,900);}};

    @Override protected void onCreate(Bundle saved){
        super.onCreate(saved);
        try {
            b=ActivityMainBinding.inflate(getLayoutInflater());
            setContentView(b.getRoot());
            bind();
            showPage(b.pageDashboard);
            initBluetooth();
            requestBtAndLoad();
        } catch (Throwable t) {
            showStartupError(t);
        }
    }

    private void initBluetooth(){
        try {
            BluetoothManager bm=(BluetoothManager)getSystemService(Context.BLUETOOTH_SERVICE);
            bt=bm==null?null:bm.getAdapter();
        } catch (Throwable t) {
            bt=null;
            if(b!=null) setStatus("Bluetooth non inizializzato",false);
        }
    }

    private void showStartupError(Throwable t){
        try {
            android.widget.TextView tv=new android.widget.TextView(this);
            tv.setPadding(40,40,40,40);
            tv.setTextSize(16f);
            tv.setText("208 OBD PRO\n\nErrore di avvio intercettato:\n"+t.getClass().getSimpleName()+"\n"+(t.getMessage()==null?"Nessun dettaglio":t.getMessage())+"\n\nRiavvia l'app dopo aver concesso i permessi Bluetooth.");
            setContentView(tv);
        } catch (Throwable ignored) {}
    }

    private void bind(){
        b.tabDashboard.setOnClickListener(v->showPage(b.pageDashboard)); b.tabDiagnostics.setOnClickListener(v->showPage(b.pageDiagnostics)); b.tabAdvanced.setOnClickListener(v->showPage(b.pageAdvanced)); b.tabLogs.setOnClickListener(v->showPage(b.pageLogs));
        b.connectButton.setOnClickListener(v->connectSelected());
        b.liveToggleButton.setOnClickListener(v->toggleLive());
        b.coldStartButton.setOnClickListener(v->toggleLogging());
        b.shareSessionButton.setOnClickListener(v->shareLastSession());
        b.vehicleInfoButton.setOnClickListener(v->readVehicleInfo());
        b.shareEcuIdentityButton.setOnClickListener(v->shareEcuIdentity());
        b.readDtcButton.setOnClickListener(v->readDtcs()); b.clearDtcButton.setOnClickListener(v->confirmClear()); b.mode06Button.setOnClickListener(v->readMode06());
        b.fullTestButton.setOnClickListener(v->runTestCenter("FULL"));
        b.serviceTestButton.setOnClickListener(v->runTestCenter("SERVICE"));
        b.coldStartTestButton.setOnClickListener(v->runTestCenter("COLD"));
        b.idleTestButton.setOnClickListener(v->runTestCenter("IDLE"));
        b.ignitionTestButton.setOnClickListener(v->runTestCenter("IGNITION"));
        b.fuelTestButton.setOnClickListener(v->runTestCenter("FUEL"));
        b.turboTestButton.setOnClickListener(v->runTestCenter("TURBO"));
        b.coolingTestButton.setOnClickListener(v->runTestCenter("COOLING"));
        b.chargingTestButton.setOnClickListener(v->runTestCenter("CHARGING"));
        b.emissionsTestButton.setOnClickListener(v->runTestCenter("EMISSIONS"));
        b.sensorsTestButton.setOnClickListener(v->runTestCenter("SENSORS"));
        b.readinessTestButton.setOnClickListener(v->runTestCenter("READINESS"));
        b.shareTestReportButton.setOnClickListener(v->shareTestReport());
        b.precheckButton.setOnClickListener(v->runPrecheck(false)); b.resetButton.setOnClickListener(v->confirmReset());
        b.sendButton.setOnClickListener(v->sendConsole()); b.clearLogButton.setOnClickListener(v->b.logText.setText(""));
    }

    private void showPage(View page){b.pageDashboard.setVisibility(View.GONE);b.pageDiagnostics.setVisibility(View.GONE);b.pageAdvanced.setVisibility(View.GONE);b.pageLogs.setVisibility(View.GONE);page.setVisibility(View.VISIBLE);}

    private void requestBtAndLoad(){
        if(Build.VERSION.SDK_INT>=31){
            boolean connect=ActivityCompat.checkSelfPermission(this,Manifest.permission.BLUETOOTH_CONNECT)==PackageManager.PERMISSION_GRANTED;
            if(!connect){
                ActivityCompat.requestPermissions(this,new String[]{Manifest.permission.BLUETOOTH_CONNECT},REQ_BT);
                return;
            }
        }
        loadBonded();
    }
    private void loadBonded(){if(bt==null){setStatus("Bluetooth non disponibile",false);return;} devices.clear();List<String> names=new ArrayList<>();try{Set<BluetoothDevice> bonded=bt.getBondedDevices();for(BluetoothDevice d:bonded){devices.add(d);names.add((d.getName()==null?"Dispositivo":d.getName())+"  •  "+d.getAddress());}}catch(SecurityException e){setStatus("Permesso Bluetooth mancante",false);} b.deviceSpinner.setAdapter(new ArrayAdapter<>(this,android.R.layout.simple_spinner_dropdown_item,names));if(names.isEmpty())setStatus("Abbina prima l'ELM327 dalle impostazioni Bluetooth",false);}

    private void connectSelected(){if(devices.isEmpty()){toast("Nessun dispositivo Bluetooth associato");return;}BluetoothDevice d=devices.get(b.deviceSpinner.getSelectedItemPosition());setStatus("Connessione in corso…",false);io.execute(()->{try{elm.connect(d);String id=elm.adapterId(),proto=elm.protocol(),volt=elm.voltage();ui(()->{setStatus("Connesso",true);b.adapterInfo.setText("Adapter: "+id+"  •  "+volt);b.protocolText.setText(proto);b.ecuSummary.setText("Protocollo: "+proto+"\nAuto Profile: identificazione in corso…");b.ecuExtendedSummary.setText("Extended ECU ID: in attesa del fingerprint read-only…");b.shareEcuIdentityButton.setEnabled(false);log("Connesso a "+id+" | "+proto+" | "+volt);});identifyEcuProfileInternal(false);}catch(Exception e){elm.close();ui(()->{setStatus("Connessione fallita",false);log("ERRORE connessione: "+e.getMessage());});}});}

    private void toggleLive(){if(!ensureConnected())return;live=!live;if(live){b.liveToggleButton.setText("Ferma live data");handler.post(liveTask);log("Live data avviati");}else{handler.removeCallbacks(liveTask);b.liveToggleButton.setText("Avvia live data");log("Live data fermati");}}
    private void toggleLogging(){
        if(!ensureConnected())return;
        if(!logging){
            try{
                File f=logger.start(this,"ai_session");
                logging=true;
                b.coldStartButton.setText("Ferma AI Diagnostic Mode");
                b.aiStatusText.setText("AI SESSION: RECORDING • dati salvati localmente");
                b.shareSessionButton.setEnabled(false);
                if(!live){live=true;b.liveToggleButton.setText("Ferma live data");handler.post(liveTask);}
                log("AI Diagnostic Mode avviata: "+f.getAbsolutePath());
            }catch(Exception e){log("Impossibile avviare sessione AI: "+e.getMessage());}
        }else{
            logging=false;
            b.coldStartButton.setText("Avvia AI Diagnostic Mode");
            File f=logger.getFile();
            b.aiStatusText.setText("AI SESSION: PRONTA DA CONDIVIDERE");
            b.shareSessionButton.setEnabled(f!=null && f.exists());
            log("AI Diagnostic Mode terminata: "+(f==null?"—":f.getAbsolutePath()));
        }
    }

    private void shareLastSession(){
        File f=logger.getFile();
        if(f==null || !f.exists()){toast("Nessuna sessione registrata");return;}
        try{
            android.net.Uri uri=FileProvider.getUriForFile(this,getPackageName()+".fileprovider",f);
            Intent share=new Intent(Intent.ACTION_SEND);
            share.setType("text/csv");
            share.putExtra(Intent.EXTRA_STREAM,uri);
            share.putExtra(Intent.EXTRA_SUBJECT,"208 OBD PRO - AI Diagnostic Session");
            share.putExtra(Intent.EXTRA_TEXT,"Analizza questa sessione OBD della mia Peugeot 208. Crea un report completo su avviamento a freddo, candele/bobine e combustione, fuel trim/lambda, aspirazione, turbo/boost, temperature, MAF/MAP, pressione carburante e tensione. Distingui dati certi da ipotesi e segnala i PID non supportati.");
            share.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);
            startActivity(Intent.createChooser(share,"Condividi sessione con ChatGPT"));
        }catch(Exception e){log("Condivisione sessione: "+e.getMessage());toast("Impossibile condividere il CSV");}
    }

    private String readSafe(String cmd, long timeoutMs){
        try { return elm.command(cmd, timeoutMs); } catch (Exception ignored) { return ""; }
    }

    private double readActualLambda(){
        // Prefer standardized wide-range O2 equivalence-ratio PIDs only when the ECU advertises them.
        String support20=readSafe("0120",1200);
        int[] candidates={0x24,0x25,0x26,0x27,0x28,0x29,0x2A,0x2B,0x34,0x35,0x36,0x37,0x38,0x39,0x3A,0x3B};
        for(int pid:candidates){
            if(!ObdParser.pidSupported(support20,0x20,pid)) continue;
            String p=String.format(Locale.ROOT,"%02X",pid);
            double v=ObdParser.widebandEquivalenceRatio(readSafe("01"+p,1100),p);
            if(v>0.2 && v<2.5) return v;
        }
        return -1;
    }

    private void pollLive(){
        if(!elm.isConnected())return;
        io.execute(()->{
            try{
                double rpm=ObdParser.rpm(readSafe("010C",850));
                int speed=ObdParser.speed(readSafe("010D",850));
                int coolant=ObdParser.coolant(readSafe("0105",850));
                int map=ObdParser.map(readSafe("010B",850));
                int baro=ObdParser.baro(readSafe("0133",850));
                double throttle=ObdParser.throttle(readSafe("0111",850));
                double load=ObdParser.engineLoad(readSafe("0104",850));
                double stft=ObdParser.fuelTrim(readSafe("0106",850),"06");
                double ltft=ObdParser.fuelTrim(readSafe("0107",850),"07");
                double timing=ObdParser.timingAdvance(readSafe("010E",850));
                int iat=ObdParser.intakeTemp(readSafe("010F",850));
                double maf=ObdParser.maf(readSafe("0110",850));
                double fuelPressure=ObdParser.fuelPressure(readSafe("010A",850));
                double railPressure=ObdParser.railPressure(readSafe("0123",850));
                double lambda=ObdParser.commandedLambda(readSafe("0144",850));
                double voltage=ObdParser.parseVoltage(readSafe("ATRV",850));
                double boost=(map>0 && baro>0)?map-baro:-999;

                // -100% a motore spento/risposta non valida non deve entrare nel report come vero LTFT.
                if(rpm>=0 && rpm<50 && ltft<=-99.0) ltft=-999;
                if(rpm>=0 && rpm<50 && stft<=-99.0) stft=-999;

                if(logging) try {
                    logger.append(System.currentTimeMillis(),rpm,speed,coolant,map,baro,boost,throttle,load,stft,ltft,
                            timing,iat,maf,fuelPressure,railPressure,lambda,voltage);
                } catch(Exception e){ logUi("CSV: "+e.getMessage()); }

                final double fStft=stft, fLtft=ltft;
                ui(()->updateMetrics(rpm,speed,coolant,map,baro,boost,throttle,load,fStft,fLtft,timing,iat,maf,fuelPressure,railPressure,lambda,voltage));
            }catch(Exception e){logUi("Live data: "+e.getMessage());}
        });
    }

    private void updateMetrics(double rpm,int speed,int coolant,int map,int baro,double boost,double throttle,double load,double stft,double ltft,
                               double timing,int iat,double maf,double fuelPressure,double railPressure,double lambda,double voltage){
        b.rpmValue.setText(rpm<0?"—":String.format(Locale.ITALY,"%.0f",rpm));
        b.speedValue.setText(speed<0?"—":String.valueOf(speed));
        b.coolantValue.setText(coolant==-999?"—":String.valueOf(coolant));
        b.mapValue.setText(map<0?"—":String.valueOf(map));
        b.throttleValue.setText(throttle<0?"—":String.format(Locale.ITALY,"%.1f",throttle));
        b.voltageValue.setText(voltage<0?"—":String.format(Locale.ITALY,"%.2f",voltage));
        b.fuelTrimText.setText(String.format(Locale.ITALY,"STFT: %s    LTFT: %s",stft==-999?"—":String.format(Locale.ITALY,"%.1f%%",stft),ltft==-999?"—":String.format(Locale.ITALY,"%.1f%%",ltft)));

        String boostTxt=boost==-999?"N/D":String.format(Locale.ITALY,"%+.0f kPa (%+.2f bar)",boost,boost/100.0);
        String baroTxt=baro<0?"N/D":baro+" kPa";
        b.turboText.setText("MAP: "+(map<0?"N/D":map+" kPa")+"  •  BARO: "+baroTxt+"\nBoost calcolato: "+boostTxt+"  •  Carico: "+fmtPct(load));

        String timingTxt=timing==-999?"N/D":String.format(Locale.ITALY,"%.1f°",timing);
        String iatTxt=iat==-999?"N/D":iat+" °C";
        String mafTxt=maf<0?"N/D":String.format(Locale.ITALY,"%.2f g/s",maf);
        String fp=fuelPressure<0?"N/D":String.format(Locale.ITALY,"%.0f kPa",fuelPressure);
        String rp=railPressure<0?"N/D":String.format(Locale.ITALY,"%.0f kPa",railPressure);
        String lam=lambda<0?"N/D":String.format(Locale.ITALY,"%.3f",lambda);
        b.ignitionText.setText("Anticipo: "+timingTxt+"  •  IAT: "+iatTxt+"\nMAF: "+mafTxt+"  •  Lambda cmd: "+lam+"\nFuel pressure: "+fp+"  •  Rail: "+rp);

        if(rpm>=0)b.rpmGraph.addValue((float)rpm);
        b.aiInsightText.setText(buildAiInsight(rpm,coolant,map,boost,stft,ltft,voltage));
    }

    private String fmtPct(double v){ return v<0?"N/D":String.format(Locale.ITALY,"%.1f%%",v); }

    private String buildAiInsight(double rpm,int coolant,int map,double boost,double stft,double ltft,double voltage){
        List<String> flags=new ArrayList<>();
        if(voltage>0){
            if(rpm>400 && voltage<13.0) flags.add("tensione di carica bassa");
            if(rpm>=0 && rpm<50 && voltage<11.8) flags.add("batteria sotto 11,8 V");
        }
        if(stft!=-999 && ltft!=-999 && Math.abs(stft+ltft)>20.0) flags.add("correzione carburazione elevata");
        if(rpm>600 && map>0 && map<18) flags.add("MAP insolitamente basso");
        if(coolant!=-999 && coolant>110) flags.add("temperatura refrigerante elevata");
        if(boost!=-999 && boost>80) flags.add("boost elevato: verificare coerenza con carico/RPM");
        if(flags.isEmpty()) return logging?"AI: acquisizione estesa in corso • accensione/turbo/fuel inclusi":"AI: valori live disponibili • avvia una sessione per il report";
        return "AI indicatori: "+String.join(" • ",flags)+". Indicazioni preliminari, non diagnosi.";
    }

    private void runTestCenter(String kind){
        if(!ensureConnected())return;
        b.testReportText.setText("TEST IN CORSO…\nNon spegnere il quadro e non scollegare ELM327.");
        io.execute(()->{
            String report=buildTestReport(kind);
            ui(()->{b.testReportText.setText(report);log("Test Center completato: "+kind);});
        });
    }

    private String buildTestReport(String kind){
        StringBuilder r=new StringBuilder();
        r.append("208 OBD PRO v2.9 • DEEP ENGINE DIAGNOSTICS\n");
        r.append("Modalità: ").append(testTitle(kind)).append("\n");
        EcuProfile p=currentProfile;
        if(p!=null){
            r.append("Veicolo: Peugeot 208 II 1.2 PureTech 100\n");
            r.append("ECU profile: ").append(p.family).append("\n");
            r.append("Calibration ID: ").append(p.calibrationId==null||p.calibrationId.isEmpty()?"N/D":p.calibrationId).append("\n");
            EcuExtendedIdentity ext=currentExtendedIdentity;
            if(ext!=null && ext.hasAnyData()){
                r.append("Extended ID: ").append(ext.supportedDidCount).append("/").append(ext.didValues.size()).append(" DID\n");
                if(!ext.supplierId.isEmpty()) r.append("Supplier: ").append(ext.supplierId).append("\n");
                if(!ext.manufacturerHardwareNumber.isEmpty()) r.append("HW: ").append(ext.manufacturerHardwareNumber).append("\n");
                else if(!ext.supplierHardwareNumber.isEmpty()) r.append("HW: ").append(ext.supplierHardwareNumber).append("\n");
                if(!ext.manufacturerSoftwareNumber.isEmpty()) r.append("SW: ").append(ext.manufacturerSoftwareNumber).append("\n");
                else if(!ext.supplierSoftwareNumber.isEmpty()) r.append("SW: ").append(ext.supplierSoftwareNumber).append("\n");
            }
            r.append(p.testPolicy()).append("\n");
        }else{
            r.append("AUTO PROFILE: non ancora completato • uso PID OBD-II supportati\n");
        }
        r.append("================================\n");

        double rpm=ObdParser.rpm(readSafe("010C",1000));
        int speed=ObdParser.speed(readSafe("010D",1000));
        int coolant=ObdParser.coolant(readSafe("0105",1000));
        int iat=ObdParser.intakeTemp(readSafe("010F",1000));
        int ambient=ObdParser.ambientTemp(readSafe("0146",1000));
        int map=ObdParser.map(readSafe("010B",1000));
        int baro=ObdParser.baro(readSafe("0133",1000));
        double boost=(map>0&&baro>0)?map-baro:-999;
        double throttle=ObdParser.throttle(readSafe("0111",1000));
        double load=ObdParser.engineLoad(readSafe("0104",1000));
        double stft=ObdParser.fuelTrim(readSafe("0106",1000),"06");
        double ltft=ObdParser.fuelTrim(readSafe("0107",1000),"07");
        double timing=ObdParser.timingAdvance(readSafe("010E",1000));
        double maf=ObdParser.maf(readSafe("0110",1000));
        double fuelPressure=ObdParser.fuelPressure(readSafe("010A",1000));
        double rail=ObdParser.railPressure(readSafe("0123",1000));
        double lambda=ObdParser.commandedLambda(readSafe("0144",1000));
        double o2=ObdParser.o2VoltageB1S1(readSafe("0114",1000));
        double evap=ObdParser.evapPurge(readSafe("012E",1000));
        double fuelLevel=ObdParser.fuelLevel(readSafe("012F",1000));
        int runtime=ObdParser.engineRuntime(readSafe("011F",1000));
        int milKm=ObdParser.distanceWithMil(readSafe("0121",1000));
        int warmups=ObdParser.warmupsSinceClear(readSafe("0130",1000));
        int sinceClear=ObdParser.distanceSinceClear(readSafe("0131",1000));
        double adapterV=ObdParser.parseVoltage(readSafe("ATRV",1000));
        double ecuV=ObdParser.moduleVoltage(readSafe("0142",1000));
        String readiness=ObdParser.readinessSummary(readSafe("0101",1200));
        String dtcRaw=readSafe("03",2500);
        List<String> dtcs=ObdParser.dtcs(dtcRaw);

        if(rpm>=0&&rpm<50&&ltft<=-99)ltft=-999;
        if(rpm>=0&&rpm<50&&stft<=-99)stft=-999;

        if(kind.equals("FULL")||kind.equals("CHARGING")||kind.equals("COLD")){
            section(r,"BATTERIA / RICARICA");
            line(r,"Tensione ELM",fmt(adapterV," V"));
            line(r,"Tensione ECU",fmt(ecuV," V"));
            if(rpm>400 && adapterV>0) verdict(r,adapterV>=13.2&&adapterV<=15.2,"Ricarica compatibile con motore acceso","Tensione di carica da verificare");
            else if(rpm>=0&&rpm<50&&adapterV>0) verdict(r,adapterV>=11.8,"Tensione a quadro acceso accettabile","Batteria bassa: ricaricare/testare prima di reset o diagnosi lunghe");
        }

        if(kind.equals("FULL")||kind.equals("COLD")){
            section(r,"AVVIAMENTO / MOTORE FREDDO");
            line(r,"RPM",rpm<0?"N/D":String.format(Locale.ITALY,"%.0f",rpm));
            line(r,"Coolant",coolant==-999?"N/D":coolant+" °C");
            line(r,"IAT",iat==-999?"N/D":iat+" °C");
            line(r,"Ambiente",ambient==-999?"N/D":ambient+" °C");
            if(coolant!=-999&&iat!=-999&&rpm<50) verdict(r,Math.abs(coolant-iat)<=15,"ECT e IAT plausibili a motore fermo/freddo","ECT/IAT molto distanti: verificare solo se motore realmente freddo");
            r.append("Nota: per il vero test avviamento registra AI Diagnostic Mode PRIMA di mettere in moto.\n");
        }

        if(kind.equals("FULL")||kind.equals("IDLE")){
            section(r,"MINIMO / REGOLARITÀ");
            double min=99999,max=-1,sum=0; int n=0;
            if(rpm>400&&speed==0){
                for(int i=0;i<6;i++){ double x=ObdParser.rpm(readSafe("010C",900)); if(x>0){min=Math.min(min,x);max=Math.max(max,x);sum+=x;n++;} }
            }
            if(n>0){line(r,"RPM medio",String.format(Locale.ITALY,"%.0f",sum/n));line(r,"Oscillazione",String.format(Locale.ITALY,"%.0f rpm",max-min));verdict(r,(max-min)<120,"Minimo abbastanza stabile","Oscillazione minimo elevata nel campione");}
            else r.append("• Test dinamico minimo: richiede motore acceso e vettura ferma.\n");
        }

        if(kind.equals("FULL")||kind.equals("IGNITION")){
            section(r,"CANDELE / BOBINE / ACCENSIONE");
            line(r,"Anticipo",timing==-999?"N/D":String.format(Locale.ITALY,"%.1f°",timing));
            line(r,"STFT",stft==-999?"N/D":String.format(Locale.ITALY,"%.1f%%",stft));
            line(r,"LTFT",ltft==-999?"N/D":String.format(Locale.ITALY,"%.1f%%",ltft));
            if(stft!=-999&&ltft!=-999) verdict(r,Math.abs(stft+ltft)<15,"Correzioni carburazione contenute","Fuel trim elevato: può influenzare combustione, non prova da solo candele difettose");
            Mode06Analyzer.Report m06=Mode06Analyzer.analyze(elm);
            r.append("• Mode $06 misfire: ").append(m06.compact()).append("\n");
            if(m06.anyData){
                r.append("• C1/C2/C3 sono i tre cilindri del 1.2 PureTech; confrontare i conteggi soprattutto tra loro.\n");
            } else {
                r.append("• La ECU non ha esposto i contatori standard A2/A3/A4 in questa scansione.\n");
            }
            r.append("• Le candele non sono ispezionabili fisicamente via OBD: misfire elevati indicano il cilindro da approfondire, non distinguono da soli candela, bobina, iniettore o compressione.\n");
        }

        if(kind.equals("FULL")||kind.equals("FUEL")){
            section(r,"INIEZIONE / CARBURAZIONE / LAMBDA");
            line(r,"STFT",stft==-999?"N/D":String.format(Locale.ITALY,"%.1f%%",stft));
            line(r,"LTFT",ltft==-999?"N/D":String.format(Locale.ITALY,"%.1f%%",ltft));
            line(r,"Lambda comandata",lambda<0?"N/D":String.format(Locale.ITALY,"%.3f",lambda));
            double actualLambda=readActualLambda();
            line(r,"Lambda reale wideband",actualLambda<0?"N/D":String.format(Locale.ITALY,"%.3f",actualLambda));
            if(lambda>0 && actualLambda>0) line(r,"Delta lambda cmd/reale",String.format(Locale.ITALY,"%+.3f",actualLambda-lambda));
            line(r,"O2 B1S1",o2<0?"N/D":String.format(Locale.ITALY,"%.3f V",o2));
            line(r,"Pressione carburante",fuelPressure<0?"N/D":String.format(Locale.ITALY,"%.0f kPa",fuelPressure));
            line(r,"Rail",rail<0?"N/D":String.format(Locale.ITALY,"%.0f kPa",rail));
            if(stft!=-999&&ltft!=-999) verdict(r,Math.abs(stft+ltft)<=20,"Fuel trim entro fascia ampia di controllo","Fuel trim molto elevato: cercare aria falsa, alimentazione o misura aria/lambda");
        }

        if(kind.equals("FULL")||kind.equals("TURBO")){
            section(r,"TURBO / ASPIRAZIONE");
            line(r,"MAP",map<0?"N/D":map+" kPa abs");
            line(r,"BARO",baro<0?"N/D":baro+" kPa");
            line(r,"Boost calcolato",boost==-999?"N/D":String.format(Locale.ITALY,"%+.0f kPa (%+.2f bar)",boost,boost/100.0));
            line(r,"Carico",load<0?"N/D":String.format(Locale.ITALY,"%.1f%%",load));
            line(r,"MAF",maf<0?"N/D":String.format(Locale.ITALY,"%.2f g/s",maf));
            line(r,"Throttle",throttle<0?"N/D":String.format(Locale.ITALY,"%.1f%%",throttle));
            if(rpm<1200) r.append("• Per valutare davvero il turbo serve una sessione su strada sotto carico; al minimo il boost non è diagnostico.\n");
            else if(boost!=-999) verdict(r,boost>-10,"Pressione aspirazione plausibile nel campione","MAP molto sotto BARO: valutare condizioni di carico prima di concludere");
        }

        if(kind.equals("FULL")||kind.equals("COOLING")){
            section(r,"RAFFREDDAMENTO / TEMPERATURE");
            line(r,"Coolant",coolant==-999?"N/D":coolant+" °C");
            line(r,"IAT",iat==-999?"N/D":iat+" °C");
            line(r,"Ambiente",ambient==-999?"N/D":ambient+" °C");
            if(coolant!=-999&&rpm>400) verdict(r,coolant<111,"Temperatura refrigerante non critica nel campione","Temperatura refrigerante elevata");
            r.append("• Il comando forzato ventola non viene eseguito: richiede diagnostica PSA specifica e attuazione controllata.\n");
        }

        if(kind.equals("FULL")||kind.equals("EMISSIONS")||kind.equals("READINESS")){
            section(r,"EMISSIONI / READINESS / PRE-REVISIONE");
            line(r,"Readiness",readiness);
            line(r,"EVAP purge",evap<0?"N/D":String.format(Locale.ITALY,"%.1f%%",evap));
            line(r,"Distanza con MIL",milKm<0?"N/D":milKm+" km");
            line(r,"Warm-up da clear",warmups<0?"N/D":String.valueOf(warmups));
            line(r,"Km da clear DTC",sinceClear<0?"N/D":sinceClear+" km");
            List<String> pending=ObdParser.pendingDtcs(readSafe("07",2200));
            List<String> permanent=ObdParser.permanentDtcs(readSafe("0A",2200));
            line(r,"DTC confermati",dtcs.isEmpty()?"nessuno":String.join(", ",dtcs));
            line(r,"DTC pending",pending.isEmpty()?"nessuno":String.join(", ",pending));
            line(r,"DTC permanenti",permanent.isEmpty()?"nessuno":String.join(", ",permanent));
            if(!dtcs.isEmpty()||!pending.isEmpty()||!permanent.isEmpty()) r.append("⚠ DTC presenti/pending/permanenti: salvare freeze-frame e diagnosticare la causa prima di cancellare.\n");
            r.append("• Catalizzatore/O2: Mode $06 e readiness sono più affidabili del solo valore istantaneo O2.\n");
        }

        if(kind.equals("FULL")||kind.equals("SENSORS")){
            section(r,"SENSORI / PLAUSIBILITÀ");
            line(r,"RPM",rpm<0?"N/D":String.format(Locale.ITALY,"%.0f",rpm));
            line(r,"Velocità",speed<0?"N/D":speed+" km/h");
            line(r,"MAP",map<0?"N/D":map+" kPa");
            line(r,"BARO",baro<0?"N/D":baro+" kPa");
            line(r,"Throttle",throttle<0?"N/D":String.format(Locale.ITALY,"%.1f%%",throttle));
            line(r,"MAF",maf<0?"N/D":String.format(Locale.ITALY,"%.2f g/s",maf));
            line(r,"Fuel level",fuelLevel<0?"N/D":String.format(Locale.ITALY,"%.0f%%",fuelLevel));
            if(rpm<50&&map>0&&baro>0) verdict(r,Math.abs(map-baro)<=12,"MAP e BARO coerenti a motore spento","MAP/BARO distanti a motore spento: verificare sensori/condizioni");
        }

        if(kind.equals("FULL")||kind.equals("SERVICE")){
            section(r,"TAGLIANDO / MANUTENZIONE");
            line(r,"Runtime motore",runtime<0?"N/D":String.format(Locale.ITALY,"%dh %02dm",runtime/3600,(runtime%3600)/60));
            line(r,"Km da cancellazione DTC",sinceClear<0?"N/D":sinceClear+" km");
            line(r,"Warm-up da cancellazione",warmups<0?"N/D":String.valueOf(warmups));
            line(r,"Liquido refrigerante",coolant==-999?"N/D":coolant+" °C ora");
            line(r,"Tensione",adapterV<0?"N/D":String.format(Locale.ITALY,"%.2f V",adapterV));
            r.append("CHECKLIST FISICA (OBD non misura l'usura reale):\n");
            r.append("□ olio motore + filtro  □ filtro aria  □ filtro abitacolo\n");
            r.append("□ candele  □ freni/pastiglie/dischi  □ pneumatici/pressioni\n");
            r.append("□ liquido freni  □ refrigerante  □ perdite  □ cinghia servizi\n");
            r.append("□ distribuzione secondo piano Peugeot/VIN e storia interventi\n");
            r.append("• Il reset della spia/tagliando del quadro NON viene inviato via ELM generico: va fatto con procedura prevista dal veicolo o diagnostica PSA verificata.\n");
        }

        r.append("\nDTC attuali: ").append(dtcs.isEmpty()?"nessuno":String.join(", ",dtcs)).append("\n");
        r.append("Nota: N/D = PID non supportato/non disponibile. Questo è screening diagnostico, non sostituisce misure meccaniche o strumentazione d'officina.\n");
        return r.toString();
    }

    private String collectMode06Compact(){
        return Mode06Analyzer.analyze(elm).compact();
    }

    private String testTitle(String kind){
        switch(kind){
            case "SERVICE": return "Tagliando / manutenzione";
            case "COLD": return "Avviamento a freddo";
            case "IDLE": return "Minimo / regolarità";
            case "IGNITION": return "Candele / bobine / accensione";
            case "FUEL": return "Iniezione / carburazione / lambda";
            case "TURBO": return "Turbo / aspirazione / boost";
            case "COOLING": return "Raffreddamento / temperature";
            case "CHARGING": return "Batteria / alternatore";
            case "EMISSIONS": return "Emissioni / catalizzatore / EVAP";
            case "SENSORS": return "Sensori / plausibilità";
            case "READINESS": return "Readiness / pre-revisione";
            default: return "Test completo motore";
        }
    }

    private void section(StringBuilder r,String title){r.append("\n[").append(title).append("]\n");}
    private void line(StringBuilder r,String name,String value){r.append("• ").append(name).append(": ").append(value).append("\n");}
    private void verdict(StringBuilder r,boolean ok,String yes,String no){r.append(ok?"✓ ":"⚠ ").append(ok?yes:no).append("\n");}
    private String fmt(double v,String unit){return v<0?"N/D":String.format(Locale.ITALY,"%.2f%s",v,unit);}

    private void shareTestReport(){
        String text=b.testReportText.getText().toString();
        if(text.trim().isEmpty()||text.contains("Nessun test")){toast("Esegui prima un test");return;}
        Intent share=new Intent(Intent.ACTION_SEND);
        share.setType("text/plain");
        share.putExtra(Intent.EXTRA_SUBJECT,"208 OBD PRO - Test Center Report");
        share.putExtra(Intent.EXTRA_TEXT,text+"\n\nAnalizza questo report della mia Peugeot 208 distinguendo anomalie certe, sospetti e controlli meccanici consigliati.");
        startActivity(Intent.createChooser(share,"Condividi report"));
    }

    private void readMode06(){
        if(!ensureConnected())return;
        io.execute(()->{
            Mode06Analyzer.Report report=Mode06Analyzer.analyze(elm);
            StringBuilder out=new StringBuilder(report.detailed());
            if(!report.anyData){
                out.append("\n\nRAW MODE $06 SUPPORT BLOCKS\n");
                for(String cmd:new String[]{"0600","0620","0640","0660","0680","06A0","06C0"}){
                    String raw=readSafe(cmd,1600);
                    String u=raw.toUpperCase(Locale.ROOT);
                    if(!raw.isEmpty()&&!u.contains("NO DATA")&&!u.contains("UNABLE")) out.append(cmd).append(": ").append(raw).append("\n");
                }
            }
            ui(()->{
                b.mode06Text.setText(out.toString());
                log("Mode $06 misfire scan C1/C2/C3 completata (sola lettura)");
            });
        });
    }

    private void readVehicleInfo(){
        if(!ensureConnected())return;
        b.ecuExtendedSummary.setText("Extended ECU ID: scansione read-only in corso…");
        b.shareEcuIdentityButton.setEnabled(false);
        io.execute(()->identifyEcuProfileInternal(true));
    }

    private void identifyEcuProfileInternal(boolean userRequested){
        try{
            String proto=elm.protocol();
            String id=elm.adapterId();
            String vinRaw=readSafe("0902",3500);
            String calRaw=readSafe("0904",3500);
            String cvnRaw=readSafe("0906",3500);
            String nameRaw=readSafe("090A",3500);
            String vin=ObdParser.vin(vinRaw);
            String cal=ObdParser.calibrationId(calRaw);
            String cvn=ObdParser.cvn(cvnRaw);
            String ecuName=ObdParser.ecuName(nameRaw);
            EcuProfile basic=EcuProfile.detect(vin,proto,cal,cvn,ecuName);
            currentProfile=basic;
            currentExtendedIdentity=null;

            ui(()->{
                b.vinText.setText("VIN: "+(vin.isEmpty()?"non disponibile":vin));
                b.ecuSummary.setText(basic.summary()+"\nInterfaccia: "+id+"\n"+basic.testPolicy());
                b.ecuExtendedSummary.setText("Extended ECU ID: scansione UDS read-only in corso…\nTarget motore CAN 0x7E0 • solo servizio 0x22");
                b.shareEcuIdentityButton.setEnabled(false);
                log("AUTO PROFILE BASIC | VIN="+vin+" | ECU="+basic.family+" | CAL="+cal+" | CVN="+cvn+" | NAME="+ecuName);
            });

            try{
                EcuExtendedIdentity ext=EcuIdentityReader.read(elm);
                currentExtendedIdentity=ext;
                EcuProfile enhanced=basic.withExtended(ext);
                currentProfile=enhanced;
                String finalVin=(enhanced.vin==null||enhanced.vin.isEmpty())?vin:enhanced.vin;
                ui(()->{
                    b.vinText.setText("VIN: "+(finalVin.isEmpty()?"non disponibile":finalVin));
                    b.ecuSummary.setText(enhanced.summary()+"\nInterfaccia: "+id+"\n"+enhanced.testPolicy());
                    b.ecuExtendedSummary.setText(ext.hasAnyData()?ext.compactSummary():"Extended ECU ID: nessun DID UDS 0x22 disponibile dalla ECU motore");
                    b.shareEcuIdentityButton.setEnabled(ext.hasAnyData());
                    log("AUTO PROFILE EXTENDED | DID="+ext.supportedDidCount+"/"+ext.didValues.size()+" | FAMILY="+enhanced.family+" | SUPPLIER="+ext.supplierId+" | HW="+ext.manufacturerHardwareNumber+" | SW="+ext.manufacturerSoftwareNumber);
                    if(userRequested) toast(enhanced.exactFamilyMatch?"Famiglia ECU confermata dal fingerprint":"Fingerprint ECU esteso completato");
                });
            }catch(Exception extError){
                elm.restoreObdFunctionalHeader();
                ui(()->{
                    b.ecuExtendedSummary.setText("Extended ECU ID non conclusivo: "+(extError.getMessage()==null?"nessuna risposta UDS":extError.getMessage())+"\nMode 09 resta valido; nessun comando di scrittura è stato inviato.");
                    b.shareEcuIdentityButton.setEnabled(false);
                    log("EXTENDED ECU ID: "+extError.getMessage());
                    if(userRequested) toast("Mode 09 letto; Extended ID non disponibile");
                });
            }
        }catch(Exception e){
            logUi("ECU Auto Profile: "+e.getMessage());
            if(userRequested) ui(()->toast("Identificazione ECU non conclusiva"));
        }
    }

    private void shareEcuIdentity(){
        EcuProfile p=currentProfile;
        EcuExtendedIdentity ext=currentExtendedIdentity;
        if(p==null || ext==null || !ext.hasAnyData()){
            toast("Esegui prima Identifica ECU / Extended Profile");
            return;
        }
        StringBuilder text=new StringBuilder();
        text.append("208 OBD PRO v2.9 - ECU FINGERPRINT\n\n");
        text.append(p.summary()).append("\n").append(p.testPolicy()).append("\n\n");
        text.append(ext.rawReport());
        text.append("\nNota sicurezza: identificazione ottenuta in sola lettura; nessun comando di coding/scrittura è stato inviato.");
        Intent share=new Intent(Intent.ACTION_SEND);
        share.setType("text/plain");
        share.putExtra(Intent.EXTRA_SUBJECT,"Peugeot 208 - Engine ECU Fingerprint");
        share.putExtra(Intent.EXTRA_TEXT,text.toString()+"\n\nIdentifica con precisione famiglia ECU, produttore e riferimenti HW/SW. Distingui ciò che è certo da ciò che è solo probabile.");
        startActivity(Intent.createChooser(share,"Condividi fingerprint ECU"));
    }

    private void readDtcs(){if(!ensureConnected())return;io.execute(()->{try{String raw=elm.command("03",3000);List<String> dtcs=ObdParser.dtcs(raw);ui(()->{b.dtcText.setText(dtcs.isEmpty()?"Nessun DTC OBD-II rilevato":String.join("\n",dtcs));log("DTC RAW: "+raw);});}catch(Exception e){logUi("DTC: "+e.getMessage());}});}
    private void confirmClear(){new AlertDialog.Builder(this).setTitle("Cancella DTC").setMessage("Cancella i codici OBD e i relativi freeze-frame. Non risolve la causa del guasto.").setNegativeButton("Annulla",null).setPositiveButton("Cancella",(d,w)->sendSafe("04","CLEAR DTC")).show();}

    private void runPrecheck(boolean thenReset){
        if(!ensureConnected())return;
        io.execute(()->{
            try{
                int speed=ObdParser.speed(elm.command("010D",1200));
                double rpm=ObdParser.rpm(elm.command("010C",1200));
                double voltage=ObdParser.parseVoltage(elm.voltage());
                boolean verified=speed>=0&&rpm>=0&&voltage>0;
                boolean safe=verified&&speed==0&&rpm<1&&voltage>=11.8;
                String msg=!verified?"BLOCCATO • dati non verificabili":safe?
                        String.format(Locale.ITALY,"OK • 0 km/h • motore spento • %.2f V",voltage):
                        String.format(Locale.ITALY,"BLOCCATO • %d km/h • %.0f rpm • %.2f V",speed,rpm,voltage);
                ui(()->{b.safetyText.setText("Safety gate: "+msg);log("Pre-check reset: "+msg);});
                if(safe&&thenReset) snapshotDtcsBeforeReset();
            }catch(Exception e){logUi("Pre-check: "+e.getMessage());}
        });
    }

    private void confirmReset(){
        new AlertDialog.Builder(this)
                .setTitle("Safe ECU Restart")
                .setMessage("Riavvia solo la ECU motore tramite diagnostica. NON equivale a scollegare la batteria e non azzera automaticamente gli adattamenti. Prima salva i DTC, poi verifica 0 km/h, motore spento e tensione ≥ 11,8 V. Radio, BSI, airbag e immobilizer non vengono toccati.")
                .setNegativeButton("Annulla",null)
                .setPositiveButton("Continua",(d,w)->confirmResetSecondStep())
                .show();
    }

    private void confirmResetSecondStep(){
        new AlertDialog.Builder(this)
                .setTitle("Conferma finale")
                .setMessage("Quadro ACCESO, motore SPENTO, vettura FERMA. Non scollegare l'ELM327 durante il riavvio. Procedere?")
                .setNegativeButton("Annulla",null)
                .setPositiveButton("Pre-check + riavvio ECU",(d,w)->runPrecheck(true))
                .show();
    }

    private void snapshotDtcsBeforeReset(){
        try{
            String raw=elm.command("03",3000);
            List<String> dtcs=ObdParser.dtcs(raw);
            String txt=dtcs.isEmpty()?"nessun DTC OBD-II":String.join(", ",dtcs);
            logUi("Snapshot DTC pre-reset: "+txt+" | RAW: "+raw);
            performEcuReset();
        }catch(Exception e){
            logUi("Reset BLOCCATO: impossibile salvare i DTC pre-reset: "+e.getMessage());
            ui(()->b.safetyText.setText("Safety gate: BLOCCATO • snapshot DTC non riuscito"));
        }
    }

    private void performEcuReset(){
        try{
            elm.command("ATH1",800);
            elm.command("ATSH7E0",800);
            String resp=elm.command("1101",2200);
            String hex=ObdParser.hexOnly(resp);
            elm.restoreAutomaticProtocol();
            if(hex.contains("5101")){
                ui(()->{
                    b.safetyText.setText("Safety gate: ECU reset accettato • attesa riavvio");
                    setStatus("ECU in riavvio…",true);
                    log("RESET ECU ACCETTATO: "+resp);
                });
                try{Thread.sleep(3500);}catch(InterruptedException ignored){Thread.currentThread().interrupt();}
                verifyAfterReset();
            }else{
                ui(()->{
                    b.safetyText.setText("Safety gate: reset non confermato/supportato");
                    setStatus("Reset non eseguito",false);
                    log("RESET NON CONFERMATO/SUPPORTATO: "+resp);
                });
            }
        }catch(Exception e){
            elm.restoreAutomaticProtocol();
            logUi("Reset ECU: "+e.getMessage());
            ui(()->{b.safetyText.setText("Safety gate: reset interrotto/non confermato");setStatus("Reset non confermato",false);});
        }
    }

    private void verifyAfterReset(){
        try{
            String pids=elm.command("0100",2500);
            double rpm=ObdParser.rpm(readSafe("010C",1200));
            double voltage=ObdParser.parseVoltage(readSafe("ATRV",1200));
            boolean ecuBack=pids!=null&&!pids.trim().isEmpty()&&!pids.toUpperCase(Locale.ROOT).contains("NO DATA");
            ui(()->{
                if(ecuBack){
                    b.safetyText.setText("Safety gate: ECU online dopo riavvio");
                    setStatus("ECU online • riavvio completato",true);
                    log(String.format(Locale.ITALY,"Verifica post-reset OK • rpm %.0f • %.2f V • 0100: %s",rpm,voltage,pids));
                }else{
                    b.safetyText.setText("Safety gate: ECU non verificata dopo riavvio");
                    setStatus("Riconnetti ELM327 e riesegui la scansione",false);
                    log("Verifica post-reset non conclusiva • 0100: "+pids);
                }
            });
        }catch(Exception e){
            ui(()->{b.safetyText.setText("Safety gate: riavvio inviato • riconnessione richiesta");setStatus("Riconnetti ELM327",false);});
            logUi("Verifica post-reset: "+e.getMessage());
        }
    }

    private void sendConsole(){String cmd=b.commandInput.getText().toString().trim().toUpperCase(Locale.ROOT);if(cmd.isEmpty())return;if(isBlockedConsoleCommand(cmd)){new AlertDialog.Builder(this).setTitle("Comando bloccato").setMessage("La console Pro non consente comandi di flashing/programmazione firmware, immobilizer o scritture su moduli di sicurezza.").setPositiveButton("OK",null).show();return;}sendSafe(cmd,"CONSOLE");}
    private boolean isBlockedConsoleCommand(String cmd){String c=cmd.replace(" ","");return c.startsWith("34")||c.startsWith("35")||c.startsWith("36")||c.startsWith("37")||c.startsWith("270")||c.startsWith("2E")||c.startsWith("2F")||c.startsWith("3101");}
    private void sendSafe(String cmd,String label){if(!ensureConnected())return;io.execute(()->{try{String r=elm.command(cmd,3000);logUi(label+" > "+cmd+"\n"+r);}catch(Exception e){logUi(label+": "+e.getMessage());}});}

    private boolean ensureConnected(){if(elm.isConnected())return true;toast("Connetti prima l'ELM327");return false;}
    private void setStatus(String s,boolean ok){b.statusText.setText(s);b.statusDot.setBackgroundColor(getColor(ok?R.color.ok:R.color.danger));}
    private void log(String s){String stamp=java.text.DateFormat.getTimeInstance().format(new java.util.Date());b.logText.append("\n["+stamp+"] "+s+"\n");}
    private void logUi(String s){ui(()->log(s));}
    private void ui(Runnable r){runOnUiThread(r);} private void toast(String s){Toast.makeText(this,s,Toast.LENGTH_SHORT).show();}

    @Override public void onRequestPermissionsResult(int req,@NonNull String[] p,@NonNull int[] g){
        super.onRequestPermissionsResult(req,p,g);
        if(req==REQ_BT){
            boolean granted=g.length>0&&g[0]==PackageManager.PERMISSION_GRANTED;
            if(granted) loadBonded();
            else {
                setStatus("Permesso Bluetooth necessario",false);
                toast("Concedi il permesso Dispositivi nelle vicinanze per usare ELM327");
            }
        }
    }
    @Override protected void onDestroy(){live=false;handler.removeCallbacks(liveTask);elm.close();io.shutdownNow();super.onDestroy();}
}
