package com.peugeot.obdtool;

import java.util.LinkedHashMap;
import java.util.Locale;
import java.util.Map;

/**
 * Conservative engine-ECU identification reader.
 * It targets the conventional OBD engine ECU address 0x7E0 and sends ONLY UDS service 0x22.
 * No diagnostic-session changes, security access, routines, coding, resets or writes are issued.
 */
public final class EcuIdentityReader {
    private static final String ENGINE_HEADER="7E0";

    private EcuIdentityReader(){}

    public static EcuExtendedIdentity read(Elm327Client elm) throws Exception {
        String proto=elm.protocol();
        String p=proto==null?"":proto.toUpperCase(Locale.ROOT);
        if(!(p.contains("CAN") || p.contains("ISO 15765"))) {
            throw new IllegalStateException("Extended ECU ID disponibile solo su protocollo CAN/ISO 15765");
        }
        if(!p.contains("11")) {
            throw new IllegalStateException("Extended ECU ID bloccato: profilo fisico 0x7E0 previsto solo per CAN 11-bit");
        }

        LinkedHashMap<String,String> values=new LinkedHashMap<>();
        // ISO 14229 standardized identification DIDs. Every request below is read-only (0x22).
        String[] dids={
                "F180", // boot software identification
                "F181", // application software identification
                "F182", // application data identification
                "F187", // vehicle manufacturer spare part number
                "F188", // vehicle manufacturer ECU software number
                "F189", // vehicle manufacturer ECU software version
                "F18A", // system supplier identifier
                "F18C", // ECU serial number
                "F190", // VIN
                "F191", // vehicle manufacturer ECU hardware number
                "F192", // system supplier ECU hardware number
                "F193", // system supplier ECU hardware version
                "F194", // system supplier ECU software number
                "F195"  // system supplier ECU software version
        };

        try {
            // Stay in the current/default diagnostic session. Only select the engine ECU CAN address.
            elm.command("ATH0",700);
            elm.command("ATCAF1",700);
            elm.command("ATSH"+ENGINE_HEADER,900);

            for(String did:dids){
                String raw="";
                try { raw=elm.command("22"+did,1200); }
                catch(Exception ignored) { raw=""; }
                values.put(did,decodeDid(raw,did));
            }
        } finally {
            // Restore standard OBD functional engine request address for the rest of the app.
            elm.restoreObdFunctionalHeader();
        }

        return new EcuExtendedIdentity(
                ENGINE_HEADER,
                values.get("F180"), values.get("F181"), values.get("F182"),
                values.get("F187"), values.get("F188"), values.get("F189"),
                values.get("F18A"), values.get("F18C"), values.get("F190"),
                values.get("F191"), values.get("F192"), values.get("F193"),
                values.get("F194"), values.get("F195"), values
        );
    }

    static String decodeDid(String raw,String did){
        if(raw==null) return "";
        String upper=raw.toUpperCase(Locale.ROOT);
        if(upper.contains("NO DATA") || upper.contains("STOPPED") || upper.contains("ERROR") || upper.contains("UNABLE TO CONNECT")) return "";
        String h=ObdParser.hexOnly(raw);
        String marker="62"+did.toUpperCase(Locale.ROOT);
        int idx=h.indexOf(marker);
        if(idx<0) return ""; // also rejects negative 7F 22 responses
        String data=h.substring(idx+marker.length());
        if(data.isEmpty()) return "";

        // Remove common trailing padding before deciding how to present the identifier.
        while(data.endsWith("00") || data.endsWith("FF")) data=data.substring(0,data.length()-2);
        if(data.isEmpty()) return "";

        StringBuilder ascii=new StringBuilder();
        int printable=0,total=0;
        for(int i=0;i+1<data.length();i+=2){
            try{
                int v=Integer.parseInt(data.substring(i,i+2),16);
                total++;
                if(v>=32 && v<=126){ ascii.append((char)v); printable++; }
                else if(v==0){ /* padding */ }
                else ascii.append(' ');
            }catch(Exception ignored){}
        }
        String text=ascii.toString().replaceAll("\\s+"," ").trim();
        if(total>0 && printable>=Math.max(2,(int)Math.ceil(total*0.55)) && !text.isEmpty()) return text;

        // Binary identifiers remain useful for ECU fingerprinting; expose them as spaced hex.
        StringBuilder hex=new StringBuilder();
        for(int i=0;i+1<data.length();i+=2){ if(hex.length()>0)hex.append(' '); hex.append(data,i,i+2); }
        return "HEX "+hex;
    }
}
