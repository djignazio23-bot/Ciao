package com.peugeot.obdtool;

import java.util.Locale;

/**
 * Read-only SAE J1979 Mode $06 helper focused on the 3-cylinder EB2 engine.
 * Standard OBD Monitor IDs A2/A3/A4 correspond to cylinders 1/2/3.
 * Standard Test ID 0C = misfire count for current/last driving cycle.
 * Standard Test ID 0B = EWMA misfire count over the last 10 driving cycles.
 * No actuator command, reset or write is issued.
 */
public final class Mode06Analyzer {
    private Mode06Analyzer() {}

    public static final class Cylinder {
        public final int number;
        public final int current;
        public final int ewma;
        public final boolean currentAvailable;
        public final boolean ewmaAvailable;
        public final String raw;

        Cylinder(int number, int current, int ewma, boolean currentAvailable, boolean ewmaAvailable, String raw) {
            this.number = number;
            this.current = current;
            this.ewma = ewma;
            this.currentAvailable = currentAvailable;
            this.ewmaAvailable = ewmaAvailable;
            this.raw = raw == null ? "" : raw;
        }
    }

    public static final class Report {
        public final Cylinder c1, c2, c3;
        public final boolean anyData;

        Report(Cylinder c1, Cylinder c2, Cylinder c3) {
            this.c1 = c1; this.c2 = c2; this.c3 = c3;
            this.anyData = has(c1) || has(c2) || has(c3);
        }

        private static boolean has(Cylinder c) { return c != null && (c.currentAvailable || c.ewmaAvailable); }

        public String compact() {
            if (!anyData) return "Mode $06 misfire standard: dati A2/A3/A4 non disponibili";
            return one(c1) + " • " + one(c2) + " • " + one(c3);
        }

        private static String one(Cylinder c) {
            if (c == null || (!c.currentAvailable && !c.ewmaAvailable)) return "C? N/D";
            String cur = c.currentAvailable ? String.valueOf(c.current) : "N/D";
            String avg = c.ewmaAvailable ? String.valueOf(c.ewma) : "N/D";
            return "C" + c.number + " current=" + cur + " EWMA=" + avg;
        }

        public String detailed() {
            StringBuilder s = new StringBuilder();
            s.append("MODE $06 • MISFIRE 3 CILINDRI • SOLA LETTURA\n");
            s.append("TID 0C = conteggi ciclo corrente/ultimo • TID 0B = media EWMA ultimi 10 cicli\n\n");
            appendCylinder(s, c1); appendCylinder(s, c2); appendCylinder(s, c3);
            if (anyData) {
                int[] cur = { valueOrMinus(c1, true), valueOrMinus(c2, true), valueOrMinus(c3, true) };
                int max = -1, min = Integer.MAX_VALUE, maxCyl = -1, n = 0;
                for (int i = 0; i < cur.length; i++) {
                    if (cur[i] >= 0) { n++; if (cur[i] > max) { max = cur[i]; maxCyl = i + 1; } min = Math.min(min, cur[i]); }
                }
                if (n >= 2) {
                    s.append("\nConfronto relativo: ");
                    if (max <= 0) s.append("nessun misfire corrente riportato nei cilindri disponibili.");
                    else if (max >= Math.max(10, min * 5 + 5)) s.append("cilindro ").append(maxCyl).append(" nettamente più alto: approfondire candela/bobina/iniettore/compressione.");
                    else s.append("conteggi presenti ma senza forte sbilanciamento tra cilindri; valutare nel contesto del ciclo di guida.");
                    s.append("\n");
                }
            }
            s.append("\nNota: i conteggi Mode $06 vanno confrontati soprattutto tra cilindri e non dimostrano da soli quale componente sia guasto.");
            return s.toString();
        }

        private static int valueOrMinus(Cylinder c, boolean current) {
            if (c == null) return -1;
            if (current) return c.currentAvailable ? c.current : -1;
            return c.ewmaAvailable ? c.ewma : -1;
        }

        private static void appendCylinder(StringBuilder s, Cylinder c) {
            if (c == null) return;
            s.append("Cilindro ").append(c.number).append(": current=")
                    .append(c.currentAvailable ? c.current : "N/D")
                    .append(" • EWMA=")
                    .append(c.ewmaAvailable ? c.ewma : "N/D").append("\n");
        }
    }

    public static Report analyze(Elm327Client elm) {
        Cylinder c1 = readCylinder(elm, 1, "A2");
        Cylinder c2 = readCylinder(elm, 2, "A3");
        Cylinder c3 = readCylinder(elm, 3, "A4");
        return new Report(c1, c2, c3);
    }

    private static Cylinder readCylinder(Elm327Client elm, int number, String mid) {
        String raw = "";
        try { raw = elm.command("06" + mid, 1800); } catch (Exception ignored) {}
        if (raw == null) raw = "";
        String upper = raw.toUpperCase(Locale.ROOT);
        if (upper.contains("NO DATA") || upper.contains("UNABLE") || upper.contains("ERROR") || upper.contains("STOPPED")) {
            return new Cylinder(number, -1, -1, false, false, raw);
        }
        int current = -1, ewma = -1;
        boolean curOk = false, ewmaOk = false;
        String h = ObdParser.hexOnly(raw);
        int idx = h.indexOf("46" + mid);
        if (idx < 0) return new Cylinder(number, -1, -1, false, false, raw);

        // Start at OBDMID. Each standardized record is 9 bytes:
        // OBDMID, TID, UASID, TestValue(2), Min(2), Max(2).
        int pos = idx + 2;
        while (pos + 18 <= h.length()) {
            String recordMid = h.substring(pos, pos + 2);
            if (!recordMid.equals(mid)) {
                int next = h.indexOf(mid, pos + 2);
                if (next < 0 || next + 18 > h.length()) break;
                pos = next;
                continue;
            }
            try {
                int tid = Integer.parseInt(h.substring(pos + 2, pos + 4), 16);
                int uasid = Integer.parseInt(h.substring(pos + 4, pos + 6), 16);
                int value = Integer.parseInt(h.substring(pos + 6, pos + 10), 16);
                // Standard misfire counts use UASID $24, one count per bit.
                if (uasid == 0x24 && tid == 0x0C) { current = value; curOk = true; }
                if (uasid == 0x24 && tid == 0x0B) { ewma = value; ewmaOk = true; }
            } catch (Exception ignored) {}
            pos += 18;
        }
        return new Cylinder(number, current, ewma, curOk, ewmaOk, raw);
    }
}
