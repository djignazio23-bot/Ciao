package com.peugeot.obdtool;

import java.util.ArrayList;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Locale;
import java.util.Set;

/** Read-only standardized Mode $06 scanner. */
public final class Mode06Scanner {
    private Mode06Scanner(){}

    public static final class Result {
        public final List<Integer> supportedMids=new ArrayList<>();
        public final List<String> rawResponses=new ArrayList<>();
        public final List<String> decodedResponses=new ArrayList<>();
        public int queried=0;
        public int responses=0;
        public int misfireCandidateLines=0;

        public String compactSummary(){
            return "MID supportati="+supportedMids.size()+" • interrogati="+queried+" • risposte="+responses+" • candidati misfire="+misfireCandidateLines;
        }
        public String fullReport(){
            StringBuilder s=new StringBuilder("MODE $06 DEEP SCAN • READ ONLY\n");
            s.append(compactSummary()).append("\n");
            if(supportedMids.isEmpty())s.append("Nessun MID standard rilevato.\n");
            for(int i=0;i<decodedResponses.size();i++){
                s.append("\n--- ").append(rawResponses.get(i)).append(" ---\n");
                s.append(decodedResponses.get(i)).append("\n");
            }
            s.append("\nNota: TID 0B/0C sono candidati standardizzati di misfire; l'associazione al cilindro dipende da MID/UASID e dalla ECU. Nessun dato viene scritto.");
            return s.toString();
        }
    }

    public static Result scan(Elm327Client elm) {
        Result result=new Result();
        Set<Integer> mids=new LinkedHashSet<>();
        int[] bases={0x00,0x20,0x40,0x60,0x80,0xA0,0xC0,0xE0};
        for(int base:bases){
            String cmd=String.format(Locale.ROOT,"06%02X",base);
            String raw=safe(elm,cmd,1600);
            long mask=parseSupportMask(raw,base);
            if(mask<0) continue;
            for(int bit=0;bit<32;bit++){
                if((mask & (1L<<(31-bit)))!=0){
                    int mid=base+1+bit;
                    if(mid<=0xFF)mids.add(mid);
                }
            }
        }
        // Continuation/support MIDs are useful for discovery but not actual monitor payloads.
        mids.remove(0x20);mids.remove(0x40);mids.remove(0x60);mids.remove(0x80);mids.remove(0xA0);mids.remove(0xC0);mids.remove(0xE0);
        result.supportedMids.addAll(mids);

        // Safety/performance cap. A real engine ECU normally exposes far fewer than this.
        int max=48;
        for(int mid:mids){
            if(result.queried>=max)break;
            result.queried++;
            String cmd=String.format(Locale.ROOT,"06%02X",mid);
            String raw=safe(elm,cmd,1800);
            String upper=raw.toUpperCase(Locale.ROOT);
            if(raw.isEmpty()||upper.contains("NO DATA")||upper.contains("UNABLE"))continue;
            String decoded=DeepObdParser.mode06Decoded(raw);
            if(decoded.startsWith("nessun record"))continue;
            result.responses++;
            result.rawResponses.add(cmd+" RAW: "+raw);
            result.decodedResponses.add(decoded);
            for(String line:decoded.split("\\n")) if(line.contains("MISFIRE candidate")) result.misfireCandidateLines++;
        }
        return result;
    }

    private static String safe(Elm327Client elm,String cmd,long timeout){
        try{return elm.command(cmd,timeout);}catch(Exception e){return "";}
    }

    private static long parseSupportMask(String raw,int base){
        if(raw==null)return -1;
        String u=raw.toUpperCase(Locale.ROOT);
        if(u.contains("NO DATA")||u.contains("UNABLE"))return -1;
        String h=ObdParser.hexOnly(u.replace("SEARCHING","").replace("NODATA","").replace("NO DATA",""));
        String marker=String.format(Locale.ROOT,"46%02X",base);
        int idx=h.indexOf(marker);
        if(idx<0||idx+marker.length()+8>h.length())return -1;
        String data=h.substring(idx+marker.length(),idx+marker.length()+8);
        try{return Long.parseLong(data,16)&0xFFFFFFFFL;}catch(Exception e){return -1;}
    }
}
