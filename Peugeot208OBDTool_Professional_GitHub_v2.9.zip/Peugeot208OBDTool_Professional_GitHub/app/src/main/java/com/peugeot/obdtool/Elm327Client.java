package com.peugeot.obdtool;

import android.bluetooth.BluetoothDevice;
import android.bluetooth.BluetoothSocket;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.nio.charset.StandardCharsets;
import java.util.UUID;

public class Elm327Client {
    private static final UUID SPP_UUID = UUID.fromString("00001101-0000-1000-8000-00805F9B34FB");
    private BluetoothSocket socket;
    private BufferedReader reader;
    private OutputStream out;

    public void connect(BluetoothDevice device) throws IOException {
        close();
        socket = device.createRfcommSocketToServiceRecord(SPP_UUID);
        socket.connect();
        reader = new BufferedReader(new InputStreamReader(socket.getInputStream(), StandardCharsets.US_ASCII));
        out = socket.getOutputStream();
        initialize();
    }

    public boolean isConnected() { return socket != null && socket.isConnected(); }

    private void initialize() throws IOException {
        command("ATZ", 3000);
        command("ATE0", 1000);
        command("ATL0", 1000);
        command("ATS0", 1000);
        command("ATH0", 1000);
        command("ATAT1", 1000);
        command("ATSP0", 3000);
    }

    public synchronized String command(String cmd, long timeoutMs) throws IOException {
        if (out == null || reader == null || !isConnected()) throw new IOException("ELM327 non connesso");
        while (reader.ready()) reader.read();
        out.write((cmd.trim() + "\r").getBytes(StandardCharsets.US_ASCII));
        out.flush();
        long end = System.currentTimeMillis() + timeoutMs;
        StringBuilder sb = new StringBuilder();
        while (System.currentTimeMillis() < end) {
            while (reader.ready()) {
                int c = reader.read();
                if (c == -1) break;
                if (c == '>') return clean(sb.toString(), cmd);
                sb.append((char)c);
            }
            try { Thread.sleep(15); } catch (InterruptedException e) { Thread.currentThread().interrupt(); throw new IOException("Operazione interrotta"); }
        }
        String partial = clean(sb.toString(), cmd);
        if (partial.isEmpty()) throw new IOException("Timeout risposta ELM327");
        return partial;
    }

    private String clean(String s, String cmd) {
        String x = s.replace("\r", " ").replace("\n", " ").replaceAll("\\s+", " ").trim();
        if (x.equalsIgnoreCase(cmd)) return "";
        if (x.toUpperCase().startsWith(cmd.toUpperCase() + " ")) x = x.substring(cmd.length()).trim();
        return x;
    }

    public String adapterId() throws IOException { return command("ATI", 1200); }
    public String protocol() throws IOException { return command("ATDP", 1200); }
    public String voltage() throws IOException { return command("ATRV", 1200); }

    public void restoreAutomaticProtocol() {
        try { command("ATSP0", 1200); } catch (Exception ignored) {}
        restoreObdFunctionalHeader();
    }

    public void restoreObdFunctionalHeader() {
        // Standard 11-bit OBD functional request address. This only restores transport settings;
        // it does not send any ECU service or change ECU state.
        try { command("ATSH7DF", 900); } catch (Exception ignored) {}
        try { command("ATCAF1", 700); } catch (Exception ignored) {}
        try { command("ATH0", 700); } catch (Exception ignored) {}
    }

    public void close() {
        try { if (socket != null) socket.close(); } catch (Exception ignored) {}
        socket = null; reader = null; out = null;
    }
}
