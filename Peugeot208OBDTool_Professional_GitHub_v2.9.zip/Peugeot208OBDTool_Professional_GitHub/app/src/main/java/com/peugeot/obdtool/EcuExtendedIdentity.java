package com.peugeot.obdtool;

import java.util.LinkedHashMap;
import java.util.Locale;
import java.util.Map;

/**
 * Read-only UDS fingerprint collected from the engine ECU.
 * Only service 0x22 (ReadDataByIdentifier) is used.
 */
public final class EcuExtendedIdentity {
    public final String requestHeader;
    public final String bootSoftwareId;
    public final String applicationSoftwareId;
    public final String applicationDataId;
    public final String partNumber;
    public final String manufacturerSoftwareNumber;
    public final String manufacturerSoftwareVersion;
    public final String supplierId;
    public final String serialNumber;
    public final String vin;
    public final String manufacturerHardwareNumber;
    public final String supplierHardwareNumber;
    public final String supplierHardwareVersion;
    public final String supplierSoftwareNumber;
    public final String supplierSoftwareVersion;
    public final int supportedDidCount;
    public final Map<String,String> didValues;

    public EcuExtendedIdentity(
            String requestHeader,
            String bootSoftwareId,
            String applicationSoftwareId,
            String applicationDataId,
            String partNumber,
            String manufacturerSoftwareNumber,
            String manufacturerSoftwareVersion,
            String supplierId,
            String serialNumber,
            String vin,
            String manufacturerHardwareNumber,
            String supplierHardwareNumber,
            String supplierHardwareVersion,
            String supplierSoftwareNumber,
            String supplierSoftwareVersion,
            Map<String,String> didValues) {
        this.requestHeader=requestHeader;
        this.bootSoftwareId=clean(bootSoftwareId);
        this.applicationSoftwareId=clean(applicationSoftwareId);
        this.applicationDataId=clean(applicationDataId);
        this.partNumber=clean(partNumber);
        this.manufacturerSoftwareNumber=clean(manufacturerSoftwareNumber);
        this.manufacturerSoftwareVersion=clean(manufacturerSoftwareVersion);
        this.supplierId=clean(supplierId);
        this.serialNumber=clean(serialNumber);
        this.vin=clean(vin);
        this.manufacturerHardwareNumber=clean(manufacturerHardwareNumber);
        this.supplierHardwareNumber=clean(supplierHardwareNumber);
        this.supplierHardwareVersion=clean(supplierHardwareVersion);
        this.supplierSoftwareNumber=clean(supplierSoftwareNumber);
        this.supplierSoftwareVersion=clean(supplierSoftwareVersion);
        this.didValues=new LinkedHashMap<>(didValues);
        int n=0;
        for(String v:this.didValues.values()) if(!empty(v)) n++;
        this.supportedDidCount=n;
    }

    public boolean hasAnyData(){ return supportedDidCount>0; }

    public String searchBlob(){
        StringBuilder s=new StringBuilder();
        for(String v:didValues.values()) if(!empty(v)) s.append(v).append(' ');
        return s.toString().toUpperCase(Locale.ROOT);
    }

    public String compactSummary(){
        StringBuilder s=new StringBuilder();
        s.append("Extended UDS ID: ").append(supportedDidCount).append('/').append(didValues.size()).append(" DID letti");
        add(s,"Supplier",supplierId);
        add(s,"Part number",partNumber);
        add(s,"HW manufacturer",manufacturerHardwareNumber);
        add(s,"HW supplier",supplierHardwareNumber);
        add(s,"HW version",supplierHardwareVersion);
        add(s,"SW manufacturer",manufacturerSoftwareNumber);
        add(s,"SW version",manufacturerSoftwareVersion);
        add(s,"SW supplier",supplierSoftwareNumber);
        add(s,"SW supplier ver.",supplierSoftwareVersion);
        add(s,"Boot SW",bootSoftwareId);
        add(s,"Application SW",applicationSoftwareId);
        add(s,"Application data",applicationDataId);
        add(s,"Serial ECU",serialNumber);
        s.append("\nPolicy: sola lettura UDS 0x22 su ECU motore • nessuna scrittura/coding");
        return s.toString();
    }

    public String rawReport(){
        StringBuilder s=new StringBuilder();
        s.append("ENGINE ECU EXTENDED IDENTIFICATION\n");
        s.append("Request header: ").append(requestHeader).append("\n");
        s.append("Read-only service: UDS 0x22 ReadDataByIdentifier\n");
        for(Map.Entry<String,String> e:didValues.entrySet()){
            s.append(e.getKey()).append(": ").append(empty(e.getValue())?"N/D":e.getValue()).append("\n");
        }
        return s.toString();
    }

    private static void add(StringBuilder s,String label,String value){
        if(!empty(value)) s.append("\n").append(label).append(": ").append(value);
    }
    private static String clean(String s){ return s==null?"":s.trim(); }
    private static boolean empty(String s){ return s==null||s.trim().isEmpty(); }
}
