package com.peugeot.obdtool;

import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

/**
 * Read-only decoders for standardized SAE J1979 / ISO 15031 data used by the
 * deep engine scan. Unsupported PIDs are reported as invalid/N/D.
 */
public final class DeepObdParser {
    private DeepObdParser() {}

    private static int[] bytesAfter(String raw, String marker, int count) {
        String h = ObdParser.hexOnly(sanitize(raw));
        String m = marker.toUpperCase(Locale.ROOT);
        int i = h.indexOf(m);
        if (i < 0) return null;
        i += m.length();
        if (h.length() < i + count * 2) return null;
        int[] b = new int[count];
        try {
            for (int n = 0; n < count; n++) b[n] = Integer.parseInt(h.substring(i + n * 2, i + n * 2 + 2), 16);
            return b;
        } catch (Exception e) { return null; }
    }

    private static String sanitize(String raw) {
        if (raw == null) return "";
        return raw.toUpperCase(Locale.ROOT)
                .replace("SEARCHING...", "")
                .replace("SEARCHING", "")
                .replace("NO DATA", "")
                .replace("NODATA", "")
                .replace("UNABLE TO CONNECT", "")
                .replace("UNABLETOCONNECT", "")
                .replace("STOPPED", "")
                .replace("BUS INIT", "")
                .replace("BUSINIT", "");
    }

    public static final class WidebandO2 {
        public final boolean valid;
        public final String pid;
        public final double lambda;
        public final double voltage;
        WidebandO2(boolean valid, String pid, double lambda, double voltage) {
            this.valid=valid; this.pid=pid; this.lambda=lambda; this.voltage=voltage;
        }
        public static WidebandO2 invalid(){ return new WidebandO2(false,"",-1,-1); }
    }

    /** PIDs 24-2B: wide range O2 equivalence ratio + sensor voltage. */
    public static WidebandO2 widebandO2(String raw, String pid) {
        int[] b=bytesAfter(raw,"41"+pid,4);
        if(b==null) return WidebandO2.invalid();
        double lambda=((b[0]*256.0+b[1])*2.0/65536.0);
        double voltage=((b[2]*256.0+b[3])*8.0/65536.0);
        if(lambda<0 || lambda>2.1) return WidebandO2.invalid();
        return new WidebandO2(true,pid,lambda,voltage);
    }

    public static final class BoostControl {
        public final boolean valid, cmdSupported, actualSupported;
        public final double commandedKpa, actualKpa;
        public final String status;
        BoostControl(boolean valid, boolean cmdSupported, boolean actualSupported, double commandedKpa, double actualKpa, String status){
            this.valid=valid; this.cmdSupported=cmdSupported; this.actualSupported=actualSupported;
            this.commandedKpa=commandedKpa; this.actualKpa=actualKpa; this.status=status;
        }
        public static BoostControl invalid(){return new BoostControl(false,false,false,-1,-1,"N/D");}
    }

    /** PID 70 Boost Pressure Control: commanded/actual absolute pressure A. */
    public static BoostControl boostControl(String raw){
        int[] b=bytesAfter(raw,"4170",10);
        if(b==null) return BoostControl.invalid();
        boolean cmd=(b[0]&0x01)!=0, act=(b[0]&0x02)!=0, statusSupported=(b[0]&0x04)!=0;
        double commanded=(b[1]*256.0+b[2])*0.03125;
        double actual=(b[3]*256.0+b[4])*0.03125;
        String status="N/D";
        if(statusSupported){
            int s=b[9]&0x03;
            if(s==1)status="OPEN LOOP"; else if(s==2)status="CLOSED LOOP"; else if(s==3)status="FAULT"; else status="RESERVED";
        }
        return new BoostControl(cmd||act||statusSupported,cmd,act,commanded,actual,status);
    }

    public static final class WastegateControl {
        public final boolean valid, cmdSupported, actualSupported;
        public final double commandedPct, actualPct;
        WastegateControl(boolean valid, boolean cmdSupported, boolean actualSupported, double commandedPct, double actualPct){
            this.valid=valid; this.cmdSupported=cmdSupported; this.actualSupported=actualSupported;
            this.commandedPct=commandedPct; this.actualPct=actualPct;
        }
        public static WastegateControl invalid(){return new WastegateControl(false,false,false,-1,-1);}
    }

    /** PID 72 Wastegate Control A. 0%=closed/full boost, 100%=open/dump boost. */
    public static WastegateControl wastegateControl(String raw){
        int[] b=bytesAfter(raw,"4172",5);
        if(b==null) return WastegateControl.invalid();
        boolean cmd=(b[0]&0x01)!=0, act=(b[0]&0x02)!=0;
        double commanded=b[1]*100.0/255.0, actual=b[2]*100.0/255.0;
        return new WastegateControl(cmd||act,cmd,act,commanded,actual);
    }

    public static final class RailControl {
        public final boolean valid, cmdSupported, actualSupported, tempSupported;
        public final double commandedKpa, actualKpa;
        public final int temperatureC;
        RailControl(boolean valid, boolean cmdSupported, boolean actualSupported, boolean tempSupported,
                    double commandedKpa,double actualKpa,int temperatureC){
            this.valid=valid;this.cmdSupported=cmdSupported;this.actualSupported=actualSupported;this.tempSupported=tempSupported;
            this.commandedKpa=commandedKpa;this.actualKpa=actualKpa;this.temperatureC=temperatureC;
        }
        public static RailControl invalid(){return new RailControl(false,false,false,false,-1,-1,-999);}
    }

    /** PID 6D Fuel Pressure Control System A. */
    public static RailControl railControl(String raw){
        int[] b=bytesAfter(raw,"416D",11);
        if(b==null) return RailControl.invalid();
        boolean cmd=(b[0]&0x01)!=0, act=(b[0]&0x02)!=0, temp=(b[0]&0x04)!=0;
        double commanded=(b[1]*256.0+b[2])*10.0;
        double actual=(b[3]*256.0+b[4])*10.0;
        int t=b[5]-40;
        return new RailControl(cmd||act||temp,cmd,act,temp,commanded,actual,t);
    }

    public static int oilTemperature(String raw){
        int[] b=bytesAfter(raw,"415C",1);
        return b==null?-999:b[0]-40;
    }

    /** PID 01 continuous-monitor state, focused on misfire support/readiness. */
    public static String misfireMonitorStatus(String raw){
        int[] b=bytesAfter(raw,"4101",4);
        if(b==null) return "N/D";
        boolean supported=(b[1]&0x01)!=0;
        boolean incomplete=(b[1]&0x10)!=0;
        if(!supported) return "non supportato dalla ECU via PID 01";
        return incomplete?"supportato • monitor NON completo":"supportato • monitor completo";
    }

    public static List<String> dtcsWithMarker(String raw,String responseMarker){
        String h=ObdParser.hexOnly(sanitize(raw));
        String marker=responseMarker.toUpperCase(Locale.ROOT);
        int idx=h.indexOf(marker);
        List<String> out=new ArrayList<>();
        if(idx<0)return out;
        h=h.substring(idx+marker.length());
        for(int i=0;i+3<h.length();i+=4){
            String w=h.substring(i,i+4);
            if("0000".equals(w))continue;
            try{
                int v=Integer.parseInt(w,16); char[] t={'P','C','B','U'};
                char prefix=t[(v>>14)&3]; int d1=(v>>12)&3; int rest=v&0xFFF;
                out.add(String.format(Locale.ROOT,"%c%d%03X",prefix,d1,rest));
            }catch(Exception ignored){}
        }
        return out;
    }

    public static String mode06Decoded(String raw){
        String h=ObdParser.hexOnly(sanitize(raw));
        StringBuilder out=new StringBuilder();
        int from=0, count=0, misfireCandidates=0;
        while(true){
            int idx=h.indexOf("46",from);
            if(idx<0 || idx+20>h.length()) break;
            try{
                int mid=Integer.parseInt(h.substring(idx+2,idx+4),16);
                int tid=Integer.parseInt(h.substring(idx+4,idx+6),16);
                int uasid=Integer.parseInt(h.substring(idx+6,idx+8),16);
                int value=Integer.parseInt(h.substring(idx+8,idx+12),16);
                int min=Integer.parseInt(h.substring(idx+12,idx+16),16);
                int max=Integer.parseInt(h.substring(idx+16,idx+20),16);
                if(count>0)out.append('\n');
                out.append(String.format(Locale.ROOT,"MID %02X • TID %02X • UASID %02X • raw %d • min %d • max %d",mid,tid,uasid,value,min,max));
                if(tid==0x0B || tid==0x0C){
                    misfireCandidates++;
                    out.append(" • MISFIRE candidate");
                }
                count++;
                from=idx+20;
            }catch(Exception e){from=idx+2;}
        }
        if(count==0)return "nessun record Mode $06 decodificabile";
        return "record="+count+" • candidati misfire="+misfireCandidates+"\n"+out;
    }
}
