# Build v2.9 on the existing GitHub workflow

Upload `Peugeot208OBDTool_Professional_GitHub_v2.9.zip` to the repository root.

In the repository workflow, set the unzip input to:

```yaml
unzip -o Peugeot208OBDTool_Professional_GitHub_v2.9.zip -d project
```

Keep the build working directory as:

```yaml
working-directory: project/Peugeot208OBDTool_Professional_GitHub
```

Then run `gradle assembleDebug` as in the current working workflow.
