package com.peugeot.obdtool;

import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

public final class ObdParser {
    private ObdParser() {}

    public static String hexOnly(String s) { return s == null ? "" : s.toUpperCase(Locale.ROOT).replaceAll("[^0-9A-F]", ""); }
    private static int[] bytesAfter(String raw, String marker, int count) {
        String h = hexOnly(raw), m = marker.toUpperCase(Locale.ROOT); int i = h.indexOf(m); if (i < 0) return null; i += m.length();
        if (h.length() < i + count * 2) return null; int[] b = new int[count];
        try { for (int n=0;n<count;n++) b[n]=Integer.parseInt(h.substring(i+n*2,i+n*2+2),16); return b; } catch(Exception e){ return null; }
    }
    public static double rpm(String raw){ int[] b=bytesAfter(raw,"410C",2); return b==null?-1:((b[0]*256+b[1])/4.0); }
    public static int speed(String raw){ int[] b=bytesAfter(raw,"410D",1); return b==null?-1:b[0]; }
    public static int coolant(String raw){ int[] b=bytesAfter(raw,"4105",1); return b==null?-999:b[0]-40; }
    public static int map(String raw){ int[] b=bytesAfter(raw,"410B",1); return b==null?-1:b[0]; }
    public static double throttle(String raw){ int[] b=bytesAfter(raw,"4111",1); return b==null?-1:(b[0]*100.0/255.0); }
    public static double fuelTrim(String raw,String pid){ int[] b=bytesAfter(raw,"41"+pid,1); return b==null?-999:(b[0]-128)*100.0/128.0; }
    public static double parseVoltage(String raw){
        if(raw==null) return -1; String x=raw.toUpperCase(Locale.ROOT).replace("V","").trim();
        try{return Double.parseDouble(x.replace(',','.'));}catch(Exception e){return -1;}
    }
    public static List<String> dtcs(String raw){
        String h=hexOnly(raw); int idx=h.indexOf("43"); List<String> out=new ArrayList<>(); if(idx<0)return out; h=h.substring(idx+2);
        for(int i=0;i+3<h.length();i+=4){ String w=h.substring(i,i+4); if("0000".equals(w))continue; try{int v=Integer.parseInt(w,16); char[] t={'P','C','B','U'}; char prefix=t[(v>>14)&3]; int d1=(v>>12)&3; int rest=v&0xFFF; out.add(String.format(Locale.ROOT,"%c%d%03X",prefix,d1,rest));}catch(Exception ignored){} }
        return out;
    }
    public static String vin(String raw){
        if(raw==null)return ""; String h=hexOnly(raw); int idx=h.indexOf("4902"); if(idx<0)return "";
        // Collect printable ASCII after service/pid and frame counters; filter to VIN charset and keep last 17 plausible chars.
        StringBuilder ascii=new StringBuilder();
        for(int i=idx+4;i+1<h.length();i+=2){ try{int v=Integer.parseInt(h.substring(i,i+2),16); if(v>=32&&v<=90) ascii.append((char)v);}catch(Exception ignored){} }
        String s=ascii.toString().replaceAll("[^A-HJ-NPR-Z0-9]",""); return s.length()>=17?s.substring(s.length()-17):s;
    }
}
