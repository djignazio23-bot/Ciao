package com.peugeot.obdtool;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.util.AttributeSet;
import android.view.View;
import java.util.ArrayDeque;
import java.util.Deque;

public class SparklineView extends View {
    private final Deque<Float> values = new ArrayDeque<>();
    private final Paint line = new Paint(Paint.ANTI_ALIAS_FLAG), grid = new Paint(Paint.ANTI_ALIAS_FLAG), label = new Paint(Paint.ANTI_ALIAS_FLAG);
    public SparklineView(Context c, AttributeSet a){ super(c,a); line.setColor(0xFF00D0B4); line.setStrokeWidth(4f); line.setStyle(Paint.Style.STROKE); grid.setColor(0x33263241); grid.setStrokeWidth(1f); label.setColor(0xFF9EACBD); label.setTextSize(28f); }
    public void addValue(float v){ if(v<0)return; if(values.size()>=60)values.removeFirst(); values.addLast(v); invalidate(); }
    public void clear(){values.clear();invalidate();}
    @Override protected void onDraw(Canvas c){ super.onDraw(c); float w=getWidth(),h=getHeight(); for(int i=1;i<4;i++)c.drawLine(0,h*i/4,w,h*i/4,grid); c.drawText("RPM live",18,34,label); if(values.size()<2)return; float max=1000; for(float v:values)max=Math.max(max,v); float dx=w/(Math.max(1,values.size()-1)); float px=0,py=h; int i=0; for(float v:values){float x=i*dx,y=h-(v/max)*(h-45); if(i>0)c.drawLine(px,py,x,y,line); px=x;py=y;i++;} }
}
