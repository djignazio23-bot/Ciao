package com.peugeot.obdtool;

import android.content.Context;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;

public class CsvLogger {
    private File file;
    public File start(Context c, String prefix) throws IOException {
        File dir=new File(c.getExternalFilesDir(null),"logs"); if(!dir.exists()&&!dir.mkdirs()) throw new IOException("Impossibile creare cartella log");
        String ts=new SimpleDateFormat("yyyyMMdd_HHmmss", Locale.ROOT).format(new Date()); file=new File(dir,prefix+"_"+ts+".csv");
        try(FileWriter w=new FileWriter(file)){w.write("timestamp_ms,rpm,speed_kmh,coolant_c,map_kpa,throttle_pct,stft_pct,ltft_pct,voltage_v\n");}
        return file;
    }
    public synchronized void append(long ts,double rpm,int speed,int coolant,int map,double throttle,double stft,double ltft,double voltage) throws IOException {
        if(file==null)return; try(FileWriter w=new FileWriter(file,true)){w.write(String.format(Locale.US,"%d,%.1f,%d,%d,%d,%.2f,%.2f,%.2f,%.2f\n",ts,rpm,speed,coolant,map,throttle,stft,ltft,voltage));}
    }
    public File getFile(){return file;}
}
