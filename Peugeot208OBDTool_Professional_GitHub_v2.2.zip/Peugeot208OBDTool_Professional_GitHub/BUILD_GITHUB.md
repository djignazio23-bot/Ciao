# Creare l'APK con GitHub Actions

Questa versione del progetto include un workflow automatico in:

`.github/workflows/build-apk.yml`

## Metodo più semplice

1. Accedi a GitHub e crea un nuovo repository, ad esempio `208-obd-pro`.
2. Estrai questo ZIP sul PC.
3. Carica **tutto il contenuto della cartella estratta** nel repository GitHub, inclusa la cartella nascosta `.github`.
4. Apri la scheda **Actions** del repository.
5. Seleziona **Build Android APK**.
6. Premi **Run workflow** e conferma.
7. Quando il job è verde, aprilo e scorri in basso fino a **Artifacts**.
8. Scarica **208-OBD-PRO-APK**.
9. Dentro troverai `208-OBD-PRO-v2-debug.apk` e il relativo file SHA-256.

L'APK debug è installabile direttamente su Android per test personali. Android potrebbe chiedere di autorizzare l'installazione di app provenienti da quella sorgente.

## Build automatico

Il workflow parte anche automaticamente quando fai push sui branch `main` o `master`.

## Cosa usa il workflow

- Java 17
- Android SDK / API 35
- Android Build Tools 35.0.0
- Gradle 8.9
- Android Gradle Plugin 8.7.3

## Sicurezza del progetto

Il workflow compila solo il codice presente nel repository. Non contiene keystore, password o token privati. La build prodotta è una build `debug`; per pubblicazione o distribuzione stabile serve una build release firmata con un keystore personale.
